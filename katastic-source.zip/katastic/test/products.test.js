import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, addBalance, addTransaction, editTransaction, snapshot, restore } from '../www/src/core/ledger.js';
import { addProduct, updateProduct, removeProduct, searchProducts, itemsTotal, strukText, receiptText } from '../www/src/core/notes.js';

const mk = () => { const b = createBook(); addBalance(b, { date: '2026-11-01', account: '1101', amount: 100000 }); return b; };
const base = { date: '2026-11-02', kind: 'income', category: 'Pulsa', price: 25000, method: '1101', status: 'berhasil' };

test('katalog produk: tambah, ubah, hapus, cari, tolak duplikat', () => {
  const b = mk(); const p = addProduct(b, { name: 'Pulsa 10rb', price: 12000, cost: 10500 });
  assert.equal(p.id, 'PR-00001');
  assert.throws(() => addProduct(b, { name: 'pulsa 10RB' }), /sudah ada/);
  assert.throws(() => addProduct(b, { name: '' }), /wajib/);
  updateProduct(b, p.id, { price: 12500 }); assert.equal(b.products[0].price, 12500);
  assert.equal(searchProducts(b, 'puls').length, 1); assert.equal(searchProducts(b, 'xyz').length, 0);
  removeProduct(b, p.id); assert.equal(b.products.length, 0);
});

test('transaksi menyimpan produk, ikut backup, bisa diedit dan masuk struk', () => {
  const b = mk(); const items = [{ n: 'Pulsa 10rb', q: 2, p: 12000, c: 10500 }, { n: 'Kuota 5GB', q: 1, p: 1000 }];
  const t = addTransaction(b, { ...base, items });
  assert.deepEqual(t.items, [{ n: 'Pulsa 10rb', q: 2, p: 12000, c: 10500 }, { n: 'Kuota 5GB', q: 1, p: 1000, c: 0 }]);
  assert.deepEqual(itemsTotal(t.items), { price: 25000, cost: 21000 });
  const r = restore(snapshot(b)); assert.equal(r.transactions[0].items.length, 2);
  assert.match(strukText(t), /2x Pulsa 10rb/); assert.match(receiptText(t), /Produk: 2× Pulsa 10rb, 1× Kuota 5GB/);
  editTransaction(b, t.id, { items: [{ n: 'Pulsa 20rb', q: 1, p: 25000 }] }); assert.equal(b.transactions[0].items[0].n, 'Pulsa 20rb');
  editTransaction(b, t.id, { note: 'x' }); assert.equal(b.transactions[0].items.length, 1);   // edit lain tidak menghapus produk
});

test('validasi produk & hanya pendapatan yang menyimpan produk', () => {
  const b = mk();
  assert.throws(() => addTransaction(b, { ...base, items: [{ n: 'A', q: 0, p: 1 }] }), /Jumlah/);
  assert.throws(() => addTransaction(b, { ...base, items: [{ n: '', q: 1, p: 1 }] }), /Nama/);
  assert.throws(() => addTransaction(b, { ...base, items: Array(31).fill({ n: 'A', q: 1, p: 1 }) }), /maksimal 30/);
  const e = addTransaction(b, { ...base, kind: 'expense', category: 'Operasional', price: 1000, items: [{ n: 'A', q: 1, p: 1 }] });
  assert.deepEqual(e.items, []);
});
