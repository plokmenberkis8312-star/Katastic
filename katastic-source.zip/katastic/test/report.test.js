import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, openAccount, addTransaction, setStatus, deleteTransaction, setSettings, txOrder, moveTransaction, editTransaction, liveTransactions, restore, snapshot, isBalanced } from '../www/src/core/ledger.js';
import { recognizedRows, sumRows, reconcile, categoryList, categoryDetail, metricSections, statusCounts, groupTx, goalProgress, hourHistogram, recapText } from '../www/src/core/report.js';

const D1 = '2026-11-10', D2 = '2026-11-12';
const fresh = () => {
  const b = createBook();
  openAccount(b, { date: '2026-11-01', account: '1201', amount: 1000000 });
  openAccount(b, { date: '2026-11-01', account: '1101', amount: 1000000 });
  return b;
};
const sale = (b, o) => addTransaction(b, { kind: 'income', status: 'berhasil', method: '1101', source: '1201', ...o });
const exp = (b, o) => addTransaction(b, { kind: 'expense', method: '1101', ...o });

function sample() {
  const b = fresh();
  sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000, fee: 500 });
  sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000 });
  sale(b, { date: D2, category: 'Pulsa', cost: 20000, price: 23000 });
  sale(b, { date: D2, category: 'Token Listrik', cost: 50500, price: 53000 });
  exp(b, { date: D2, category: 'Listrik', price: 15000 });
  return b;
}

test('rincian dari transaksi sama dengan angka jurnal (tanpa refund)', () => {
  const b = sample(), r = reconcile(b, '2026-11-01', '2026-11-30');
  assert.deepEqual(r.adj, { rev: 0, cogs: 0, exp: 0, gross: 0, net: 0 });
  assert.equal(r.sum.rev, r.pl.revenue);
  assert.equal(r.sum.exp, r.pl.expense);       // biaya tambahan 500 + listrik 15.000
  assert.equal(r.sum.net, r.pl.net);
  assert.equal(r.sum.n, 5);
});

test('daftar kategori: jumlah, nominal, untung; pengeluaran terpisah dari pendapatan', () => {
  const b = sample(), a = '2026-11-01', z = '2026-11-30';
  const inc = categoryList(b, 'income', a, z);
  assert.deepEqual(inc.map(c => [c.name, c.n, c.sum, c.net]), [['Token Listrik', 1, 53000, 2500], ['Pulsa', 3, 47000, 6500]]);
  const ex = categoryList(b, 'expense', a, z);
  assert.deepEqual(ex.map(c => [c.name, c.n, c.sum, c.net]), [['Listrik', 1, 15000, -15000]]);
});

test('detail kategori: hitungan, rata-rata, rincian per nominal, status lain, piutang', () => {
  const b = sample(), a = '2026-11-01', z = '2026-11-30';
  const g = sale(b, { date: D2, category: 'Pulsa', cost: 10000, price: 12000, status: 'gagal' });
  const u = sale(b, { date: D2, category: 'Pulsa', cost: 5000, price: 6000, paid: false });
  const d = categoryDetail(b, 'income', 'Pulsa', a, z);
  assert.ok(g && u);
  assert.equal(d.n, 3);                          // yang belum bayar belum dihitung (dasar: lunas), yang gagal tidak
  assert.equal(d.sum, 47000);
  assert.equal(d.avg, Math.round(47000 / 3));
  assert.equal(d.max, 23000);
  assert.equal(d.min, 12000);
  assert.deepEqual(d.prices.map(p => [p.key, p.n]), [[12000, 2], [23000, 1]]);
  assert.deepEqual(d.unpaid, { n: 1, sum: 6000 });
  assert.equal(d.other.gagal, 1);
  assert.equal(d.history.length, 5);              // 3 berhasil + 1 gagal + 1 belum bayar, terbaru dulu
  assert.ok(d.history.every((t, i, a) => !i || a[i - 1].date >= t.date));
  assert.equal(d.cogs, 40000);
  assert.equal(d.fee, 500);
  assert.equal(d.net, 47000 - 40000 - 500);
  assert.ok(Math.abs(d.margin - (6500 / 47000 * 100)) < 1e-9);
});

test('refund di tanggal lain: omzet dan untung hari transaksi asli ikut berkurang, tanpa selisih', () => {
  const b = sample(), b1 = reconcile(b, D1, D1).pl, b2 = reconcile(b, D2, D2).pl;
  const t = sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000 });
  setStatus(b, t.id, 'refund', D2);              // uang kembali dicatat di D2, tetapi penjualannya dihapus dari D1
  const day1 = reconcile(b, D1, D1), day2 = reconcile(b, D2, D2);
  assert.deepEqual(day1.pl, b1);                 // kembali persis seperti sebelum transaksi dibuat
  assert.deepEqual(day2.pl, b2);                 // dan tidak ada omzet negatif di hari refund
  assert.deepEqual(day1.adj, { rev: 0, cogs: 0, exp: 0, gross: 0, net: 0 });
  assert.deepEqual(day2.adj, { rev: 0, cogs: 0, exp: 0, gross: 0, net: 0 });
  const all = reconcile(b, '2026-11-01', '2026-11-30');
  assert.deepEqual(all.adj, { rev: 0, cogs: 0, exp: 0, gross: 0, net: 0 });
});

test('transaksi dihapus tidak ikut rincian dan tidak menimbulkan selisih', () => {
  const b = sample();
  const t = sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000 });
  deleteTransaction(b, t.id);
  const r = reconcile(b, D1, D1);
  assert.deepEqual(r.adj, { rev: 0, cogs: 0, exp: 0, gross: 0, net: 0 });
  assert.equal(recognizedRows(b, D1, D1).length, 2);
});

test('penjualan belum bayar: dasar "lunas" tidak dihitung, dasar "transaksi" dihitung', () => {
  const b = sample();
  sale(b, { date: D1, category: 'Paket Data', cost: 20000, price: 25000, paid: false });
  assert.equal(recognizedRows(b, D1, D1).filter(t => t.category === 'Paket Data').length, 0);
  assert.equal(reconcile(b, D1, D1).adj.rev, 0);
  setSettings(b, { basis: 'transaksi' });
  assert.equal(recognizedRows(b, D1, D1).filter(t => t.category === 'Paket Data').length, 1);
  assert.equal(reconcile(b, D1, D1).adj.rev, 0);
});

test('bagian rincian kartu: omzet, untung kotor, modal, pengeluaran, untung bersih', () => {
  const b = sample(), rows = recognizedRows(b, '2026-11-01', '2026-11-30'), s = sumRows(rows);
  const sum = (sec) => sec.items.reduce((x, i) => x + i.sum, 0);
  assert.equal(sum(metricSections('omzet', rows)[0]), s.rev);
  assert.equal(sum(metricSections('gross', rows)[0]), s.gross);
  assert.equal(sum(metricSections('modal', rows)[0]), s.cogs);
  const bi = metricSections('biaya', rows);
  assert.equal(sum(bi[0]) + sum(bi[1]), s.exp);
  const nt = metricSections('net', rows);
  assert.equal(sum(nt[0]) + sum(nt[1]), s.net);
  assert.equal(metricSections('omzet', rows)[1].items[0].key, '1101');
  assert.deepEqual(metricSections('tidak-ada', rows), []);
});

test('hitungan status sama dengan dashboard', () => {
  const b = sample();
  sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000, status: 'gagal' });
  const t = sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000 });
  setStatus(b, t.id, 'refund', D1);
  assert.deepEqual(statusCounts(b, '2026-11-01', '2026-11-30'), { berhasil: 5, pending: 0, gagal: 1, dibatalkan: 0, refund: 1 });
});

test('groupTx mengurutkan nilai terbesar dulu', () => {
  const g = groupTx([{ k: 'a', price: 1 }, { k: 'b', price: 5 }, { k: 'a', price: 2 }], t => t.k);
  assert.deepEqual(g.map(x => [x.key, x.n, x.sum]), [['b', 1, 5], ['a', 2, 3]]);
});

test('target bulanan: capaian, sisa, kebutuhan per hari, proyeksi dan status', () => {
  const b = sample();                                   // untung bersih bulan ini: 6.500 + 2.500 - 500 - 15.000 → lihat angka jurnal
  assert.equal(goalProgress(b, '2026-11-12'), null);    // belum ada target
  setSettings(b, { goal: 150000, goalKind: 'revenue' });
  const g = goalProgress(b, '2026-11-12');
  assert.equal(g.done, 12000 + 12000 + 23000 + 53000);  // omzet (basis lunas, semua lunas? penjualan baru langsung lunas)
  assert.equal(g.left, 150000 - g.done);
  assert.equal(g.daysLeft, 18);
  assert.equal(g.perDay, Math.ceil(g.left / 18));
  assert.equal(g.projected, Math.round(g.done / 12 * 30));
  assert.equal(g.status, g.projected >= 150000 ? 'jalur' : 'kejar');
  setSettings(b, { goal: 50000 });
  assert.equal(goalProgress(b, '2026-11-12').status, 'tercapai');
  assert.equal(goalProgress(b, '2026-11-12').pct, 100);
  assert.equal(goalProgress(b, '2026-11-12').perDay, 0);
});

test('target: nilai tidak valid ditolak', () => {
  const b = createBook();
  assert.throws(() => setSettings(b, { goal: -1 }), /Target/);
  assert.throws(() => setSettings(b, { goal: 1.5 }), /Target/);
  assert.throws(() => setSettings(b, { goalKind: 'x' }), /Pilihan/);
  assert.equal(b.settings.goal, 0);
});

test('jam ramai: hitung penjualan berhasil per jam, lewati tanpa jam, tentukan puncak', () => {
  const b = fresh();
  sale(b, { date: D1, time: '09:10', category: 'Pulsa', cost: 10000, price: 12000 });
  sale(b, { date: D1, time: '10:05', category: 'Pulsa', cost: 10000, price: 12000 });
  sale(b, { date: D1, time: '10:55', category: 'Pulsa', cost: 10000, price: 13000 });
  sale(b, { date: D1, category: 'Pulsa', cost: 10000, price: 12000 });                 // tanpa jam
  exp(b, { date: D1, time: '10:00', category: 'Listrik', price: 5000 });                // bukan penjualan
  const h = hourHistogram(b, D1, D1);
  assert.equal(h.total, 3);
  assert.equal(h.peak, 10);
  assert.deepEqual([h.hours[9].n, h.hours[10].n, h.hours[10].rev], [1, 2, 25000]);
  assert.equal(hourHistogram(b, '2026-11-20', '2026-11-30').peak, -1);
});

test('rekap teks: angka, kategori terlaris, piutang', () => {
  const b = sample();
  const txt = recapText(b, '2026-11-01', '2026-11-30', { label: 'Bulan ini', shop: 'Konter Aku', owed: { n: 2, sum: 24000 } });
  assert.match(txt, /\*Rekap Bulan ini\* · Konter Aku/);
  assert.match(txt, /1 Nov 2026 – 30 Nov 2026/);
  assert.match(txt, /Omzet: Rp100\.000/);
  assert.match(txt, /1\. Token Listrik — Rp53\.000 \(1x\)/);
  assert.match(txt, /Piutang belum bayar: Rp24\.000 \(2 transaksi\)/);
  assert.ok(!/Piutang/.test(recapText(b, '2026-11-01', '2026-11-30', { label: 'x' })));
});

test('urutan: transaksi baru di atas, pindah naik/turun/atas/bawah, ID dan jurnal tidak berubah', () => {
  const b = fresh();
  const A = sale(b, { date: D1, time: '09:00', category: 'Pulsa', cost: 10000, price: 12000 }), B = sale(b, { date: D1, time: '10:00', category: 'Pulsa', cost: 10000, price: 12000 }), C = sale(b, { date: D1, time: '11:00', category: 'Pulsa', cost: 10000, price: 12000 });
  const order = () => liveTransactions(b).filter(t => t.date === D1).sort(txOrder).map(t => t.id);
  assert.deepEqual(order(), [C.id, B.id, A.id]);                       // jam terbaru di atas
  const before = JSON.stringify(b.entries), ids = b.transactions.map(t => t.id);
  assert.equal(moveTransaction(b, A.id, 'top'), true);
  assert.deepEqual(order(), [A.id, C.id, B.id]);
  assert.equal(moveTransaction(b, A.id, 'top'), false);                // sudah paling atas
  assert.equal(moveTransaction(b, A.id, 'down'), true);
  assert.deepEqual(order(), [C.id, A.id, B.id]);
  assert.equal(moveTransaction(b, C.id, 'bottom'), true);
  assert.deepEqual(order(), [A.id, B.id, C.id]);
  assert.equal(moveTransaction(b, C.id, 'up'), true);
  assert.deepEqual(order(), [A.id, C.id, B.id]);
  assert.equal(JSON.stringify(b.entries), before);                      // jurnal tidak tersentuh
  assert.deepEqual(b.transactions.map(t => t.id), ids);                 // ID tidak berubah
  assert.ok(isBalanced(b));
  const N = sale(b, { date: D1, time: '08:00', category: 'Pulsa', cost: 10000, price: 12000 });
  assert.equal(order()[0], N.id);                                       // transaksi baru tampil di atas urutan manual
  assert.deepEqual(restore(snapshot(b)).transactions.map(t => t.ord), b.transactions.map(t => t.ord));   // urutan ikut cadangan
});

test('urutan: hari lain tidak terpengaruh, langkah melewati transaksi tersaring, edit tanggal menghapus urutan', () => {
  const b = fresh();
  const A = sale(b, { date: D1, time: '09:00', category: 'Pulsa', cost: 10000, price: 12000 }), B = sale(b, { date: D1, time: '10:00', category: 'Pulsa', cost: 10000, price: 12000 }), C = sale(b, { date: D1, time: '11:00', category: 'Pulsa', cost: 10000, price: 12000 });
  const O = sale(b, { date: D2, time: '09:00', category: 'Pulsa', cost: 10000, price: 12000 });
  moveTransaction(b, C.id, 'down', [C.id, A.id]);                       // B tersaring: C melewati B dan langsung di bawah A
  assert.deepEqual(liveTransactions(b).filter(t => t.date === D1).sort(txOrder).map(t => t.id), [B.id, A.id, C.id]);
  assert.equal(O.ord, undefined);
  assert.equal(liveTransactions(b).sort(txOrder)[0].id, O.id);          // D2 lebih baru, tetap di atas hari D1
  editTransaction(b, C.id, { date: D2 });
  assert.equal(b.transactions.find(t => t.id === C.id).ord, undefined);
  assert.throws(() => moveTransaction(b, 'TX-999999', 'up'), /tidak ditemukan/);
  assert.throws(() => moveTransaction(b, A.id, 'x'), /tidak dikenal/);
});

test('periode awal: validasi pilihan, tanggal tunggal dan rentang', () => {
  const b = createBook();
  assert.throws(() => setSettings(b, { startPeriod: 'minggu' }), /tidak dikenal/);
  assert.throws(() => setSettings(b, { startPeriod: 'custom' }), /Pilih tanggal/);
  assert.equal(b.settings.startPeriod, 'week');                                                 // gagal = tidak ada yang berubah
  assert.throws(() => setSettings(b, { startCustom: { a: '2026-02-30' } }), /tidak valid/);
  assert.throws(() => setSettings(b, { startCustom: { a: '2026-11-10', b: '2026-11-01' } }), /sebelum/);
  setSettings(b, { startCustom: { a: '2026-11-10' }, startPeriod: 'custom' });                 // tanpa b = satu tanggal
  assert.deepEqual(b.settings.startCustom, { a: '2026-11-10', b: '2026-11-10' });
  setSettings(b, { startCustom: { a: '2026-11-01', b: '2026-11-15' } });
  assert.deepEqual(b.settings.startCustom, { a: '2026-11-01', b: '2026-11-15' });
  setSettings(b, { startPeriod: 'month' });
  assert.equal(b.settings.startPeriod, 'month');
  const old = JSON.parse(snapshot(b)); delete old.settings.startPeriod; delete old.settings.startCustom;
  assert.equal(restore(JSON.stringify(old)).settings.startPeriod, 'week');                      // cadangan lama → bawaan 7 hari terakhir
});
