import { test } from 'node:test';
import assert from 'node:assert/strict';
import { pieAngles, sliceInset, slicePath, fmtShare, TAU } from '../www/src/core/pie.js';

const sum = (a) => a.reduce((x, s) => x + (s.a1 - s.a0), 0);

test('proporsional bila tidak ada irisan kecil', () => {
  const a = pieAngles([50, 30, 20]);
  assert.equal(a.length, 3);
  assert.ok(Math.abs(sum(a) - TAU) < 1e-9);
  assert.ok(Math.abs((a[0].a1 - a[0].a0) - TAU * 0.5) < 1e-9);
});

test('timpang ekstrem (500 jt vs 50 rb): irisan kecil tetap terlihat dan total tetap satu lingkaran', () => {
  const a = pieAngles([500_000_000, 50_000]);
  assert.ok(a[1].a1 - a[1].a0 >= 0.07 - 1e-9);
  assert.ok(Math.abs(sum(a) - TAU) < 1e-9);
  assert.equal(a[0].a0, 0); assert.equal(a[1].a1, TAU);
  assert.ok(Math.abs(a[0].share - 500_000_000 / 500_050_000) < 1e-12);   // persen asli tidak berubah
});

test('banyak irisan mungil sekaligus', () => {
  const a = pieAngles([1e9, 10, 5, 1, 1, 1]);
  a.slice(1).forEach(s => assert.ok(s.a1 - s.a0 >= 0.07 - 1e-9));
  assert.ok(Math.abs(sum(a) - TAU) < 1e-9);
  a.forEach((s, i) => { if (i) assert.ok(Math.abs(s.a0 - a[i - 1].a1) < 1e-9); });   // berurutan tanpa celah
});

test('irisan tunggal = lingkaran penuh; kosong / nol = tanpa irisan', () => {
  assert.deepEqual(pieAngles([42]), [{ a0: 0, a1: TAU, share: 1 }]);
  assert.deepEqual(pieAngles([]), []);
  assert.deepEqual(pieAngles([0, 0]), []);
});

test('celah antar irisan tidak menelan irisan tipis', () => {
  const a = 0.07, p = sliceInset(a);
  assert.ok(a - 2 * p > 0.04);
  assert.ok(sliceInset(0.001) <= 0.00025 + 1e-12);
});

test('jalur irisan valid (tanpa NaN) termasuk busur besar', () => {
  for (const [a0, a1] of [[0, 0.07], [0.5, 2], [0, TAU - 0.07]]) {
    const d = slicePath(180, 112, 74, 50, a0, a1);
    assert.ok(!/NaN|Infinity/.test(d)); assert.ok(d.startsWith('M') && d.endsWith('Z'));
  }
  assert.match(slicePath(0, 0, 10, 5, 0, 4), / 0 1 1 /);   // > 180° → large-arc
});

test('teks persen', () => {
  assert.equal(fmtShare(55.24), '55,2'); assert.equal(fmtShare(0.0099), '<0,1'); assert.equal(fmtShare(100), '100'); assert.equal(fmtShare(0), '0');
});
