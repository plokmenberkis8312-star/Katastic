import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, openAccount, addBalance, balanceHistory, cancelBalance, addTransaction, deleteTransaction, setStatus, settleTransaction, setSettings, profitLoss, balance, isBalanced } from '../www/src/core/ledger.js';
import { reconcile } from '../www/src/core/report.js';

const mk = (basis = 'lunas') => { const b = createBook(); setSettings(b, { basis }); openAccount(b, { date: '2026-10-01', account: '1101', amount: 1e6 }); openAccount(b, { date: '2026-10-01', account: '1201', amount: 5e5 }); return b; };
const sale = (b, date, o = {}) => addTransaction(b, { date, price: 12000, cost: 10000, fee: 500, category: 'Pulsa', status: 'berhasil', paid: true, ...o });
const pl = (b, a, z = a) => profitLoss(b, a, z);
const ZERO = { revenue: 0, cogs: 0, expense: 0, net: 0 };
const same = (p) => ({ revenue: p.revenue, cogs: p.cogs, expense: p.expense, net: p.net });

for (const basis of ['lunas', 'transaksi']) {
  test(`[${basis}] refund / batal / hapus: periode asal dan hari pembalikan sama-sama kembali nol`, () => {
    let b = mk(basis), t = sale(b, '2026-10-28'); setStatus(b, t.id, 'refund', '2026-11-02');
    assert.deepEqual(same(pl(b, '2026-10-01', '2026-10-31')), ZERO); assert.deepEqual(same(pl(b, '2026-11-01', '2026-11-30')), ZERO);
    b = mk(basis); t = addTransaction(b, { kind: 'expense', date: '2026-10-28', price: 30000, category: 'Operasional', method: '1101', status: 'berhasil' });
    setStatus(b, t.id, 'dibatalkan', '2026-11-03');
    assert.deepEqual(same(pl(b, '2026-10-01', '2026-10-31')), ZERO); assert.deepEqual(same(pl(b, '2026-11-01', '2026-11-30')), ZERO);
    b = mk(basis); t = sale(b, '2026-10-28'); deleteTransaction(b, t.id);
    assert.deepEqual(same(pl(b, '2026-10-28')), ZERO); assert.ok(isBalanced(b));
  });
}
test('hanya transaksi yang dibatalkan yang berkurang; transaksi lain di hari itu tetap', () => {
  const b = mk(), a = sale(b, '2026-11-10'), c = sale(b, '2026-11-10', { price: 20000, cost: 15000 });
  setStatus(b, a.id, 'refund', '2026-11-23');
  const p = pl(b, '2026-11-10'); assert.equal(p.revenue, 20000); assert.equal(p.net, 20000 - 15000 - 500);
  assert.equal(pl(b, '2026-11-23').revenue, 0);
  assert.equal(reconcile(b, '2026-11-10', '2026-11-10').adj.net, 0);
});
test('piutang: lunas lalu refund menghapus untung di hari lunas dan tidak minus di hari refund', () => {
  const b = mk(), t = sale(b, '2026-10-28', { paid: false });
  assert.equal(pl(b, '2026-10-01', '2026-10-31').revenue, 0);
  settleTransaction(b, t.id, '2026-11-02'); assert.equal(pl(b, '2026-11-02').revenue, 12000);
  setStatus(b, t.id, 'refund', '2026-11-05');
  assert.equal(pl(b, '2026-11-02').revenue, 0); assert.equal(pl(b, '2026-11-05').revenue, 0);
});
test('saldo kas tetap bergerak pada tanggal pembalikan (uang kembali hari refund)', () => {
  const b = mk(), k0 = balance(b, '1101'), t = sale(b, '2026-11-10');
  setStatus(b, t.id, 'refund', '2026-11-23');
  assert.equal(balance(b, '1101'), k0); assert.equal(balance(b, '1101', '2026-11-15') ?? balance(b, '1101'), balance(b, '1101', '2026-11-15'));
});

test('tambah saldo: tercatat di riwayat dengan catatan, urut terbaru, dan menambah ekuitas', () => {
  const b = mk(), k0 = balance(b, '1101');
  addBalance(b, { date: '2026-11-05', account: '1101', amount: 250000, note: '  Setor   modal  ' });
  addBalance(b, { date: '2026-11-20', account: '1201', amount: 100000 });
  const h = balanceHistory(b);
  assert.equal(h.length, 4); assert.deepEqual(h.slice(0, 2).map(x => [x.account, x.amount, x.note, x.awal]), [['1201', 100000, '', false], ['1101', 250000, 'Setor modal', false]]);
  assert.deepEqual(h.slice(2).map(x => x.awal), [true, true]);       // dua saldo awal
  assert.equal(balance(b, '1101'), k0 + 250000); assert.ok(isBalanced(b));
  assert.deepEqual(same(pl(b, '2026-11-01', '2026-11-30')), ZERO);   // modal bukan pendapatan
});
test('tambah saldo: nominal dan akun divalidasi', () => {
  const b = mk();
  assert.throws(() => addBalance(b, { date: '2026-11-05', account: '1101', amount: 0 }), /lebih dari 0/);
  assert.throws(() => addBalance(b, { date: '2026-11-05', account: '3101', amount: 1000 }), /tidak valid/);
  assert.throws(() => addBalance(b, { date: '2026-11-05', account: '9999', amount: 1000 }), /tidak valid/);
  assert.throws(() => addBalance(b, { date: '2026-11-05', account: '1101', amount: 10.5 }));
});
test('batalkan tambah saldo: saldo berkurang, riwayat ditandai, tidak bisa dua kali', () => {
  const b = mk(), k0 = balance(b, '1101'), e = addBalance(b, { date: '2026-11-05', account: '1101', amount: 250000 });
  cancelBalance(b, e.id, '2026-11-06');
  assert.equal(balance(b, '1101'), k0);
  const h = balanceHistory(b).find(x => x.id === e.id); assert.equal(h.reversed, true); assert.ok(h.reversedId);
  assert.equal(balanceHistory(b).length, 3);                          // pembaliknya tidak muncul sebagai baris sendiri
  assert.throws(() => cancelBalance(b, e.id, '2026-11-06'), /Sudah dibatalkan/);
  assert.throws(() => cancelBalance(b, 'JE-999999', '2026-11-06'), /tidak ditemukan/);
  assert.ok(isBalanced(b));
});
test('batalkan tambah saldo ditolak bila saldo akun akan minus; tidak ada yang berubah', () => {
  const b = mk(), e = addBalance(b, { date: '2026-11-05', account: '1101', amount: 250000 });
  addTransaction(b, { kind: 'expense', date: '2026-11-06', price: 1100000, category: 'Operasional', method: '1101', status: 'berhasil' });
  const n = b.entries.length;
  assert.throws(() => cancelBalance(b, e.id, '2026-11-07'));
  assert.equal(b.entries.length, n); assert.equal(balanceHistory(b).find(x => x.id === e.id).reversed, false);
});
test('hanya jurnal saldo yang bisa dibatalkan lewat riwayat (bukan jurnal penjualan)', () => {
  const b = mk(), t = sale(b, '2026-11-10');
  assert.throws(() => cancelBalance(b, t.entryId, '2026-11-11'), /tidak ditemukan/);
});
