import test from 'node:test';
import assert from 'node:assert/strict';
import { abbrRupiah } from '../www/src/core/money.js';

test('singkatan nominal: rb, jt, m (miliar), t (triliun)', () => {
  const cases = [[0, '0'], [500, '500'], [1500, '1,5rb'], [75000, '75rb'], [999999, '1jt'], [1250000, '1,25jt'], [50000000, '50jt'],
    [999999999, '1m'], [1000000000, '1m'], [50000000000, '50m'], [50000000000000 / 1000, '50m'], [2500000000, '2,5m'], [1200000000000, '1,2t'], [50000000000000, '50t']];
  for (const [v, out] of cases) assert.equal(abbrRupiah(v), out, String(v));
  assert.equal(abbrRupiah(-2500000), '-2,5jt');
});
