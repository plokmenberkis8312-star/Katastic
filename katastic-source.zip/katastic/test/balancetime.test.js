import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, openAccount, addBalance, balanceHistory, isBalanced } from '../www/src/core/ledger.js';

test('tambah modal menyimpan jam dan muncul di riwayat; tanpa jam tetap valid', () => {
  const b = createBook(); openAccount(b, { date: '2026-11-01', account: '1101', amount: 100000 });
  addBalance(b, { date: '2026-11-10', time: '14:05', account: '1101', amount: 5000 });
  addBalance(b, { date: '2026-11-10', account: '1101', amount: 3000 });
  addBalance(b, { date: '2026-11-10', time: 'abc', account: '1101', amount: 1000 });   // jam tidak valid diabaikan
  const h = balanceHistory(b).filter(x => !x.awal);
  assert.deepEqual(h.map(x => [x.amount, x.time]).sort((p, q) => p[0] - q[0]), [[1000, ''], [3000, ''], [5000, '14:05']]);
  assert.ok(isBalanced(b));
});
