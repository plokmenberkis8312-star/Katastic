import { demoBook } from './src/core/demo.js';
import { evalExpr, pressKey, fmtExpr } from './src/core/calc.js';
import { txOrder, moveTransaction, addBalance, balanceHistory, cancelBalance, deleteTransactions, placeTransaction, createBook, restore, snapshot, balance, addTransaction, setStatus, openAccount, profitLoss, CATEGORY_LIST, EXPENSE_CATS, addCategory, removeCategory, addAccount, removeAccount, settleTransaction, editTransaction, ACCOUNT_SHORT, deleteTransaction, setPaid, deleteAccount, restoreAccount, liveTransactions, PROTECTED_ACCOUNTS, recognizedDate, setSettings } from './src/core/ledger.js';
import { addContact, updateContact, removeContact, searchContacts, findContactByNumber, numKey, receiptText, reminderText, waNumber } from './src/core/notes.js';
import { parseRupiah, formatRupiah as rp, abbrRupiah } from './src/core/money.js';
import { pieAngles, sliceInset, slicePath, fmtShare } from './src/core/pie.js';
import { recognizedRows, reconcile, categoryList, categoryDetail, metricSections, statusCounts, goalProgress, hourHistogram, recapText } from './src/core/report.js';
import { loadSnapshot, saveSnapshot } from './src/db/idb.js';
import { parseReceiptText } from './src/core/receipt.js';
import { MAX_FILES, newFileId, filesOf, fileText, setFiles, fileIdsInUse } from './src/core/attach.js';
import { strukText, addProduct, updateProduct, removeProduct, searchProducts, itemsTotal, itemsLine } from './src/core/notes.js';
import { readImageText } from './src/core/ocr.js';
import { putFile, getFile, delFiles, fileKeys } from './src/db/files.js';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ymd = (d) => d.toLocaleDateString('sv-SE');
const today = () => ymd(new Date());
let book = null, view = 'home', period = 'week', draft = null, customRange = null;   // customRange = { a, b } untuk periode 'custom' (a === b = satu tanggal)
const live = () => liveTransactions(book);
const VERSION = '0.35.0';
let nTab = 'ct', nq = '', txq = '', txSearch = false, cfFn = null, cfNeed = null, pageName = null, pgTok = 0, theme = 'auto';
try { theme = localStorage.getItem('kb-theme') || 'auto'; } catch {}
let storage = true, demo = false, txTab = 'day', selDay = null, pieMode = 'sum', fresh = '', pieKind = 'income', chartMode = 'line', strukUrl = null, strukCache = null;
let foldSet = new Set();   // kartu dashboard yang ditutup (disimpan di perangkat ini saja)
try { foldSet = new Set(JSON.parse(localStorage.getItem('kb-fold') || '[]')); } catch {}
const isFold = (k) => foldSet.has(k);
const foldBtn = (k, nm) => `<button type="button" class="fold" data-fold="${k}" aria-expanded="${!isFold(k)}" aria-label="Buka atau tutup ${nm}"><span>${isFold(k) ? 'Buka' : 'Tutup'}</span>${ico('chev')}</button>`;
function toggleFold(btn) {
  const k = btn.dataset.fold, tile = btn.closest('.tile'), on = !foldSet.has(k);
  if (on) foldSet.add(k); else foldSet.delete(k);
  try { localStorage.setItem('kb-fold', JSON.stringify([...foldSet])); } catch {}
  tile.classList.toggle('folded', on); btn.setAttribute('aria-expanded', String(!on)); btn.querySelector('span').textContent = on ? 'Buka' : 'Tutup';
}
let openKeys = new Set([`m:${ymd(new Date()).slice(0, 7)}`]);
let mon = { y: new Date().getFullYear(), m: new Date().getMonth() };
let pageArg = {}, pgStack = [], pgSort = 'new', pgLim = 30, trxFilter = 'all', catKind = 'income';
let txKind = 'all', txSt = 'all', txCat = 'all'; // filter tampilan daftar Transaksi (tidak mengubah data)

function toast(m) { const t = $('#toast'); t.textContent = m; t.hidden = false; setTimeout(() => (t.hidden = true), 3500); }

function range(per = period) {
  const t = new Date(), end = today();
  if (per === 'all') return ['0000-01-01', '9999-12-31'];
  if (per === 'day') return [end, end];
  if (per === 'custom' && customRange) return [customRange.a, customRange.b];
  if (per === 'week') { const s = new Date(t); s.setDate(t.getDate() - 6); return [ymd(s), end]; }
  if (per === 'month') return [ymd(new Date(t.getFullYear(), t.getMonth(), 1)), end];
  return [ymd(new Date(t.getFullYear(), 0, 1)), end];
}

const I = {
  up: 'M4 16l5-5 4 4 7-8M15 7h5v5',
  down: 'M4 8l5 5 4-4 7 8M15 17h5v-5',
  box: 'M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10',
  check: 'M5 12l5 5 9-10',
  wallet: 'M4 7h14a2 2 0 012 2v9a2 2 0 01-2 2H4zM4 7l12-3v3M16 13.5h.01',
  bank: 'M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18',
  server: 'M4 5h16v5H4zM4 14h16v5H4zM8 7.5h.01M8 16.5h.01',
  phone: 'M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2',
  plus: 'M12 5v14M5 12h14',
  coin: 'M12 3a9 9 0 100 18 9 9 0 000-18zM9.5 9.8c0-1 1-1.6 2.5-1.6s2.5.6 2.5 1.6-1 1.5-2.5 1.9-2.5.9-2.5 2 1 1.7 2.5 1.7 2.5-.6 2.5-1.6M12 6.8v1.4M12 15.8v1.4',
  clock: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2',
  note: 'M6 3h11a1 1 0 011 1v16a1 1 0 01-1 1H6zM6 3v18M10 8h5M10 12h5M10 16h3',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6',
  copy: 'M9 9h11v11H9zM5 15V4h10',
  search: 'M11 4a7 7 0 100 14 7 7 0 000-14zM20 20l-4-4',
  edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  download: 'M12 4v11M7 11l5 5 5-5M5 20h14',
  upload: 'M12 16V5M7 9l5-5 5 5M5 20h14',
  chat: 'M4 5h16v11H9l-5 4zM8 9h8M8 12h5',
  tag: 'M20.6 13.4l-7.2 7.2a2 2 0 01-2.8 0L3 13V3h10l7.6 7.6a2 2 0 010 2.8zM7.5 7.5h.01',
  swap: 'M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7',
  users: 'M16 20v-1a4 4 0 00-4-4H7a4 4 0 00-4 4v1M9.5 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM21 20v-1a4 4 0 00-3-3.9M16 4.2a3.5 3.5 0 010 6.6',
  clip: 'M20 11.5l-8 8a5 5 0 01-7-7l8.5-8.5a3.5 3.5 0 015 5L10 17.5a2 2 0 01-3-3l7.5-7.5',
  image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9.5h.01',
  scan: 'M4 8V5a1 1 0 011-1h3M16 4h3a1 1 0 011 1v3M20 16v3a1 1 0 01-1 1h-3M8 20H5a1 1 0 01-1-1v-3M4 12h16',
  chev: 'M6 9l6 6 6-6',
  cal: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  share: 'M12 15V3M8 7l4-4 4 4M5 12v8h14v-8',
  target: 'M12 3a9 9 0 100 18 9 9 0 000-18zM12 7.5a4.5 4.5 0 100 9 4.5 4.5 0 000-9zM12 12h.01',
  bolt: 'M13 3L5 14h6l-1 7 8-11h-6z',
  mvTop: 'M5 4h14M12 20V9M6 14l6-6 6 6',
  mvUp: 'M12 19V6M6 11l6-6 6 6',
  mvDown: 'M12 5v13M6 13l6 6 6-6',
  mvBottom: 'M5 20h14M12 4v11M6 10l6 6 6-6',
};
const ico = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${I[k]}"/></svg>`;
const stat = (cls, icon, label, value, hint, pct = null, go = '') => {
  const inner = `<span class="sic">${ico(icon)}</span><small>${label}</small><b>${value}</b><em>${hint}</em>${pct != null ? `<div class="mbar"><i style="width:${pct}%"></i></div>` : ''}`;
  return go ? `<button class="stat ${cls}" ${go}>${inner}</button>` : `<div class="stat ${cls}">${inner}</div>`;
};
const addDays = (v, n) => { const d = new Date(`${v}T00:00:00`); d.setDate(d.getDate() + n); return ymd(d); };
const customDays = () => customRange ? Math.round((Date.parse(`${customRange.b}T00:00:00Z`) - Date.parse(`${customRange.a}T00:00:00Z`)) / 864e5) + 1 : 0;
function fmtRange(a, b) {
  const dmy = (v) => `${+v.slice(8)} ${MON[+v.slice(5, 7) - 1]} ${v.slice(0, 4)}`;
  if (a === b) return dmy(a);
  if (a.slice(0, 7) === b.slice(0, 7)) return `${+a.slice(8)}–${dmy(b)}`;
  if (a.slice(0, 4) === b.slice(0, 4)) return `${+a.slice(8)} ${MON[+a.slice(5, 7) - 1]} – ${dmy(b)}`;
  return `${dmy(a)} – ${dmy(b)}`;
}
const LABEL = { day: 'Hari ini', week: '7 hari terakhir', month: 'Bulan ini', year: 'Tahun ini', all: 'Semua waktu', get custom() { return customRange ? fmtRange(customRange.a, customRange.b) : 'Pilih tanggal'; } };

const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const CHART_LABEL = { day: '7 hari terakhir', week: '7 hari terakhir', month: 'bulan ini', year: 'per bulan', all: '12 bulan terakhir', get custom() { return customDays() > 62 ? 'per bulan' : 'per hari'; } };

function buckets() {
  const t = new Date(), out = [];
  if (period === 'all') return allBuckets();
  if (period === 'custom' && customRange) {
    const { a, b } = customRange;
    if (customDays() <= 62) { for (let d = a; d <= b; d = addDays(d, 1)) out.push({ l: String(+d.slice(8)), a: d, b: d }); }
    else {                                              // rentang panjang: per bulan (bulan pertama / terakhir dipotong sesuai rentang)
      let y = +a.slice(0, 4), m = +a.slice(5, 7) - 1;
      while (ymd(new Date(y, m, 1)) <= b) {
        const s0 = ymd(new Date(y, m, 1)), e0 = ymd(new Date(y, m + 1, 0));
        out.push({ l: MON[m], a: s0 < a ? a : s0, b: e0 > b ? b : e0 });
        if (++m > 11) { m = 0; y++; }
      }
    }
    return out;
  }
  if (period === 'year') {
    for (let m = 0; m < 12; m++) out.push({ l: MON[m], a: ymd(new Date(t.getFullYear(), m, 1)), b: ymd(new Date(t.getFullYear(), m + 1, 0)) });
  } else {
    const n = period === 'month' ? t.getDate() : 7;
    for (let i = n - 1; i >= 0; i--) { const d = new Date(t); d.setDate(t.getDate() - i); out.push({ l: String(d.getDate()), a: ymd(d), b: ymd(d) }); }
  }
  return out;
}

const short = abbrRupiah;
const nice = (v) => { const p = 10 ** Math.floor(Math.log10(v)); return [1, 2, 5, 10].map(x => x * p).find(x => x >= v); };

// Kurva halus yang tidak "melampaui" data (monotone cubic), supaya garis tidak turun di bawah nol.
function smoothPath(pts) {
  const n = pts.length, f = (v) => v.toFixed(1);
  if (n < 2) return n ? `M${f(pts[0][0])} ${f(pts[0][1])}` : '';
  const dx = [], m = [], t = Array(n).fill(0);
  for (let i = 0; i < n - 1; i++) { dx[i] = pts[i + 1][0] - pts[i][0]; m[i] = (pts[i + 1][1] - pts[i][1]) / dx[i]; }
  t[0] = m[0]; t[n - 1] = m[n - 2];
  for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
  for (let i = 0; i < n - 1; i++) {
    if (m[i] === 0) { t[i] = t[i + 1] = 0; continue; }
    const a = t[i] / m[i], b = t[i + 1] / m[i], q = a * a + b * b;
    if (q > 9) { const k = 3 / Math.sqrt(q); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
  }
  let d = `M${f(pts[0][0])} ${f(pts[0][1])}`;
  for (let i = 0; i < n - 1; i++) { const h = dx[i] / 3; d += `C${f(pts[i][0] + h)} ${f(pts[i][1] + t[i] * h)} ${f(pts[i + 1][0] - h)} ${f(pts[i + 1][1] - t[i + 1] * h)} ${f(pts[i + 1][0])} ${f(pts[i + 1][1])}`; }
  return d;
}

const chg = (cur, prev, upGood) => {                   // perubahan terhadap titik sebelumnya: panah + persen
  if (prev == null) return '';
  if (cur === prev) return '<em class="chg flat">sama</em>';
  const up = cur > prev, p = prev > 0 ? Math.round(Math.abs(cur - prev) / prev * 100) : null, good = up === upGood;
  return `<em class="chg ${good ? 'good' : 'bad'}"><svg viewBox="0 0 10 10" aria-hidden="true"><path d="${up ? 'M5 1.5L9 7.5H1z' : 'M5 8.5L1 2.5h8z'}"/></svg>${p === null ? 'baru' : p > 999 ? '>999%' : p + '%'}</em>`;
};
const rdHtml = (l, i, o, pi, po) => {
  const net = i - o, has = pi !== undefined && pi !== null && !Number.isNaN(pi);
  return `<div class="rd-h"><b>${esc(l)}</b><span class="rd-n ${net < 0 ? 'out' : net > 0 ? 'in' : ''}">Selisih ${net < 0 ? '−' : net > 0 ? '+' : ''}${rp(Math.abs(net))}</span></div><div class="rd-g"><span><div class="rl"><i class="b1"></i><small>Pemasukan</small></div><div class="rv"><b class="in">${rp(i)}</b>${has ? chg(i, pi, true) : ''}</div></span><span><div class="rl"><i class="b2"></i><small>Modal + biaya</small></div><div class="rv"><b class="out">${rp(o)}</b>${has ? chg(o, po, false) : ''}</div></span></div>${has ? '<small class="rd-f">▲▼ dibanding sebelumnya</small>' : ''}`;
};
const bucketName = (a, monthly) => monthly ? `${MON_FULL[+a.slice(5, 7) - 1]} ${a.slice(0, 4)}` : `${DAY_FULL[new Date(`${a}T00:00:00`).getDay()]}, ${+a.slice(8)} ${MON[+a.slice(5, 7) - 1]}`;
const DAY_FULL = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

function chart() {
  const data = buckets().map(k => { const p = profitLoss(book, k.a, k.b); return { l: k.l, a: k.a, i: p.revenue, o: p.cogs + p.expense }; });
  const n = data.length, isBar = chartMode === 'bar', top10 = Math.max(10000, ...data.map(d => Math.max(d.i, d.o))), pw10 = 10 ** Math.floor(Math.log10(top10)), mx = [1, 2, 3, 4, 5, 6, 8, 10].map(x => x * pw10).find(x => x >= top10);
  const AX = 46, avail = Math.max(220, Math.min(window.innerWidth, 720) - AX - 76), pw = Math.max(isBar ? 40 : 36, Math.floor(avail / n)), Wp = pw * n;
  const H = 230, top = 50, bot = 30, base = H - bot, y = (v) => base - (v / mx) * (base - top), f1 = (v) => v.toFixed(1);
  const sf = abbrRupiah;
  const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => mx * f);
  const monthly = period === 'year' || period === 'all' || (period === 'custom' && customDays() > 62);
  const cx = (k) => pw * (k + 0.5), step = Math.ceil(n / Math.max(4, Math.floor(Wp / 34)));   // label sumbu-x tidak berdesakan
  const tot = data.reduce((q, d) => ({ i: q.i + d.i, o: q.o + d.o }), { i: 0, o: 0 });
  const best = data.reduce((m, d, k) => d.i > data[m].i ? k : m, 0), low = data.reduce((m, d, k) => d.i < data[m].i ? k : m, 0), unit = monthly ? 'bulan' : 'hari';
  const avg = tot.i / n, ya = y(avg), lowOk = n > 2 && tot.i > 0 && data[low].i < data[best].i;
  const avgEl = n > 1 && avg > 0 ? `<line class="avg" x1="0" x2="${Wp}" y1="${f1(ya)}" y2="${f1(ya)}"/>` : '';
  const grid = ticks.map((v, k) => `<line class="gl${k === 0 ? ' z' : ''}" x1="0" x2="${Wp}" y1="${f1(y(v))}" y2="${f1(y(v))}"/>`).join('');
  const axis = `<svg class="chax" viewBox="0 0 ${AX} ${H}" style="width:${AX}px;height:${H}px" aria-hidden="true">${ticks.map(v => `<text class="ax" x="${AX - 6}" y="${f1(y(v) + 3.5)}" text-anchor="end">${sf(v)}</text>`).join('')}</svg>`;
  const pI = data.map((d, k) => [cx(k), y(d.i)]), pO = data.map((d, k) => [cx(k), y(d.o)]), poly = (pts) => pts.map(p => `${f1(p[0])} ${f1(p[1])}`).join(' L');
  // Kurva halus (monotone cubic): puncak dan lembah membulat, tidak pernah melampaui data sehingga tidak turun di bawah nol.
  const dI = smoothPath(pI), dO = smoothPath(pO);
  const lines = isBar || n < 2 ? '' : `<path class="ar1" d="${dI} L${f1(cx(n - 1))} ${base} L${f1(cx(0))} ${base}Z"/><path class="ln ln2" d="${dO}"/><path class="ln ln1" d="${dI}"/>`;
  const bw = Math.min(16, pw * 0.3), tipW = 118, tipX = (x) => Math.max(2, Math.min(Wp - tipW - 2, x - tipW / 2));
  const groups = data.map((d, k) => {
    const x = cx(k), prev = k > 0 ? data[k - 1] : null, cur = k === n - 1;
    const body = isBar
      ? [[x - bw / 2 - 1.5, d.i, 'b1'], [x + bw / 2 + 1.5, d.o, 'b2']].map(([bx, v, c]) => v > 0 ? `<rect class="${c}" style="animation-delay:${k * 25}ms" x="${f1(bx - bw / 2)}" y="${f1(y(v))}" width="${f1(bw)}" height="${f1(base - y(v))}" rx="2"/>` : `<rect class="${c} zero" x="${f1(bx - bw / 2)}" y="${f1(base - 1.5)}" width="${f1(bw)}" height="1.5"/>`).join('')
      : `<circle class="dt dt2" cx="${f1(x)}" cy="${f1(y(d.o))}" r="3"/><circle class="dt dt1" cx="${f1(x)}" cy="${f1(y(d.i))}" r="3.4"/>`;
    // penanda titik tertinggi / terendah (hanya mode garis)
    const mk = isBar || n < 3 || !(tot.i > 0) ? '' : k === best ? `<g class="mk up"><path d="M${f1(x)} ${f1(y(d.i) - 15)} l-4 6 h8z"/></g>` : lowOk && k === low ? `<g class="mk dn"><path d="M${f1(x)} ${f1(y(d.i) - 9)} l-4 -6 h8z"/></g>` : '';
    const tx = tipX(x), net = d.i - d.o;
    const tip = `<g class="tip"><rect x="${f1(tx)}" y="3" width="${tipW}" height="36" rx="7"/><circle class="tc1" cx="${f1(tx + 11)}" cy="14" r="3.2"/><text class="tt" x="${f1(tx + 19)}" y="17.5">${sf(d.i)}</text><circle class="tc2" cx="${f1(tx + 11)}" cy="29" r="3.2"/><text class="tt" x="${f1(tx + 19)}" y="32.5">${sf(d.o)}</text><text class="tn ${net < 0 ? 'neg' : 'pos'}" x="${f1(tx + tipW - 8)}" y="23.5" text-anchor="end">${net < 0 ? '−' : net > 0 ? '+' : ''}${sf(Math.abs(net))}</text></g>`;
    const lbl = bucketName(d.a, monthly), xl = k % step === 0 || k === n - 1 || cur ? `<text class="ax xl" x="${f1(x)}" y="${H - 11}" text-anchor="middle">${d.l}</text>` : '';
    return `<g class="grp${cur ? ' sel def' : ''}" data-l="${esc(lbl)}" data-i="${Math.round(d.i)}" data-o="${Math.round(d.o)}" data-pi="${prev ? Math.round(prev.i) : ''}" data-po="${prev ? Math.round(prev.o) : ''}"><rect class="hit" x="${f1(x - pw / 2)}" y="0" width="${pw}" height="${H}"/><line class="gd" x1="${f1(x)}" x2="${f1(x)}" y1="${top - 6}" y2="${base}"/>${body}${mk}${xl}${tip}</g>`;
  }).join('');
  const lastD = data[n - 1], prevD = n > 1 ? data[n - 2] : null;
  const stats = tot.i > 0 ? `<div class="chstats"><span>Tertinggi<b>${sf(data[best].i)} · ${data[best].l}</b></span><span>${lowOk ? 'Terendah' : 'Rata-rata / ' + unit}<b>${lowOk ? `${sf(data[low].i)} · ${data[low].l}` : sf(Math.round(tot.i / n))}</b></span><span>Selisih<b class="${tot.i - tot.o < 0 ? 'out' : 'in'}">${tot.i - tot.o < 0 ? '−' : '+'}${sf(Math.abs(tot.i - tot.o))}</b></span></div>` : '';
  const modes = `<div class="mini">${[['line', 'Garis'], ['bar', 'Batang']].map(([k, l]) => `<button data-cm="${k}" class="${chartMode === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const pr = prevRange(period === 'day' ? 'week' : period), prevRev = pr ? profitLoss(book, pr[0], pr[1]).revenue : null;
  const sum = `<div class="chsum"><div><small>Pemasukan</small><b class="in">${rp(tot.i)}</b></div><div><small>Modal + biaya</small><b class="out">${rp(tot.o)}</b></div></div>${pr ? deltaChip(tot.i, prevRev, pr[2]) : ''}`;
  const fs = `Pemasukan <b class="in">${rp(tot.i)}</b> · Modal + biaya <b class="out">${rp(tot.o)}</b>`;
  return `<div class="tile span2 chart ${isBar ? 'isbar' : 'isline'}${isFold('chart') ? ' folded' : ''}"><div class="ph"><div><small>Pemasukan vs pengeluaran</small><small class="sub2">${CHART_LABEL[period]} · dalam rupiah</small></div>${foldBtn('chart', 'grafik')}</div>
    <div class="fsum">${fs}</div><div class="fwrap"><div class="fbody"><div class="mrow">${modes}</div>
    ${sum}
    <div class="chwrap">${axis}<div class="chscroll"><svg viewBox="0 0 ${Wp} ${H}" style="width:${Wp}px;height:${H}px" role="img" aria-label="Grafik pemasukan dan pengeluaran"><defs><linearGradient id="gI" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--in);stop-opacity:.32"/><stop offset="1" style="stop-color:var(--in);stop-opacity:0"/></linearGradient><linearGradient id="gB1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--in)"/><stop offset="1" style="stop-color:var(--in);stop-opacity:.55"/></linearGradient><linearGradient id="gB2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--out)"/><stop offset="1" style="stop-color:var(--out);stop-opacity:.5"/></linearGradient></defs>${grid}${avgEl}${lines}${groups}</svg></div></div>
    <div class="legend"><span><i class="b1"></i>Pemasukan</span><span><i class="b2"></i>Modal + biaya</span>${avgEl ? `<span><i class="lk"></i>Rata-rata ${sf(avg)}</span>` : ''}${!isBar && n > 2 && tot.i > 0 ? '<span class="lm"><svg viewBox="0 0 10 10"><path d="M5 1.5L9 7.5H1z"/></svg>tertinggi' + (lowOk ? '<svg class="d" viewBox="0 0 10 10"><path d="M5 8.5L1 2.5h8z"/></svg>terendah' : '') + '</span>' : ''}</div>
    <div class="readout" aria-live="polite">${rdHtml(bucketName(lastD.a, monthly), lastD.i, lastD.o, prevD ? prevD.i : null, prevD ? prevD.o : null)}</div>
    <small class="chhint">Ketuk satu ${unit} untuk melihat detailnya. Geser bila grafik lebih lebar dari layar.</small></div></div></div>`;
}
function saldoHero() {
  const custom = Object.keys(book.accounts).filter(c => c.startsWith('14'));
  const sum = (cs) => { const on = cs.filter(c => book.accounts[c] && !book.accounts[c].archived); return on.length ? on.reduce((t, c) => t + balance(book, c), 0) : null; };
  const parts = [['Tunai', sum(['1101']), 'c1'], ['Bank', sum(['1102']), 'c2'], ['Deposit', sum(['1201', '1202']), 'c3'], ['E-wallet', sum(['1203']), 'c4'],
    ['Lainnya', custom.length ? sum(custom) : null, 'c5']].filter(x => x[1] !== null);
  const total = parts.reduce((s, p) => s + p[1], 0);
  return `<div class="tile hero span2"><div><small>Total saldo</small><b>${rp(total)}</b></div>
    <div class="stack">${parts.map(([, v, c]) => `<i class="${c}" style="flex:${Math.max(0, v)}"></i>`).join('')}</div>
    <div class="legend">${parts.map(([l, v, c]) => `<span><i class="${c}"></i>${l}${total > 0 ? `<u>${Math.round(Math.max(0, v) / total * 100)}%</u>` : ''}<em>${rp(v)}</em></span>`).join('')}</div></div>`;
}

const pct1 = (x) => (Math.round(x * 10) / 10).toLocaleString('id-ID');
function prevRange(per = period) {
  const t = new Date(), mk = (y, m, d) => ymd(new Date(y, m, d));
  if (per === 'day') { const y = mk(t.getFullYear(), t.getMonth(), t.getDate() - 1); return [y, y, 'kemarin']; }
  if (per === 'week') return [mk(t.getFullYear(), t.getMonth(), t.getDate() - 13), mk(t.getFullYear(), t.getMonth(), t.getDate() - 7), '7 hari sebelumnya'];
  if (per === 'month') { const last = new Date(t.getFullYear(), t.getMonth(), 0).getDate(); return [mk(t.getFullYear(), t.getMonth() - 1, 1), mk(t.getFullYear(), t.getMonth() - 1, Math.min(t.getDate(), last)), 'bulan lalu']; }
  if (per === 'year') return [mk(t.getFullYear() - 1, 0, 1), mk(t.getFullYear() - 1, t.getMonth(), t.getDate()), 'tahun lalu'];
  if (per === 'custom' && customRange) { const L = customDays(); return [addDays(customRange.a, -L), addDays(customRange.a, -1), L === 1 ? 'hari sebelumnya' : 'periode sebelumnya']; }
  return null;
}
function deltaChip(cur, prev, label, neutral = false) {
  if (prev === 0) return cur === 0 ? '' : `<span class="dchip">Belum ada data ${label}</span>`;
  const d = Math.round((cur - prev) / Math.abs(prev) * 100);
  return `<span class="dchip ${neutral ? '' : d > 0 ? 'up' : d < 0 ? 'dn' : ''}">${d > 0 ? '▲' : d < 0 ? '▼' : '•'} ${Math.abs(d)}% vs ${label}</span>`;
}

// Kartu untung bersih + bar komposisi omzet (modal / biaya / untung) + pembanding periode sebelumnya.
function gauge(m) {   // busur 270° margin untung (0–100% dari omzet); warna: merah rugi, kuning tipis, hijau sehat
  const v = Math.max(0, Math.min(100, m)), C = 2 * Math.PI * 40, arc = C * 0.75, tone = m < 0 ? 'neg' : m < 10 ? 'mid' : 'ok';
  const ticks = [0, 25, 50, 75, 100].map(t => { const an = (135 + t * 2.7) * Math.PI / 180; return `<line x1="${(50 + 31 * Math.cos(an)).toFixed(1)}" y1="${(50 + 31 * Math.sin(an)).toFixed(1)}" x2="${(50 + 34 * Math.cos(an)).toFixed(1)}" y2="${(50 + 34 * Math.sin(an)).toFixed(1)}"/>`; }).join('');
  return `<svg class="gauge ${tone}" viewBox="0 0 100 100" role="img" aria-label="Margin ${pct1(m)}%"><defs><linearGradient id="gg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" style="stop-color:var(--g1)"/><stop offset="1" style="stop-color:var(--g2)"/></linearGradient></defs>
    <circle class="gt" cx="50" cy="50" r="40" stroke-dasharray="${arc.toFixed(1)} ${C.toFixed(1)}" transform="rotate(135 50 50)"/>
    ${v > 0 ? `<circle class="gv" cx="50" cy="50" r="40" stroke-dasharray="${(arc * v / 100).toFixed(1)} ${C.toFixed(1)}" transform="rotate(135 50 50)"/>` : ''}
    <g class="gk">${ticks}</g><text x="50" y="52" text-anchor="middle" class="gn">${pct1(m)}%</text><text x="50" y="65" text-anchor="middle" class="gl2">margin untung</text></svg>`;
}
function profitCard(p, count) {
  const pr = prevRange(), dl = pr ? deltaChip(p.net, profitLoss(book, pr[0], pr[1]).net, pr[2]) : '';
  const den = Math.max(1, p.revenue, p.cogs + p.expense), w = (v) => (Math.max(0, v) / den * 100).toFixed(2);
  const margin = p.revenue > 0 ? `Margin ${pct1(p.net / p.revenue * 100)}% · ` : '';
  const lg = (c, l, v) => `<span><label><i class="${c}"></i>${l}<u>${Math.round(w(v))}%</u></label><em>${rp(v)}</em></span>`;
  return `<div class="pcard ${p.net < 0 ? 'loss' : ''}" data-metric="net" role="button" tabindex="0"><div class="ph1"><small>Untung bersih · ${LABEL[period]}</small>${dl}</div>
    <div class="pgrow"><div class="pgl"><b class="big">${rp(p.net)}</b><div class="sub">${count} transaksi berhasil</div></div>${gauge(p.revenue > 0 ? p.net / p.revenue * 100 : 0)}</div>
    <div class="sbar" role="img" aria-label="Komposisi omzet">${[['sg-m', p.cogs], ['sg-b', p.expense], ['sg-n', p.net]].filter(x => x[1] > 0).map(([c, v]) => `<i class="${c}" style="width:${w(v)}%"></i>`).join('')}</div>
    <div class="slg">${lg('sg-m', 'Modal', p.cogs)}${lg('sg-b', 'Biaya', p.expense)}${lg('sg-n', 'Untung', p.net)}</div><span class="more">Ketuk untuk rincian ›</span></div>`;
}

// Aktivitas terbaru di Dashboard: 5 transaksi terakhir (hanya tampilan, memakai txItem yang sama dengan tab Transaksi).
function recentBlock() {
  // transaksi + saldo/modal yang ditambahkan (bukan saldo awal), diurut menurut tanggal dan jam; modal lama tanpa jam tampil di bawah transaksi hari itu
  const rows = [...live().map(t => ({ t, date: t.date, time: t.time ?? '', id: t.id })), ...balanceHistory(book).filter(h => !h.awal && !h.reversed).map(h => ({ h, date: h.date, time: h.time, id: h.id }))]
    .sort((x, y) => y.date.localeCompare(x.date) || y.time.localeCompare(x.time) || y.id.localeCompare(x.id)).slice(0, 6);
  return `<div class="sec-h"><h3>Aktivitas terbaru</h3>${rows.length ? '<button class="link" data-v="tx">Lihat semua</button>' : ''}</div>
    ${rows.length ? `<div class="items">${rows.map(r => r.h ? hrow(r.h, true) : txItem(r.t)).join('')}</div>` : '<p class="empty">Belum ada transaksi.</p>'}`;
}

// ---------- Target bulanan (kartu di Dashboard) ----------
function goalCard() {
  const g = goalProgress(book, today());
  if (!g) return `<button class="tile span2 goal nogoal" data-page="settings" data-goalfocus="1"><span class="ic">${ico('target')}</span><span class="gtx"><b>Atur target bulanan</b><small>Pantau progres, kebutuhan harian, dan proyeksi akhir bulan</small></span><i class="chev">›</i></button>`;
  const lab = g.kind === 'net' ? 'Untung bersih' : 'Omzet', pace = Math.round(g.day / g.days * 100);
  const st = { tercapai: ['Tercapai 🎉', 'ok'], jalur: ['Di jalur', 'ok'], kejar: ['Perlu dikejar', 'warn'] }[g.status];
  const foot = g.status === 'tercapai' ? `Target bulan ini sudah terlewati ${rp(g.done - g.target)}` : `Sisa ${rp(g.left)} · ${g.daysLeft > 0 ? `${g.daysLeft} hari lagi` : 'hari terakhir'}`;
  return `<button type="button" class="tile span2 goal ${g.status}" data-page="settings" data-goalfocus="1" aria-label="Target bulanan, ketuk untuk mengubah">
    <div class="gh"><span class="gt">${ico('target')}Target ${lab.toLowerCase()}</span><span class="gs ${st[1]}">${st[0]}</span></div>
    <div class="gnum"><b>${rp(g.done)}</b><small>dari ${rp(g.target)}</small><em>${g.pct}%</em></div>
    <div class="gbar" role="progressbar" aria-valuenow="${g.pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${g.pct}%"></i><u style="left:${pace}%" title="Posisi ideal hari ini"></u></div>
    <div class="gf"><span>${foot}</span></div>
    ${g.status === 'tercapai' ? '' : `<div class="gx"><div><small>Butuh per hari</small><b>${rp(g.perDay)}</b></div><div><small>Proyeksi akhir bulan</small><b class="${g.status === 'jalur' ? 'pos' : 'warn'}">${rp(g.projected)}</b></div></div>`}</button>`;
}

// ---------- Jam ramai ----------
const hrRng = (i) => `${String(i).padStart(2, '0')}.00–${String(i).padStart(2, '0')}.59`;
const rpShort = (v) => v >= 1e7 ? `Rp${abbrRupiah(v)}` : rp(v);
const hrRead = (i, n, rev, total) => `<div class="hv-rt"><b>${hrRng(i)}</b><small>${n ? `${n} penjualan · ${Math.round(n / total * 100)}% dari total` : 'Belum ada penjualan'}</small></div>${n ? `<strong>${rpShort(rev)}</strong>` : ''}`;
function selHr(btn) {   // ketuk / geser di atas batang jam → ringkasan jam itu (tanpa menggambar ulang)
  const card = btn.closest('.hourly'); if (!card) return;
  card.querySelectorAll('.hv-c.sel, .hv-x .on').forEach(e => e.classList.remove('sel', 'on'));
  btn.classList.add('sel'); card.querySelector(`.hv-x [data-i="${btn.dataset.hr}"]`)?.classList.add('on');
  card.querySelector('.hv-read').innerHTML = hrRead(+btn.dataset.hr, +btn.dataset.n, +btn.dataset.rev, +card.dataset.total);
}
let hvDown = false;
document.addEventListener('pointerdown', e => { hvDown = !!e.target.closest?.('.hv-bars'); }, true);
['pointerup', 'pointercancel'].forEach(t => document.addEventListener(t, () => { hvDown = false; }, true));
document.addEventListener('pointermove', e => {   // geser jari menelusuri jam satu per satu
  if (!hvDown) return;
  const bars = e.target.closest?.('.hv-bars'); if (!bars) return;
  const r = bars.getBoundingClientRect(), cols = bars.children, k = Math.max(0, Math.min(cols.length - 1, Math.floor((e.clientX - r.left) / r.width * cols.length)));
  if (!cols[k].classList.contains('sel')) selHr(cols[k]);
});
const DAY_PARTS = [['Dini hari', 0, 4, 'var(--mut)'], ['Pagi', 5, 10, '#f5a524'], ['Siang', 11, 14, 'var(--brand)'], ['Sore', 15, 17, 'var(--tr)'], ['Malam', 18, 23, 'var(--in)']];
function hourly() {
  const [a, b] = range(), h = hourHistogram(book, a, b);
  if (!h.total) return '';
  const hs = h.hours, first = hs.findIndex(x => x.n), last = hs.map(x => x.n > 0).lastIndexOf(true);
  const lo = Math.min(7, first), hi = Math.max(21, last), c = hi - lo + 1, mx = hs[h.peak].n, pk = hs[h.peak], ph = (i) => String(i).padStart(2, '0');
  const ties = hs.filter(x => x.n === mx).length, share = Math.round(mx / h.total * 100), active = hs.filter(x => x.n > 0).length;
  const nice = (v) => { if (v <= 4) return v; const p = 10 ** Math.floor(Math.log10(v)), m = [1, 1.2, 1.6, 2, 2.4, 3, 4, 5, 6, 8, 10].find(x => x * p >= v); return Math.round(m * p); };   // puncak sumbu rapat ke data, tapi tetap angka bulat
  const ytop = nice(mx), ticks = ytop % 2 === 0 && ytop > 2 ? [ytop, ytop / 2, 0] : [ytop, 0];
  let cols = '', xs = '';
  for (let i = lo; i <= hi; i++) {
    const x = hs[i], pct = x.n ? Math.max(6, Math.round(x.n / ytop * 100)) : 0, tone = x.n ? Math.round(28 + x.n / mx * 42) : 0, isPk = x.n > 0 && x.n === mx;
    cols += `<button type="button" class="hv-c${isPk ? ' pk' : ''}${x.n ? '' : ' z'}${i === h.peak ? ' sel' : ''}" style="--h:${pct}%;--t:${tone}%;--i:${i - lo}" data-hr="${i}" data-n="${x.n}" data-rev="${x.rev}" aria-label="${hrRng(i)}, ${x.n} penjualan"><u class="hv-v">${x.n}</u><span class="hv-b"></span></button>`;
    xs += `<span data-i="${i}"${i === h.peak ? ' class="on"' : ''}>${i % 3 === 0 ? ph(i) : ''}</span>`;
  }
  const parts = DAY_PARTS.map(([nm, s0, e0, col]) => ({ nm, col, s0, e0, n: hs.slice(s0, e0 + 1).reduce((q, x) => q + x.n, 0) }));
  const rail = parts.map(x => { const s = Math.max(lo, x.s0), e = Math.min(hi, x.e0); return s > e ? '' : `<i style="grid-column:${s - lo + 1}/${e - lo + 2};--pc:${x.col}"></i>`; }).join('');
  const used = parts.filter(x => x.n > 0);
  // jendela 2 jam paling sepi di rentang jam buka: saran waktu isi deposit / belanja stok
  let quiet = null, busiest = 0;
  if (c >= 6 && h.total >= 4) {
    for (let i = lo; i < hi; i++) { const sm = hs[i].n + hs[i + 1].n; busiest = Math.max(busiest, sm); if (!quiet || sm < quiet.sm) quiet = { i, sm }; }
    if (quiet && quiet.sm >= busiest) quiet = null;
  }
  return `<div class="tile span2 hourly hz${isFold('hourly') ? ' folded' : ''}" data-total="${h.total}"><div class="ph"><div><small>Jam ramai</small><small class="sub2">${LABEL[period]} · ${h.total} penjualan</small></div>${foldBtn('hourly', 'jam ramai')}</div>
    <div class="fsum">Paling ramai <b>${hrRng(h.peak)}</b> · ${mx} penjualan (${share}%)</div>
    <div class="fwrap"><div class="fbody">
      <div class="hv-hero"><div class="hv-time"><b>${ph(h.peak)}.00<i>–${ph(h.peak)}.59</i></b>${ties > 1 ? `<em>+${ties - 1} jam lain sama ramai</em>` : `<em>${mx} penjualan di jam ini</em>`}</div>
        <div class="hv-ring" role="img" aria-label="${share}% dari seluruh penjualan"><svg viewBox="0 0 84 84" aria-hidden="true"><defs><linearGradient id="hvg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff8a8f"/><stop offset="1" stop-color="var(--brand)"/></linearGradient></defs><circle class="hv-rt0" cx="42" cy="42" r="34"/><circle class="hv-rp" cx="42" cy="42" r="34" style="--len:${(Math.max(share, 1) / 100 * 213.63).toFixed(1)}"/></svg><div><b>${share}<small>%</small></b><span>dari total</span></div></div></div>
      <div class="hv-stats"><div><small>Penjualan</small><b>${mx}</b></div><div><small>Omzet jam ini</small><b>${rpShort(pk.rev)}</b></div><div><small>Jam aktif</small><b>${active} jam</b></div></div>
      <div class="hv-plot"><div class="hv-area" style="--c:${c}">
        <div class="hv-yl">${ticks.map(t => `<span style="bottom:${t / ytop * 100}%">${t}</span>`).join('')}</div>
        <div class="hv-gl">${ticks.map(t => `<i style="bottom:${t / ytop * 100}%"></i>`).join('')}</div>
        <div class="hv-bars" role="group" aria-label="Penjualan per jam, ketuk atau geser untuk rincian">${cols}</div></div>
        <div class="hv-x" style="--c:${c}">${xs}</div><div class="hv-rail" style="--c:${c}">${rail}</div></div>
      <div class="hv-read" aria-live="polite">${hrRead(h.peak, pk.n, pk.rev, h.total)}</div>
      <p class="hv-h">Bagian hari</p>
      <div class="hv-split" role="img" aria-label="Pembagian penjualan menurut bagian hari">${used.map(x => `<i style="flex:${x.n};--pc:${x.col}"></i>`).join('')}</div>
      <div class="hv-leg">${used.map(x => `<div style="--pc:${x.col}"><i></i><span>${x.nm}<small>${ph(x.s0)}–${ph(x.e0)}</small></span><b>${Math.round(x.n / h.total * 100)}%</b></div>`).join('')}</div>
      ${quiet ? `<div class="hv-tip"><span>${ico('clock')}</span><div><b>Paling sepi ${ph(quiet.i)}.00–${ph(quiet.i + 1)}.59</b><small>${quiet.sm ? `Hanya ${quiet.sm} penjualan` : 'Tanpa penjualan'} · waktu pas untuk isi deposit atau belanja stok</small></div></div>` : ''}
    </div></div></div>`;
}

// ---------- Rekap untuk dibagikan ----------
let recapTxt = '';
function openRecap() {
  const [a, b] = range(), debts = piutangList();
  recapTxt = recapText(book, a, b, { label: period === 'custom' ? 'Periode pilihan' : LABEL[period], shop: book.settings.shop, owed: { n: debts.length, sum: debts.reduce((x, t) => x + t.price, 0) } });
  const s = SHEET_BOTTOM();
  s.innerHTML = `<div class="box"><div class="dh"><h3>Rekap ${esc(period === 'custom' ? 'periode pilihan' : LABEL[period].toLowerCase())}</h3></div>
    <pre class="recap">${esc(recapTxt)}</pre>
    <div class="acts rc-acts">${navigator.share ? `<button class="primary" data-rcshare="1">${ico('share')} Bagikan</button>` : ''}<button data-rccopy="1" class="${navigator.share ? '' : 'primary'}">${ico('copy')} Salin</button><a class="btn wa" href="https://wa.me/?text=${encodeURIComponent(recapTxt)}" target="_blank" rel="noopener">${ico('chat')} WhatsApp</a><button class="${navigator.share ? 'rc-full' : ''}" data-x="1">Tutup</button></div></div>`;
}

function home() {
  const [a, b] = range(), p = profitLoss(book, a, b);
  const tx = live().filter(x => x.date >= a && x.date <= b);
  const n = (...s) => tx.filter(x => s.includes(x.status)).length;
  const share = (v) => p.revenue > 0 ? Math.max(0, Math.min(100, Math.round(v / p.revenue * 100))) : 0;
  const debts = piutangList(), owed = debts.length, owedSum = debts.reduce((x, t) => x + t.price, 0);
  const omzetHint = book.settings.basis === 'lunas' ? (owedSum ? `Belum termasuk piutang ${rp(owedSum)}` : 'Penjualan yang sudah lunas') : 'Total penjualan';
  return `${emptyHint()}<div class="bento">${saldoHero()}</div>
  ${periodPick(true)}
  <div class="bento">${profitCard(p, n('berhasil'))}</div>
  <div class="bento">${goalCard()}</div>
  <div class="stats">
    ${stat('', 'up', 'Omzet', rp(p.revenue), omzetHint, null, 'data-metric="omzet"')}
    ${stat('g', 'coin', 'Untung kotor', rp(p.gross), `${share(p.gross)}% dari omzet`, share(p.gross), 'data-metric="gross"')}
    ${stat('n', 'box', 'Modal', rp(p.cogs), `${share(p.cogs)}% dari omzet`, share(p.cogs), 'data-metric="modal"')}
    ${stat('r', 'down', 'Pengeluaran', rp(p.expense), 'Biaya + operasional', share(p.expense), 'data-metric="biaya"')}
    ${stat('n', 'check', 'Transaksi', `${n('berhasil')} / ${n('gagal', 'dibatalkan')}`, 'berhasil / gagal', null, 'data-metric="trx"')}
    ${stat('a', 'clock', 'Total piutang', rp(owedSum), owed ? `${owed} belum bayar · ketuk` : 'Semua sudah bayar', null, 'data-page="piutang"')}
  </div>
  <div class="bento duo">${chart()}${pie()}</div>
  <div class="bento">${hourly()}</div>
  <div class="sec-h"><h3>Menu cepat</h3></div>
  <div class="qm">
    <button class="qm-i" data-new="1"><span class="ic">${ico('plus')}</span><b>Transaksi baru</b></button>
    <button class="qm-i cap" data-newsaldo="1"><span class="ic">${ico('wallet')}</span><b>Tambah modal</b></button>
    <button class="qm-i" data-v="notes"><span class="ic">${ico('users')}</span><b>Catatan</b></button>
    <button class="qm-i" data-page="piutang"><span class="ic">${ico('clock')}</span><b>Piutang</b></button>
    <button class="qm-i" data-page="kategori"><span class="ic">${ico('tag')}</span><b>Kategori</b></button>
    <button class="qm-i" data-page="saldohist"><span class="ic">${ico('clock')}</span><b>Riwayat modal</b></button>
  </div>
  ${recentBlock()}`;
}

const pick = (name, items, sel) => `<div class="pick"><input type="hidden" name="${name}" value="${esc(sel)}">${items.map(([v, l]) =>
  `<button type="button" data-pick="${esc(v)}" class="${v === sel ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;
const accOpts = (codes) => codes.map(c => [c, book.accounts[c].name]);
const ACC_ICON = { 1101: 'wallet', 1102: 'bank', 1201: 'server', 1202: 'server', 1203: 'phone', 1301: 'box' };
const ACC_KIND = { 1101: 'cash', 1102: 'bank', 1201: 'dep', 1202: 'dep', 1203: 'ewallet' }; // hanya untuk warna ikon akun

const MON_FULL = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const DAY = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
// Nama akun: bawaan dari ACCOUNT_SHORT, akun kustom dari buku.
const SHORT = new Proxy(ACCOUNT_SHORT, { get: (o, k) => o[k] ?? book?.accounts?.[k]?.name });
const KIND = { income: 'Pendapatan', expense: 'Pengeluaran', transfer: 'Transfer' };
const LBL = { price: 'Total', cost: 'Modal', fee: 'Biaya' };
const lbl = (f) => f === 'fee' && draft?.kind === 'transfer' ? 'Pajak' : LBL[f];
const trxNo = (t) => `TRX-${t.id.slice(3)}`;   // nomor transaksi yang tampil; bisa dicari
const KEYS = [['1', '1'], ['2', '2'], ['3', '3'], ['back', '⌫', 'k-alt'], ['4', '4'], ['5', '5'], ['6', '6'], ['calc', '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/></svg>', 'k-alt'],
  ['7', '7'], ['8', '8'], ['9', '9'], ['done', 'Selesai', 'k-done'], ['clear', 'C', 'k-alt'], ['0', '0'], ['000', '000']];
const aset = (codes) => codes.map(c => [c, SHORT[c]]);

let tok = 0;
const nowHM = () => new Date().toTimeString().slice(0, 5);
const inOut = (a, b) => { const p = profitLoss(book, a, b); return { i: p.revenue, o: p.cogs + p.expense, n: p.net }; };
const sumRow = (x) => `<div class="sum"><div><small>Pendapatan</small><b class="in">${rp(x.i)}</b></div><div><small>Pengeluaran</small><b class="out">${rp(x.o)}</b></div><div><small>Total</small><b>${rp(x.n)}</b></div></div>`;
const daysOf = (a, b) => [...new Set(live().filter(t => t.date >= a && t.date <= b).map(t => t.date))].sort().reverse();

const inRange = (t, a, b) => { const d = recognizedDate(book, t); return d !== null && d >= a && d <= b; };
const catColor = (n) => PIE_COL[[...String(n)].reduce((s, c) => s + c.charCodeAt(0), 0) % PIE_COL.length];
const fmtDay = (d) => new Date(`${d}T00:00:00`).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });

function txItem(t) {
  const dead = ['gagal', 'dibatalkan', 'refund'].includes(t.status);
  const cls = { income: 'in', expense: 'out', transfer: 'tr' }[t.kind];
  const open = t.kind === 'income' && ['pending', 'berhasil'].includes(t.status), unpaid = open && t.paid === false;
  const sub = `#${+t.id.slice(3)} · ` + (t.time ? `${t.time} · ` : '') + (t.kind === 'transfer' ? `${SHORT[t.source]} → ${SHORT[t.method]}` : unpaid ? 'Piutang' : SHORT[t.method]) +
    (t.status === 'berhasil' ? '' : ` <em class="st ${t.status}">${t.status}</em>`) + (filesOf(t).length ? ` <em class="clip">${ico('clip')}${filesOf(t).length}</em>` : '');
  const gain = t.kind === 'income' && t.cost > 0 ? `<small>untung ${rp(t.price - t.cost - t.fee)}</small>` : '';
  const chip = open ? `<button class="chip ${unpaid ? 'belum' : 'lunas'}" data-pay="${t.id}">${unpaid ? 'Belum bayar' : '✓ Lunas'}</button>` : '';
  return `<div class="item ${dead ? 'dead' : ''} k-${cls}" role="button" tabindex="0" data-open="${t.id}"><i class="ck" aria-hidden="true"></i><i class="ki" aria-hidden="true"></i>
    <span class="mid"><b>${esc(t.product)}</b><small class="sub"><span class="cat" style="--cc:${catColor(t.category)}">${esc(t.category)}</span><span>${sub}</span></small>${t.target ? `<button class="tgcopy" data-copy="${esc(t.target)}" aria-label="Salin nomor">${esc(t.target)}${ico('copy')}</button>` : ''}</span><span class="amt ${cls}">${rp(t.price)}${gain}${chip}</span><i class="grip" aria-hidden="true" title="Seret untuk mengurutkan"></i></div>`;
}

// Filter tampilan (jenis / status / kategori). Hanya menyaring baris yang ditampilkan; angka ringkasan tetap dari jurnal.
const filterOn = () => txKind !== 'all' || txSt !== 'all' || txCat !== 'all';
function passTx(t) {
  if (txKind !== 'all' && t.kind !== txKind) return false;
  if (txCat !== 'all' && t.category !== txCat) return false;
  if (txSt === 'all') return true;
  const open = t.kind === 'income' && ['pending', 'berhasil'].includes(t.status);
  if (txSt === 'unpaid') return open && t.paid === false;
  if (txSt === 'paid') return open && t.paid !== false;
  return t.status === txSt;
}
const dayHas = (d) => !filterOn() || live().some(t => t.date === d && passTx(t));

function dayBlock(d, only = null) {
  const dt = new Date(`${d}T00:00:00`), x = inOut(d, d);
  const rows = (only ?? live().filter(t => t.date === d)).filter(passTx).sort(txOrder);
  return `<div class="day"><span class="dn">${dt.getDate()}</span><i class="wd">${DAY[dt.getDay()]}</i><small>${d.slice(5, 7)}.${d.slice(0, 4)}</small>
    <b class="in">${rp(x.i)}</b><b class="out">${rp(x.o)}</b></div>
    ${rows.length ? `<div class="items">${rows.map(txItem).join('')}</div>` : `<p class="empty">${filterOn() ? 'Tidak ada transaksi yang cocok dengan filter.' : 'Tidak ada transaksi.'}</p>`}`;
}

const dayView = (key) => daysOf(`${key}-01`, `${key}-31`).filter(dayHas).map(d => dayBlock(d)).join('') || '<p class="empty">Belum ada transaksi bulan ini.</p>';

function calView(key) {
  const { y, m } = mon, first = new Date(y, m, 1).getDay(), n = new Date(y, m + 1, 0).getDate(), t0 = today();
  const sel = selDay ?? (key === t0.slice(0, 7) ? t0 : null);
  const cells = Array(first).fill('<span class="cc off"></span>');
  for (let d = 1; d <= n; d++) {
    const ds = `${key}-${String(d).padStart(2, '0')}`, x = inOut(ds, ds);
    cells.push(`<button class="cc ${ds === t0 ? 'now' : ''} ${ds === sel ? 'on' : ''}" data-day="${ds}"><b>${d}</b>${x.i > 0 ? `<em class="in">${short(x.i)}</em>` : ''}${x.o > 0 ? `<em class="out">${short(x.o)}</em>` : ''}</button>`);
  }
  return `<div class="cal"><div class="cw">${DAY.map(x => `<span>${x}</span>`).join('')}</div><div class="cg">${cells.join('')}</div></div>
    ${sel && sel.startsWith(key) ? dayBlock(sel) : '<p class="empty">Ketuk tanggal untuk melihat transaksinya.</p>'}`;
}

function weeksOf(y, m, endD, isFresh) {
  const pad = (n) => String(n).padStart(2, '0'), out = [];
  for (let d = 1; d <= endD;) {
    const e = Math.min(endD, d + (6 - new Date(y, m, d).getDay()));
    const from = `${y}-${pad(m + 1)}-${pad(d)}`, to = `${y}-${pad(m + 1)}-${pad(e)}`, x = inOut(from, to), wk = `w:${from}`, isOpen = openKeys.has(wk);
    out.push(`<div class="wgroup"><button class="wrow" data-tg="${wk}"><span>${pad(d)}.${pad(m + 1)} ~ ${pad(e)}.${pad(m + 1)}</span>
      <span class="mv"><b class="in">${rp(x.i)}</b><b class="out">${rp(x.o)}</b><small>${rp(x.n)}</small></span></button>
      ${isOpen ? `<div class="wbody ${fresh === wk ? 'fresh' : ''}">${daysOf(from, to).filter(dayHas).map(dd => dayBlock(dd)).join('') || '<p class="empty">Tidak ada transaksi.</p>'}</div>` : ''}</div>`);
    d = e + 1;
  }
  return `<div class="weeks ${isFresh ? 'fresh' : ''}">${out.reverse().join('')}</div>`;
}

function monthView() {
  const y = mon.y, now = new Date(), last = y === now.getFullYear() ? now.getMonth() : 11, rows = [];
  for (let m = last; m >= 0; m--) {
    const mm = String(m + 1).padStart(2, '0'), key = `${y}-${mm}`, endD = new Date(y, m + 1, 0).getDate();
    const x = inOut(`${key}-01`, `${key}-${endD}`), isOpen = openKeys.has(`m:${key}`);
    rows.push(`<div class="mgroup ${isOpen ? 'open' : ''}"><button class="mrow" data-tg="m:${key}"><span class="mn"><b>${MON[m]}</b><small>01.${mm} ~ ${endD}.${mm}</small></span>
      <span class="mv"><b class="in">${rp(x.i)}</b><b class="out">${rp(x.o)}</b><small>${rp(x.n)}</small></span><i class="chev">›</i></button>
      ${isOpen ? weeksOf(y, m, endD, fresh === `m:${key}`) : ''}</div>`);
  }
  return rows.join('');
}

function txBody() {
  const q = txq.trim().toLowerCase();
  if (q) {
    // Cari lewat nomor transaksi (trx-2, trx 0002, #2), nama, nomor / ID, jenis, status, "belum bayar", akun, jam, tanggal, nominal, catatan, atau teks gambar.
    const k = numKey(q), tm = q.match(/^(?:trx|tx|#)[\s\-#]*0*(\d+)$/), tn = tm ? Number(tm[1]) : null;
    const hay = (t) => `${t.product} ${t.category} ${t.target} ${t.note} ${itemsLine(t.items)} ${t.price} ${t.date} ${t.time ?? ''} ${KIND[t.kind]} ${t.status} ${SHORT[t.method] ?? ''} ${t.kind === 'income' && t.paid === false && ['pending', 'berhasil'].includes(t.status) ? 'belum bayar piutang' : ''} ${fileText(t)} ${trxNo(t)} ${t.id}`.toLowerCase();
    const hit = live().filter(passTx).filter(t => (tn !== null && +t.id.slice(3) === tn) || hay(t).includes(q) || (k.length >= 3 && numKey(t.target).includes(k)))
      .sort(txOrder);
    const days = [...new Set(hit.map(t => t.date))].slice(0, 60);
    return `<p class="rescount">${hit.length} hasil</p>` + (days.map(d => dayBlock(d, hit.filter(t => t.date === d))).join('') || '<p class="empty">Tidak ada transaksi yang cocok.</p>');
  }
  const { y, m } = mon, key = `${y}-${String(m + 1).padStart(2, '0')}`, isMonth = txTab === 'month';
  const nav = isMonth
    ? `<div class="mnav"><button data-yr="-1" aria-label="Tahun sebelumnya">‹</button><b>${y}</b><button data-yr="1" aria-label="Tahun berikutnya">›</button></div>`
    : `<div class="mnav"><button data-mo="-1" aria-label="Bulan sebelumnya">‹</button><b>${MON_FULL[m]} ${y}</b><button data-mo="1" aria-label="Bulan berikutnya">›</button></div>`;
  const tabs = [['day', 'Harian'], ['cal', 'Kalender'], ['month', 'Bulanan']];
  const x = isMonth ? inOut(`${y}-01-01`, `${y}-12-31`) : inOut(`${key}-01`, `${key}-31`);
  const body = txTab === 'day' ? dayView(key) : txTab === 'cal' ? calView(key) : monthView();
  return `${nav}<div class="tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${txTab === k ? 'on' : ''}">${l}</button>`).join('')}<i style="--i:${tabs.findIndex(t => t[0] === txTab)}"></i></div>
    ${sumRow(x)}${body}`;
}

const ST_OPT = [['all', 'Semua status'], ['berhasil', 'Berhasil'], ['pending', 'Pending'], ['gagal', 'Gagal'], ['dibatalkan', 'Dibatalkan'], ['refund', 'Refund'], ['paid', 'Sudah bayar'], ['unpaid', 'Belum bayar']];
const txCats = () => {
  const cats = [...new Set(live().map(t => t.category))].sort((a, b) => a.localeCompare(b, 'id'));
  if (txCat !== 'all' && !cats.includes(txCat)) cats.push(txCat);
  return cats;
};
function filterBar() {
  const kinds = [['all', 'Semua'], ...Object.entries(KIND)];
  const fdd = (k, label, val, on, opts, cur, cls = '') => `<div class="pdd fdd ${cls}"><button type="button" class="fbtn ${on ? 'act' : ''}" data-pdd="1" aria-haspopup="listbox" aria-expanded="false"><span>${label}</span><b>${esc(val)}</b>${ico('chev')}</button><div class="pdd-menu" role="listbox" aria-label="${label}">${opts.map(([v, l, sub], i) => `<button type="button" role="option" aria-selected="${v === cur}" data-fk="${k}" data-fv="${esc(v)}" class="pdd-opt ${v === cur ? 'on' : ''}" style="--i:${Math.min(i, 8)}"><span class="po-t"><b>${esc(l)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span><i class="po-ck">${ico('check')}</i></button>`).join('')}</div></div>`;
  const catOpts = [['all', 'Semua kategori'], ...txCats().map(c => [c, c, `${live().filter(t => t.category === c).length} transaksi`])];
  const sOn = !!txq || txSearch;
  return `<div class="filters"><div class="frow"><button type="button" class="sico ${sOn ? 'on' : ''}" data-txs="1" aria-label="Cari transaksi" aria-expanded="${sOn}">${ico('search')}</button><div class="fchips" role="group" aria-label="Jenis transaksi">${kinds.map(([k, l]) => `<button data-txk="${k}" class="${txKind === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
    <div class="sbx ${sOn ? 'open' : ''}"><div class="sbi"><div class="search">${ico('search')}<input id="txq" type="search" placeholder="Cari ID (TRX-…), nama, nomor…" value="${esc(txq)}" autocomplete="off" enterkeyhint="search"><button type="button" class="sx" data-txsx="1" aria-label="Tutup pencarian">✕</button></div></div></div>
    <div class="fsel">${fdd('st', 'Status', ST_OPT.find(o => o[0] === txSt)?.[1] ?? 'Semua status', txSt !== 'all', ST_OPT, txSt)}${fdd('cat', 'Kategori', txCat === 'all' ? 'Semua kategori' : txCat, txCat !== 'all', catOpts, txCat, 'r')}</div>
    ${filterOn() ? '<button class="link freset" data-txreset="1">Reset filter</button>' : ''}</div>`;
}

function txView() {
  return `${filterBar()}<div id="tvb">${txBody()}</div><button class="fab" data-new="1" aria-label="Transaksi baru">+</button>`;
}

function allBuckets() {
  const ds = [...live().map(t => t.date), ...book.entries.map(e => e.date.slice(0, 10))].sort(), end = new Date(), out = [];
  const f = ds[0] ?? today();
  let y = +f.slice(0, 4), m = +f.slice(5, 7) - 1;
  while (y < end.getFullYear() || (y === end.getFullYear() && m <= end.getMonth())) {
    out.push({ l: MON[m], a: ymd(new Date(y, m, 1)), b: ymd(new Date(y, m + 1, 0)) });
    if (++m > 11) { m = 0; y++; }
  }
  if (!out.length) out.push({ l: MON[end.getMonth()], a: ymd(new Date(end.getFullYear(), end.getMonth(), 1)), b: today() });
  return out.slice(-12);
}

// Warna cerah (merah, jingga, kuning, hijau muda, hijau, cyan, biru, ungu, pink). PIE_FG = warna teks lencana (semua putih agar seragam).
const PIE_COL = ['#ff4d5e', '#ff8a1f', '#ffc61a', '#7ed321', '#16c784', '#14c8e6', '#3d8bff', '#9b5cff', '#ff5cb8'];
const PIE_OTHER = '#98a2b3';   // "Lainnya" abu-abu netral, bukan warna pelangi
function pie() {
  const [a, b] = range(), inc = pieKind === 'income', key = pieMode === 'count' ? 'n' : 'sum';
  const cats = categoryList(book, pieKind, a, b), sumOf = (l) => l.reduce((x, c) => x + c.sum, 0);
  const tots = { [pieKind]: sumOf(cats), [inc ? 'expense' : 'income']: sumOf(categoryList(book, inc ? 'expense' : 'income', a, b)) };
  let rows = cats.map(c => ({ c: c.name, v: c[key], sum: c.sum, n: c.n, net: c.net })).filter(r => r.v > 0).sort((x, y) => y.v - x.v);
  if (rows.length > 6) { const r = rows.slice(6), add = (k) => r.reduce((x, y) => x + y[k], 0); rows = [...rows.slice(0, 6), { c: 'Lainnya', v: add('v'), sum: add('sum'), n: add('n'), net: add('net'), more: true }]; }
  const total = rows.reduce((x, r) => x + r.v, 0), totSum = rows.reduce((x, r) => x + r.sum, 0), totN = rows.reduce((x, r) => x + r.n, 0), nCat = cats.length;
  const pr = prevRange(), prevSum = pr ? sumOf(categoryList(book, pieKind, pr[0], pr[1])) : null;
  const dv = (() => {
    if (prevSum === null) return ['Jumlah kategori', `${nCat}`, ''];
    if (prevSum === 0) return [`vs ${pr[2]}`, totSum ? 'Baru' : '—', ''];
    const d = Math.round((totSum - prevSum) / prevSum * 100);
    return [`vs ${pr[2]}`, `${d > 0 ? '▲' : d < 0 ? '▼' : '•'} ${Math.abs(d)}%`, d === 0 ? '' : (d > 0) === inc ? 'pos' : 'out'];
  })();
  const psum = totN ? `<div class="chstats psum"><span>Transaksi<b>${totN}</b></span><span>Rata-rata<b>${rp(Math.round(totSum / totN))}</b></span><span>${dv[0]}<b class="${dv[2]}">${dv[1]}</b></span></div>` : '';
  const tabs = `<div class="ptabs">${[['income', 'Pendapatan'], ['expense', 'Pengeluaran']].map(([k, l]) => `<button data-pkind="${k}" class="${k} ${pieKind === k ? 'on' : ''}"><span>${l}</span><b>${rp(tots[k])}</b></button>`).join('')}</div>`;
  const modes = `<div class="mini">${[['sum', 'Nominal'], ['count', 'Jumlah']].map(([k, l]) => `<button data-pm="${k}" class="${pieMode === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const hd = `<div class="ph"><div><small>Kategori terlaris</small><small class="sub2">${LABEL[period]}</small></div>${foldBtn('pie', 'kategori')}</div>`;
  const ctl = `${tabs}<div class="mrow">${modes}</div>`, tileCls = `tile span2 pie${isFold('pie') ? ' folded' : ''}`;
  const go = (r) => r.more ? `data-catall="${pieKind}"` : `data-cat="${esc(catKey(pieKind, r.c))}"`;
  if (!total) return `<div class="${tileCls}">${hd}<div class="fsum">Belum ada ${inc ? 'penjualan' : 'pengeluaran'}</div><div class="fwrap"><div class="fbody">${ctl}<p class="empty">Belum ada ${inc ? 'penjualan' : 'pengeluaran'} pada periode ini.</p><button class="link catall" data-page="kategori">Lihat semua kategori ›</button></div></div></div>`;
  const fs = `${inc ? 'Pendapatan' : 'Pengeluaran'} <b>${rp(totSum)}</b> · terlaris <b>${esc(rows[0].c)}</b> (${fmtShare(rows[0].v / total * 100)}%)`;

  const W = 360, H = 226, CX = 180, CY = 112, R = 78, RI = 52, MIDR = (R + RI) / 2;
  const pt = (th, r) => [CX + r * Math.sin(th), CY - r * Math.cos(th)];
  const ang = pieAngles(rows.map(r => r.v));   // irisan sekecil apa pun tetap terlihat; persen yang ditampilkan tetap asli
  const sl = rows.map((r, i) => {
    const { a0, a1, share } = ang[i], mid = (a0 + a1) / 2, [ex, ey] = pt(mid, R), [px, py] = pt(mid, R + 12);
    return { r, i, a0, a1, mid, share, side: Math.sin(mid) >= 0 ? 1 : -1, ex, ey, px, py, ly: CY - (R + 22) * Math.cos(mid), col: r.more ? PIE_OTHER : PIE_COL[i % PIE_COL.length] };
  });
  for (const side of [1, -1]) {                    // geser label yang bertumpuk
    const g = sl.filter(x => x.side === side).sort((x, y) => x.ly - y.ly);
    g.forEach((x, k) => { if (k && x.ly < g[k - 1].ly + 30) x.ly = g[k - 1].ly + 30; });
    for (let k = g.length - 1; k >= 0; k--) { const lim = H - 22 - (g.length - 1 - k) * 30; if (g[k].ly > lim) g[k].ly = lim; }
    g.forEach(x => { x.ly = Math.max(14, x.ly); });
  }
  const f = (v) => v.toFixed(1), cut = (t) => t.length > 13 ? `${t.slice(0, 12)}…` : t;
  const shape = (x) => {
    if (sl.length === 1) return `<circle class="pring" cx="${CX}" cy="${CY}" r="${MIDR}" stroke-width="${R - RI}" style="stroke:${x.col}" fill="none"/>`;
    const p = sliceInset(x.a1 - x.a0);
    return `<path class="pslice" style="animation-delay:${x.i * 70}ms" fill="${x.col}" d="${slicePath(CX, CY, R, RI, x.a0 + p, x.a1 - p)}"/>`;
  };
  const cpt = (v) => v >= 1e7 ? `Rp${abbrRupiah(v)}` : rp(v), ctr = pieMode === 'count' ? String(totN) : cpt(totSum);
  const center = `<text class="pcn" x="${CX}" y="${CY - 2}" text-anchor="middle" style="font-size:${ctr.length > 10 ? 13 : 16}px">${ctr}</text><text class="pcl" x="${CX}" y="${CY + 13}" text-anchor="middle">${pieMode === 'count' ? 'transaksi' : inc ? 'pendapatan' : 'pengeluaran'}</text><text class="pcs" x="${CX}" y="${CY + 27}" text-anchor="middle">${nCat} kategori</text>`;
  const parts = sl.map(x => {
    const lx = CX + x.side * (R + 24), anchor = x.side > 0 ? 'start' : 'end';
    return `<g class="ps" style="--dx:${f(Math.sin(x.mid) * 7)}px;--dy:${f(-Math.cos(x.mid) * 7)}px" ${go(x.r)} role="button" tabindex="0" aria-label="${esc(x.r.c)} ${fmtShare(x.share * 100)}%">${shape(x)}
      <path class="pl-ln" pathLength="1" style="animation-delay:${x.i * 70 + 250}ms" d="M${f(x.ex)} ${f(x.ey)}C${f(x.px)} ${f(x.py)} ${f(lx - x.side * 18)} ${f(x.ly - 4)} ${f(lx - x.side * 4)} ${f(x.ly - 4)}"/>
      <text class="pn" x="${f(lx)}" y="${f(x.ly - 2)}" text-anchor="${anchor}">${esc(cut(x.r.c))}</text><text class="pp" x="${f(lx)}" y="${f(x.ly + 12)}" text-anchor="${anchor}">${fmtShare(x.share * 100)} %</text></g>`;
  }).join('');
  const list = sl.map(({ r, i, col, share }) => `<button class="prow" ${go(r)} style="--pc:${col}"><i class="psw"></i><span class="pnm"><span class="pn1"><span class="pnt">${esc(r.c)}</span></span><small>${r.n} transaksi${inc && r.net != null ? ` · <span class="${r.net < 0 ? 'neg' : 'gain'}">untung Rp${abbrRupiah(r.net)}</span>` : ''}</small><span class="pbar"><i style="width:${Math.max(3, share * 100).toFixed(1)}%"></i></span></span><span class="pam"><b>${rp(r.sum)}</b><small>${i === 0 && rows.length > 1 ? '<em class="ptop">Terlaris</em>' : ''}<span class="pchip">${fmtShare(share * 100)}%</span></small></span><i class="chev">›</i></button>`).join('');
  return `<div class="${tileCls}">${hd}<div class="fsum">${fs}</div><div class="fwrap"><div class="fbody">${ctl}${psum}
    <svg class="pieSvg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Diagram kategori"><circle class="ptrack" cx="${CX}" cy="${CY}" r="${MIDR}" stroke-width="${R - RI}" fill="none"/>${parts}${center}</svg>
    <div class="plist">${list}</div><button class="link catall" data-page="kategori">Lihat semua kategori ›</button></div></div></div>`;
}

function openEdit(id) {
  const t = book.transactions.find(x => x.id === id);
  if (!t || !['pending', 'berhasil'].includes(t.status)) return;
  draft = { editId: id, kind: t.kind, date: t.date, time: t.time ?? '', price: String(t.price), cost: t.cost ? String(t.cost) : '', fee: t.fee ? String(t.fee) : '',
    name: t.product === t.category ? '' : t.product, target: t.target ?? '', memo: t.note ?? '', category: t.category, method: t.method, source: t.source, paid: t.paid === false ? '0' : '1', field: 'price', pad: false, items: (t.items ?? []).map(i => ({ ...i })), files: (t.files ?? []).map(f => ({ ...f })), pend: new Map() };
  renderForm();
}

// Salin transaksi: tanya dulu tanggal & jam salinan (sama dengan transaksi asal, atau hari ini), lalu buka form terisi.
// Baru tersimpan setelah Simpan, jadi membatalkan tidak meninggalkan data ganda. Akun yang sudah dihapus diganti ke bawaan.
const fmtFull = (d) => new Date(`${d}T00:00:00`).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' });
const nowLabel = () => `${fmtFull(today())} · ${nowHM()}`;
// Menu Salin = dropdown di tempat (gaya pilihan periode Hari/Minggu/...): 2 pilihan tanggal & jam untuk salinan.
const cloneMenu = (t) => `<div class="pdd cl-dd"><button type="button" class="clbtn" data-pdd="1" aria-haspopup="listbox" aria-expanded="false">${ico('copy')} Salin</button>
  <div class="pdd-menu" role="listbox" aria-label="Salin transaksi">
    <button type="button" role="option" aria-selected="false" class="pdd-opt" data-clmode="same" data-clid="${t.id}" style="--i:0"><span class="po-t"><b>Tanggal &amp; jam sama</b><small>${esc(fmtFull(t.date))}${t.time ? ` · ${t.time}` : ''}</small></span><i class="po-ck po-go">${ico('cal')}</i></button>
    <button type="button" role="option" aria-selected="false" class="pdd-opt" data-clmode="today" data-clid="${t.id}" style="--i:1"><span class="po-t"><b>Tanggal &amp; jam hari ini</b><small class="cl-now">${esc(nowLabel())}</small></span><i class="po-ck po-go">${ico('clock')}</i></button>
  </div></div>`;
function cloneTx(id, mode = 'today') {
  const t = book.transactions.find(x => x.id === id);
  if (!t || t.deleted || !['income', 'expense', 'transfer'].includes(t.kind)) return;
  const on = activeCodes(), tr = t.kind === 'transfer';
  let source = on.includes(t.source) ? t.source : tr ? '1101' : defSource();
  let method = on.includes(t.method) ? t.method : tr ? defSource() : '1101';
  if (tr && source === method) method = on.find(c => c !== source) ?? method;
  const same = mode === 'same';
  draft = { cloneOf: id, kind: t.kind, date: same ? t.date : today(), time: same ? (t.time ?? '') : nowHM(), price: String(t.price), cost: t.cost ? String(t.cost) : '', fee: t.fee ? String(t.fee) : '',
    name: t.product === t.category ? '' : t.product, target: t.target ?? '', memo: t.note ?? '', category: t.category, method, source,
    paid: t.paid === false ? '0' : '1', field: 'price', pad: false, files: [], items: (t.items ?? []).map(i => ({ ...i })), pend: new Map() };
  renderForm();
  toast(same ? 'Salinan (tanggal & jam sama) siap. Ubah seperlunya lalu Simpan.' : 'Salinan (hari ini) siap. Ubah seperlunya lalu Simpan.');
}

function newInCategory({ kind, name }) {
  openForm(kind); draft.category = name; renderForm();
}

function closeSheet() {
  if (draft && !draft.saved && draft.pend) dropUrls([...draft.pend.keys()]);
  draft = null; detailId = null;
  const s = $('#sheet'); if (s.hidden) return;
  const my = ++tok; s.classList.add('out');
  setTimeout(() => { if (tok === my) { s.hidden = true; s.innerHTML = ''; s.classList.remove('out'); } }, 220);
}

const SHEET_BOTTOM = () => { const s = $('#sheet'); tok++; detailId = null; s.className = 'sheet bottom'; s.hidden = false; return s; };

function askConfirm({ title, text, ok, danger = false, type = null, list = null, more = 0 }, fn) {
  cfFn = fn; cfNeed = type;
  const c = $('#confirm'); c.hidden = false;
  c.innerHTML = `<div class="box"><h3>${esc(title)}</h3><p class="cft">${esc(text)}</p>
    ${list ? `<ul class="cf-list">${list.map(([a, b]) => `<li><span>${esc(a)}</span><b>${esc(b)}</b></li>`).join('')}${more > 0 ? `<li class="more">+ ${more} transaksi lainnya</li>` : ''}</ul>` : ''}
    ${type ? `<input id="cfin" class="cfin" placeholder="Ketik ${esc(type)} untuk melanjutkan" autocomplete="off" autocapitalize="characters">` : ''}
    <div class="acts"><button data-cf="no">Batal</button><button class="${danger ? 'danger' : 'primary'}" data-cf="ok" ${type ? 'disabled' : ''}>${esc(ok)}</button></div></div>`;
}
function closeConfirm() { cfFn = null; const c = $('#confirm'); c.hidden = true; c.innerHTML = ''; }

async function copyText(v, label = null) {
  try { await navigator.clipboard.writeText(v); }
  catch { const ta = document.createElement('textarea'); ta.value = v; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch {} ta.remove(); }
  toast(label ?? `Disalin: ${v}`);
}

function askDel(id) {
  const t = book.transactions.find(x => x.id === id); if (!t || t.deleted) return;
  askConfirm({ title: 'Hapus transaksi?', text: `"${t.product}" senilai ${rp(t.price)} akan dihapus. Saldo dan laporan dikembalikan seperti sebelum transaksi ini dicatat.${filesOf(t).length ? ' Gambar lampiran ikut dihapus.' : ''}`, ok: 'Hapus', danger: true },
    async () => {
      const ids = filesOf(t).map(f => f.id);
      if (await act(() => { deleteTransaction(book, id); t.files = []; closeSheet(); toast('Transaksi dihapus'); }) && ids.length) { delFiles(ids).catch(() => {}); dropUrls(ids); }
    });
}

function payChip(id) {
  const t = book.transactions.find(x => x.id === id); if (!t) return;
  if (t.paid === false) act(() => { setPaid(book, id, true, today()); toast('Ditandai sudah bayar'); });
  else askConfirm({ title: 'Tandai belum bayar?', text: `Uang ${rp(t.price)} dicatat sebagai piutang lagi sampai pembeli melunasi.`, ok: 'Ya, belum bayar' },
    () => act(() => { setPaid(book, id, false, today()); toast('Ditandai belum bayar'); }));
}

function openDetail(id) {
  const t = book.transactions.find(x => x.id === id); if (!t || t.deleted) return;
  const live1 = ['pending', 'berhasil'].includes(t.status), isIn = t.kind === 'income';
  const unpaid = isIn && live1 && t.paid === false;
  const acts = t.status === 'pending' ? [['berhasil', 'Tandai berhasil'], ['gagal', 'Gagal'], ['dibatalkan', 'Batalkan']]
    : t.status === 'berhasil' ? [isIn ? ['refund', 'Refund'] : ['dibatalkan', 'Batalkan transaksi']] : [];
  const sale = isIn && t.cost > 0, tr = t.kind === 'transfer', kc = { income: 'in', expense: 'out', transfer: 'tr' }[t.kind];
  const cell = (k, v, extra = '', w = '') => `<div class="kc ${w}"><span>${k}</span><b>${esc(v)}${extra}</b></div>`;
  const cells = [
    tr ? cell('Kategori', t.category) : `<div class="kc"><span>Kategori</span><b>${esc(t.category)}<button class="icb sm lnk" data-cat="${esc(catKey(t.kind, t.category))}" aria-label="Lihat kategori">›</button></b></div>`,
    cell(tr ? 'Dari' : 'Aset', unpaid ? 'Piutang' : SHORT[tr ? t.source : t.method]),
    ...(tr ? [cell('Ke', SHORT[t.method])] : []),
    ...(tr && t.fee > 0 ? [cell('Pajak', rp(t.fee)), cell('Total keluar', rp(t.price + t.fee))] : []),
    ...(sale ? [cell('Modal', rp(t.cost)), cell('Biaya', rp(t.fee)), cell('Untung', rp(t.price - t.cost - t.fee)), cell('Sumber modal', SHORT[t.source])] : []),
    ...(t.target ? [cell('No. / ID', t.target, `<button class="icb sm" data-copy="${esc(t.target)}" aria-label="Salin">${ico('copy')}</button>`, 'w')] : []),
    ...(t.note ? [cell('Catatan', t.note, '', 'w')] : [])];
  const pay = isIn && live1 ? `<div class="paysw"><button data-setpaid="1" data-id="${t.id}" class="p1 ${unpaid ? '' : 'on'}">Sudah bayar</button><button data-setpaid="0" data-id="${t.id}" class="p0 ${unpaid ? 'on' : ''}">Belum bayar</button></div>` : '';
  const canSave = t.target && !findContactByNumber(book, t.target);
  const wa = unpaid && waNumber(t.target);
  const tagih = unpaid ? `<div class="tagih"><button data-bill="${t.id}">${ico('copy')} Salin tagihan</button>${wa ? `<a class="btn wa" href="https://wa.me/${wa}?text=${encodeURIComponent(reminderText([t], book.settings.shop))}" target="_blank" rel="noopener">${ico('chat')} WhatsApp</a>` : ''}</div>` : '';
  const fl = filesOf(t), canAdd = !demo && storage && fl.length < MAX_FILES;
  const att = fl.length || canAdd ? `<div class="att-d"><h4>Lampiran gambar${fl.length ? ` · ${fl.length}` : ''}</h4><div class="thumbs">${fl.map(f => `<div class="th"><button type="button" data-fv="${esc(f.id)}" data-ftx="${t.id}" aria-label="Lihat gambar"><img data-fid="${esc(f.id)}" alt=""></button></div>`).join('')}${canAdd ? `<button type="button" class="thadd" data-ftxadd="${t.id}">${ico('image')}<span>Tambah</span></button>` : ''}</div></div>` : '';
  draft = null;
  const s = SHEET_BOTTOM();
  s.innerHTML = `<div class="box gb det"><div class="grab"></div>
    <div class="dbody"><div class="dh"><div class="dht"><h3>${esc(t.product)}</h3><small class="dmeta">${trxNo(t)} · ${fmtDay(t.date)} ${t.date.slice(0, 4)}${t.time ? ' · ' + t.time : ''}</small></div><b class="${kc}">${rp(t.price)}</b></div>
      <div class="badges"><span class="bd ${kc}">${KIND[t.kind]}</span><em class="st ${t.status}">${t.status}</em></div>${pay}${tagih}
      <div class="kgrid">${cells.join('')}</div>${itemsBlock(t)}${att}</div>
    <div class="acts">${live1 ? `<button class="edit" data-edit="${t.id}">✎ Edit</button>` : ''}${cloneMenu(t)}<button data-struk="${t.id}">${ico('note')} Struk</button><button class="ghostdanger" data-del="${t.id}">Hapus</button>${acts.map(([st, l]) => `<button class="wide ${st === 'berhasil' ? 'primary' : ''}" data-tx="${t.id}" data-st="${st}">${l}</button>`).join('')}${canSave ? `<button class="wide" data-savect="${t.id}">+ Simpan ke Catatan</button>` : ''}</div></div>`;
  detailId = id; hydrate(s);
}

const activeCodes = () => Object.values(book.accounts).filter(a => a.type === 'asset' && !a.archived && a.code !== '1301').map(a => a.code);
const defSource = () => { const on = activeCodes(); return ['1201', '1202'].find(c => on.includes(c)) ?? on.find(c => c !== '1101') ?? '1101'; };

function setKind(k) {
  const d = draft; d.mem ??= {};
  if (d.kind) d.mem[d.kind] = { cost: d.cost, fee: d.fee, category: d.category, method: d.method, source: d.source, paid: d.paid };
  d.kind = k; d.field = 'price'; d.pad = true;
  const m = d.mem[k];
  if (m) { Object.assign(d, m); return; }          // kembali ke jenis yang pernah diisi: nilai lama dipulihkan
  d.paid = '1'; d.cost = ''; d.fee = '';
  d.category = k === 'transfer' ? 'Transfer' : k === 'saldo' ? 'Saldo' : book.categories[k][0];
  d.method = k === 'transfer' ? defSource() : '1101';
  d.source = k === 'transfer' ? '1101' : defSource();
}

function openForm(kind = 'income') {
  draft = { date: today(), time: nowHM(), price: '', cost: '', fee: '', name: '', target: '', memo: '', files: [], items: [], pend: new Map() };
  setKind(kind);
  renderForm();
}

function renderFormRaw() {
  const d = draft, k = d.kind;
  const num = (f) => `<div class="fr num ${d.field === f ? 'on' : ''}" data-f="${f}"><span>${lbl(f)}</span><b class="${d[f] ? '' : 'ph'}">${rp(Number(d[f] || 0))}</b></div>`;
  const row = (name) => `<div class="fr pk" data-pk="${name}"><span>${fieldLabel(name, k)}</span><b>${esc(pkLabel(name))}</b><i>›</i></div>`;
  const s = $('#sheet'); tok++; detailId = null; s.className = 'sheet full'; s.dataset.k = k; s.hidden = false;
  s.innerHTML = `<div class="sh-head"><button data-x="1" aria-label="Kembali">←</button><b>${k === 'saldo' ? TITLE[k] : d.editId ? 'Edit' : d.cloneOf ? 'Salin' : 'Baru'}</b>${k === 'income' ? `<button type="button" class="paychip ${d.paid === '1' ? 'ok' : 'no'}" data-paidtg="1" aria-label="Ubah status pembayaran">${d.paid === '1' ? 'Sudah bayar' : 'Belum bayar'}</button>` : ''}<button class="primary" data-save="1">Simpan</button></div>
  ${k === 'saldo' ? '' : `<div class="kinds" role="tablist">${Object.entries(KIND).map(([v, l]) => `<button role="tab" data-kind="${v}" class="${v === k ? 'on' : ''}">${l}</button>`).join('')}</div>`}
  <div class="fields">
    <div class="fg two"><label class="fl"><span>Tanggal</span><input type="date" name="date" value="${d.date}"></label><label class="fl"><span>Jam</span><input type="time" name="time" value="${d.time ?? ''}"></label></div>
    <div class="fg">${num('price')}${k === 'income' ? `<div class="mini2">${num('cost')}${num('fee')}</div>` : k === 'transfer' ? `<div class="mini2 one">${num('fee')}</div><div class="tinfo">Dipotong dari akun asal: <b id="tout">${rp(Number(d.price || 0) + Number(d.fee || 0))}</b></div>` : ''}</div>
    <div class="fg">${k === 'income' || k === 'expense' ? row('category') : ''}
      ${k === 'transfer' ? row('source') + row('method') : row('method')}
      ${k === 'income' ? row('source') : ''}</div>
    ${k === 'saldo' ? `<div class="fg"><div class="fr top"><span>Catatan</span><textarea name="memo" rows="2" maxlength="80" placeholder="Opsional, mis. setor modal, top up deposit">${esc(d.memo)}</textarea></div></div>` : `<div class="fg"><div class="fr"><span>Pelanggan</span><input name="name" value="${esc(d.name)}" placeholder="Nama pelanggan / keterangan" autocomplete="off">${k === 'income' ? `<button type="button" class="icb sm" data-ctpick="1" aria-label="Pilih dari Catatan">${ico('note')}</button>` : ''}</div>
      ${k === 'income' ? `<div class="fr"><span>No. / ID</span><input name="target" value="${esc(d.target)}" maxlength="40" placeholder="No. HP, ID PLN, ID game…" autocomplete="off"></div>` : ''}
      ${k === 'income' ? row('items') : ''}
      <div class="fr top"><span>Catatan</span><textarea name="memo" rows="2" maxlength="200" placeholder="Opsional">${esc(d.memo)}</textarea><div class="mini-acts"><button type="button" class="icb sm" data-fadd="1" aria-label="Lampirkan gambar">${ico('clip')}${d.files.length ? `<i class="bdg">${d.files.length}</i>` : ''}</button><button type="button" class="icb sm" data-fread="1" aria-label="Baca dari gambar">${ico('scan')}</button></div></div>
      ${d.files.length ? `<div class="thumbs sm">${d.files.map(f => `<div class="th"><button type="button" data-fv="${esc(f.id)}" aria-label="Lihat gambar"><img data-fid="${esc(f.id)}" alt=""></button><button type="button" class="thx" data-frm="${esc(f.id)}" aria-label="Lepas gambar">✕</button></div>`).join('')}</div>` : ''}</div>`}
    ${d.editId ? `<button type="button" class="dangerlink" data-del="${d.editId}">Hapus transaksi</button>` : ''}
  </div>
  <div id="pad" class="pad" ${d.pad ? '' : 'hidden'}><div class="pad-t"><b id="padt">${lbl(d.field)}</b><button type="button" data-key="done" aria-label="Tutup keypad">✕</button></div>
    <div class="keys">${KEYS.map(([c, l, x = '']) => `<button type="button" class="${x}" data-key="${c}">${l}</button>`).join('')}</div></div>`;
}

function updateNums() {
  document.querySelectorAll('#sheet .num').forEach(x => {
    const v = draft[x.dataset.f], b = x.querySelector('b');
    b.textContent = rp(Number(v || 0)); b.className = v ? '' : 'ph';
  });
  const out = $('#tout'); if (out) out.textContent = rp(Number(draft.price || 0) + Number(draft.fee || 0));
}

function keypad(k) {
  const f = draft.field;
  if (k === 'calc') { openCalc(); return; }
  if (k === 'done') { draft.pad = false; $('#pad').hidden = true; return; }
  if (k === 'back') draft[f] = draft[f].slice(0, -1);
  else if (k === 'clear') draft[f] = '';
  else { const v = (draft[f] + k).replace(/^0+/, ''); if (v.length <= 12) draft[f] = v; }
  updateNums();
}

async function saveDraft() {
  const d = draft; if (!d || d.busy) return;
  const n = (k) => Number(d[k] || 0), c = { date: d.date, time: d.time, category: d.category, product: d.name, note: d.memo, items: d.kind === 'income' ? d.items : [], target: d.kind === 'income' ? d.target : '' };
  if (d.kind === 'saldo') {
    act(() => {
      if (n('price') <= 0) throw new Error('Nominal harus lebih dari 0');
      addBalance(book, { date: d.date, time: d.time, account: d.method, amount: n('price'), note: d.memo });
      closeSheet();
    });
    return;
  }
  const t = d.kind === 'income' ? { ...c, kind: 'income', price: n('price'), cost: n('cost'), fee: n('fee'), method: d.method, source: d.source, status: 'berhasil', paid: d.paid === '1' }
    : d.kind === 'expense' ? { ...c, kind: 'expense', price: n('price'), method: d.method }
    : { ...c, kind: 'transfer', price: n('price'), fee: n('fee'), source: d.source, method: d.method };
  d.busy = true;
  const fresh = d.files.filter(f => d.pend.has(f.id));
  try { for (const f of fresh) { const p = d.pend.get(f.id); await putFile(f.id, await toRec(p.blob, p.thumb)); } }
  catch { await delFiles(fresh.map(f => f.id)).catch(() => {}); d.busy = false; toast('Gagal menyimpan gambar di perangkat'); return; }
  const before = d.editId ? filesOf(book.transactions.find(x => x.id === d.editId)).map(f => f.id) : [];
  const ok = await act(() => {
    const tx = d.editId ? editTransaction(book, d.editId, t) : addTransaction(book, t);
    setFiles(book, tx.id, d.files);
    view = 'tx'; if (!d.editId) txTab = 'day'; mon = { y: +d.date.slice(0, 4), m: +d.date.slice(5, 7) - 1 };
    d.saved = true; closeSheet();
  });
  d.busy = false;
  if (ok) await delFiles(before.filter(id => !d.files.some(f => f.id === id))).catch(() => {});
  else { d.saved = false; if (fresh.length) await delFiles(fresh.map(f => f.id)).catch(() => {}); }
}

let calc = null;
const CK = [['C', 'C', 'k-alt'], ['back', '⌫', 'k-alt'], ['÷', '÷', 'k-op'], ['×', '×', 'k-op'], ['7'], ['8'], ['9'], ['-', '−', 'k-op'],
  ['4'], ['5'], ['6'], ['+', '+', 'k-op'], ['1'], ['2'], ['3'], ['=', '=', 'k-op'], ['0'], ['000'], ['use', 'Pakai', 'k-done k-w']];

function openCalc() {
  calc = { expr: draft[draft.field] };
  const c = $('#calc'); c.hidden = false;
  c.innerHTML = `<div class="box"><div class="calc-h"><b>Kalkulator · ${lbl(draft.field)}</b><button type="button" data-c="x" aria-label="Tutup">✕</button></div>
    <div class="calc-d"><small id="cx"></small><b id="cr"></b></div>
    <div class="ckeys">${CK.map(([k, l = k, x = '']) => `<button type="button" class="${x}" data-c="${k}">${l}</button>`).join('')}</div></div>`;
  showCalc();
}

function closeCalc() { calc = null; const c = $('#calc'); c.hidden = true; c.innerHTML = ''; }

function calcResult() {
  const r = Math.round(evalExpr(calc.expr));
  if (r < 0) throw new Error('Hasil tidak boleh negatif');
  if (String(r).length > 12) throw new Error('Angka terlalu besar');
  return r;
}

function showCalc() {
  let r; try { r = rp(Math.round(evalExpr(calc.expr))); } catch (e) { r = e.message; }
  $('#cx').textContent = fmtExpr(calc.expr) || '0';
  $('#cr').textContent = `= ${r}`;
}

function calcKey(k) {
  try {
    if (k === 'x') { closeCalc(); return; }
    if (k === 'use') { draft[draft.field] = String(calcResult()).replace(/^0$/, ''); updateNums(); closeCalc(); return; }
    calc.expr = k === '=' ? String(calcResult()) : pressKey(calc.expr, k);
    showCalc();
  } catch (e) { toast(e.message); }
}

const TITLE = { ...KIND, saldo: 'Tambah saldo' };
const fieldLabel = (name, k) => name === 'category' ? 'Kategori' : name === 'items' ? 'Produk'
  : name === 'source' ? (k === 'transfer' ? 'Dari' : 'Sumber modal')
  : { income: 'Masuk ke', expense: 'Dibayar dari', transfer: 'Ke', saldo: 'Akun' }[k];
const pkLabel = (name) => name === 'category' ? draft.category : name === 'items' ? itemsLabel() : SHORT[draft[name]];
const syncRows = () => document.querySelectorAll('#sheet .pk').forEach(r => { r.querySelector('b').textContent = pkLabel(r.dataset.pk); });
let pkName = null;
const itemsLabel = () => draft.items?.length ? `${draft.items.reduce((a, i) => a + i.q, 0)} barang · ${rp(itemsTotal(draft.items).price)}` : 'Tambah produk';
// Produk dibeli: lembar terpisah (tidak memenuhi form). Perubahan langsung mengisi Nominal & Modal di form.
let itEdit = null;
function renderItems() {
  const c = $('#pick'); c.hidden = false; itEdit = null;
  c.innerHTML = `<div class="box gb pkbox itbox"><div class="grab"></div>
    <div class="pkh"><b>Produk dibeli</b><div class="pkh-r"><button type="button" class="pkm on" data-pkx="1">Selesai</button></div></div>
    <div id="itl"></div>
    <div class="itsearch">${ico('search')}<input name="itn" maxlength="40" placeholder="Cari atau ketik produk baru" autocomplete="off"></div>
    <div class="itcat" id="itc"></div>
    <div class="itnew" id="itnew" hidden><input name="itp" inputmode="numeric" placeholder="Harga jual" autocomplete="off"><input name="itm" inputmode="numeric" placeholder="Modal" autocomplete="off">
      <button type="button" data-itadd="1">Tambah</button><label class="itsave"><input type="checkbox" name="itsv" checked> Simpan ke daftar produk</label></div>
    <div class="ittot" id="itt"></div></div>`;
  refreshItems(); refreshCat();
}
const nf = (n) => n ? new Intl.NumberFormat('id-ID').format(n) : '';   // 12000 → 12.000
const digits = (v) => Number(String(v).replace(/\D/g, '').slice(0, 12)) || 0;
// Daftar pilihan ikut menyaring saat mengetik; bila nama belum ada, muncul isian harga & modal untuk produk baru.
function refreshCat() {
  const q = ($('#pick [name=itn]')?.value ?? '').trim(), list = searchProducts(book, q), exact = list.some(x => x.name.toLowerCase() === q.toLowerCase());
  $('#itc').innerHTML = list.map(x => `<button type="button" class="itc" data-itpr="${x.id}"><b>${esc(x.name)}</b><small>${x.price ? rp(x.price) : 'tanpa harga'}</small></button>`).join('');
  $('#itc').hidden = !list.length; $('#itnew').hidden = !q || exact;
}
const itSub = (i) => `${rp(i.p).replace('Rp', '')}${i.c ? ` · modal ${rp(i.c).replace('Rp', '')}` : ''}`;
function refreshItems() {
  const it = draft.items;
  $('#itl').innerHTML = it.map((i, x) => `<div class="itr ${itEdit === x ? 'op' : ''}"><div class="itl1"><span class="itnm"><b>${esc(i.n)}</b><small><span id="itsm${x}">${itSub(i)}</span><button type="button" class="ited" data-ited="${x}" aria-label="Ubah harga dan modal">${ico('edit')}</button></small></span>
    <span class="itq"><button type="button" data-itq="${x}" data-dq="-1" aria-label="Kurangi">−</button><b>${i.q}</b><button type="button" data-itq="${x}" data-dq="1" aria-label="Tambah">+</button></span><b class="its" id="its${x}">${rp(i.q * i.p)}</b></div>
    ${itEdit === x ? `<div class="itf"><label>Harga<input data-itf="p" data-i="${x}" inputmode="numeric" value="${nf(i.p)}" placeholder="0"></label><label>Modal<input data-itf="c" data-i="${x}" inputmode="numeric" value="${nf(i.c)}" placeholder="0"></label></div>` : ''}</div>`).join('');
  $('#itl').hidden = !it.length;
  refreshTot();
}
function refreshTot() {
  const t = itemsTotal(draft.items), n = draft.items.length;
  $('#itt').innerHTML = `<div><span>Total harga</span><b>${rp(t.price)}</b></div>${t.cost ? `<div class="sm"><span>Modal</span><b>${rp(t.cost)}</b></div><div class="sm up"><span>Untung</span><b>${rp(t.price - t.cost)}</b></div>` : ''}`;
  if (n) { draft.price = t.price ? String(t.price) : ''; draft.cost = t.cost ? String(t.cost) : ''; }
}
function addItem(x) {
  const it = draft.items, hit = it.find(i => i.n.toLowerCase() === x.n.toLowerCase() && i.p === x.p);
  if (hit) hit.q = Math.min(999, hit.q + 1);
  else if (it.length >= 30) return toast('Maksimal 30 baris produk');
  else it.push({ q: 1, c: 0, ...x });
  refreshItems();
}
const itemsBlock = (t) => t.items?.length ? `<div class="its-d"><h4>Produk · ${t.items.reduce((a, i) => a + i.q, 0)} barang</h4>${t.items.map(i => `<div class="itd"><span>${i.q}× ${esc(i.n)}</span><b>${rp(i.q * i.p)}</b></div>`).join('')}</div>` : '';

function pickerOpts(name) {
  if (name === 'contact') return searchContacts(book, '').map(c => ({ v: c.id, l: c.name || c.number, s: c.name ? c.number : '' }));
  if (name === 'category') return book.categories[draft.kind].map(c => ({ v: c, l: c, del: true }));
  return Object.values(book.accounts).filter(a => a.type === 'asset' && a.code !== '1301' && !a.archived)
    .map(a => ({ v: a.code, l: SHORT[a.code], s: rp(balance(book, a.code)), del: a.code.startsWith('14') }));
}

function renderPicker() {
  const c = $('#pick'), isCt = pkName === 'contact', cur = pkName === 'category' ? draft.category : draft[pkName], opts = pickerOpts(pkName);
  const canManage = !isCt && opts.some(o => o.del), mg = canManage && pkManage;
  c.hidden = false;
  const rows = opts.map(o => `<div class="pko ${o.v === cur ? 'on' : ''} ${mg ? 'mg' : ''}"><button type="button" class="pko-b" data-pv="${esc(o.v)}" ${mg ? 'disabled' : ''}><i class="pko-rad"></i><span class="pko-t"><b>${esc(o.l)}</b>${o.s ? `<small>${esc(o.s)}</small>` : ''}</span></button>${mg ? (o.del ? `<button type="button" class="pko-d" data-pd="${esc(o.v)}" aria-label="Hapus ${esc(o.l)}">${ico('trash')}</button>` : '<span class="pko-lock">Bawaan</span>') : ''}</div>`).join('');
  c.innerHTML = `<div class="box gb pkbox"><div class="grab"></div>
    <div class="pkh"><b>${isCt ? 'Pilih dari Catatan' : fieldLabel(pkName, draft.kind)}</b><div class="pkh-r">${canManage ? `<button type="button" class="pkm ${mg ? 'on' : ''}" data-pkm="1">${mg ? 'Selesai' : 'Kelola'}</button>` : ''}<button type="button" class="pkc" data-pkx="1" aria-label="Tutup">✕</button></div></div>
    ${mg ? '<p class="pkhint">Ketuk ikon tempat sampah untuk menghapus pilihan.</p>' : ''}
    <div class="pklist">${rows || '<p class="empty">Catatan masih kosong. Tambah lewat menu Catatan.</p>'}</div>
    ${isCt || mg ? '' : `<div class="addcat pkadd"><input name="newopt" maxlength="20" placeholder="${pkName === 'category' ? 'Kategori baru' : 'Akun baru, mis. DANA'}" autocomplete="off"><button type="button" data-padd="1">Tambah</button></div>`}</div>`;
  const on = c.querySelector('.pko.on'), l = c.querySelector('.pklist'); if (on && l) l.scrollTop = Math.max(0, on.offsetTop - l.clientHeight / 2 + on.offsetHeight / 2);
}
let pkManage = false;
const openPicker = (name) => { pkName = name; pkManage = false; name === 'items' ? renderItems() : renderPicker(); };
function closePicker() { const was = pkName; pkName = null; pkManage = false; const c = $('#pick'); c.hidden = true; c.innerHTML = ''; if (was === 'items' && draft) renderForm(); }

const emptyHint = () => book.entries.length || demo ? '' :
  `<div class="hint"><b>Belum ada data</b><small>Mulai dari menu Kas (Tambah saldo), atau lihat tampilannya dengan data contoh.</small><button data-demo="1">Lihat data contoh</button></div>`;

function renderForm() {
  const sc = $('#sheet .fields')?.scrollTop ?? 0;
  renderFormRaw();
  const f = $('#sheet .fields'); if (f) f.scrollTop = sc;
  hydrate($('#sheet'));
}

function kasView() {
  const [a, b] = range(), p = profitLoss(book, a, b);
  const assets = Object.values(book.accounts).filter(x => x.type === 'asset' && x.code !== '1301');
  const accs = assets.filter(x => !x.archived), gone = assets.filter(x => x.archived);
  const tot = Math.max(1, accs.reduce((s, x) => s + Math.max(0, balance(book, x.code)), 0));
  const byCat = {};
  for (const t of live())
    if (t.kind === 'income' && t.status === 'berhasil' && inRange(t, a, b)) byCat[t.category] = (byCat[t.category] ?? 0) + t.price - t.cost - t.fee;
  const cats = Object.entries(byCat).sort((x, y) => y[1] - x[1]).slice(0, 5), top = Math.max(1, ...cats.map(c => Math.abs(c[1])));
  const debts = piutangList(), owed = debts.length, owedSum = debts.reduce((x, t) => x + t.price, 0);
  const cnt = live().filter(t => t.status === 'berhasil' && t.date >= a && t.date <= b).length;
  const moves = live().filter(t => t.kind === 'transfer').sort(byNewest);
  return `<div class="bento">${saldoHero()}</div>
  <div class="sec-h"><h3>Akun</h3><small>Ketuk untuk kelola</small></div>
  <div class="items accs">${accs.map(x => { const v = balance(book, x.code); return `<button class="acc a-${ACC_KIND[x.code] ?? 'other'}" data-acc="${x.code}"><span class="ic">${ico(ACC_ICON[x.code] ?? 'wallet')}</span>
    <div class="an"><b>${esc(SHORT[x.code])}</b><div class="bar"><i style="width:${Math.round(Math.max(0, v) / tot * 100)}%"></i></div></div><strong>${rp(v)}</strong><i class="chev">›</i></button>`; }).join('')}</div>
  <div class="sec-h"><h3>Piutang</h3></div>
  <button class="piu" data-page="piutang"><span class="ic">${ico('clock')}</span><div class="pm"><b>${rp(owedSum)}</b><small>${owed ? `${piutangGroups().length} pembeli · ${owed} transaksi belum bayar` : 'Semua pembeli sudah bayar'}</small></div><i class="chev">›</i></button>
  <div class="sec-h"><h3>Perpindahan saldo</h3>${moves.length ? '<button class="link" data-txgo="transfer">Lihat semua</button>' : ''}</div>
  ${moves.length ? `<div class="items">${moves.slice(0, 4).map(txItem).join('')}</div>` : '<p class="empty">Belum ada perpindahan saldo antar akun.</p>'}
  <div class="sec-h"><h3>Keuntungan</h3></div>
  ${periodPick()}
  <div class="bento">
    ${profitCard(p, cnt)}
    <div class="tile span2 cbars"><small>Untung penjualan per kategori · ketuk untuk rincian</small>${cats.map(([n, v]) => `<button class="cb" data-cat="${esc(catKey('income', n))}"><div><span>${esc(n)}</span><b>${rp(v)}</b></div><div class="bar"><i style="width:${Math.round(Math.abs(v) / top * 100)}%"></i></div></button>`).join('') || '<p class="empty">Belum ada penjualan pada periode ini.</p>'}</div>
    ${pie()}
  </div>
  <div class="sec-h"><h3>Kelola</h3></div>
  <div class="bento"><button class="tile act" data-newsaldo="1"><span class="ic">${ico('plus')}</span><b>Tambah saldo / modal</b></button><button class="tile act" data-page="saldohist"><span class="ic">${ico('clock')}</span><b>Riwayat saldo & modal</b></button></div>
  <form id="af" class="form"><small>Tambah akun baru</small><div class="addcat"><input name="name" maxlength="20" placeholder="Mis. DANA, BRI, Deposit Server B" required autocomplete="off"><button>Tambah</button></div></form>
  ${gone.length ? `<div class="sec-h"><h3>Akun dihapus</h3></div><div class="items">${gone.map(x => `<div class="row2"><span>${esc(SHORT[x.code])}</span><button data-accrestore="${x.code}">Aktifkan lagi</button></div>`).join('')}</div>` : ''}
`;
}

// ---- Halaman penuh (Piutang, Pengaturan) ----
const piutangList = () => live().filter(t => t.kind === 'income' && t.status === 'berhasil' && t.paid === false);
const ageDays = (d) => Math.max(0, Math.round((new Date(`${today()}T00:00:00`) - new Date(`${d}T00:00:00`)) / 864e5));
const ageTxt = (n) => n === 0 ? 'Hari ini' : n === 1 ? 'Kemarin' : `${n} hari`;

// Utang pembeli dikelompokkan per nomor / ID (pembeli yang sama), yang paling lama menunggak di atas.
function piutangGroups() {
  const g = new Map();
  for (const t of piutangList().sort((x, y) => x.date.localeCompare(y.date) || x.id.localeCompare(y.id))) {
    const k = t.target ? `n:${numKey(t.target)}` : `t:${t.id}`;
    if (!g.has(k)) g.set(k, { target: t.target, rows: [] });
    g.get(k).rows.push(t);
  }
  return [...g.values()].map(x => {
    const c = x.target ? findContactByNumber(book, x.target) : null, many = x.rows.length > 1;
    const title = c?.name || (many && x.target ? x.target : x.rows[0].product);
    return { ...x, title, sub: title === x.target ? '' : x.target, total: x.rows.reduce((s, t) => s + t.price, 0) };
  }).sort((a, b) => a.rows[0].date.localeCompare(b.rows[0].date));
}

function debtRow(t, solo) {
  const n = ageDays(t.date);
  return `<div class="drow" role="button" tabindex="0" data-goto="${t.id}"><div class="dm"><b>${esc(t.product)}</b><small>${fmtDay(t.date)} · <em class="age ${n >= 30 ? 'old' : n >= 7 ? 'mid' : ''}">${ageTxt(n)}</em></small></div>
    <span class="dprice">${rp(t.price)}</span>${solo ? '' : `<button class="ok" data-pay="${t.id}" aria-label="Tandai lunas">${ico('check')}</button>`}<i class="chev">›</i></div>`;
}

function debtCard(g, i) {
  const ids = g.rows.map(r => r.id).join(','), wa = waNumber(g.target), many = g.rows.length > 1;
  const msg = encodeURIComponent(reminderText(g.rows, book.settings.shop));
  return `<section class="debt" style="--i:${i + 1}"><div class="dhd"><span class="av" style="--cc:${catColor(g.title)}">${esc((g.title.trim()[0] ?? '?').toUpperCase())}</span>
    <div class="ctm"><b>${esc(g.title)}</b>${g.sub ? `<small>${esc(g.sub)}</small>` : ''}</div><div class="dtot"><b>${rp(g.total)}</b><small>${g.rows.length} transaksi</small></div></div>
    <div class="drows">${g.rows.map(t => debtRow(t, !many)).join('')}</div>
    <div class="dact"><button data-bill="${ids}">${ico('copy')} Salin tagihan</button>${wa ? `<a class="btn wa" href="https://wa.me/${wa}?text=${msg}" target="_blank" rel="noopener">${ico('chat')} WA</a>` : ''}<button class="primary" data-payall="${ids}">${many ? 'Lunasi semua' : 'Lunas'}</button></div></section>`;
}

function piutangPage() {
  const groups = piutangGroups(), rows = groups.flatMap(g => g.rows), total = rows.reduce((x, t) => x + t.price, 0);
  const old = rows.length ? ageDays(groups[0].rows[0].date) : 0;
  const head = '<div class="pg-head"><button data-pgx="1" aria-label="Kembali">←</button><b>Piutang</b></div>';
  if (!rows.length) return `${head}<div class="pg-body"><div class="done"><span class="okc">${ico('check')}</span><b>Semua sudah bayar</b><small>Tidak ada pembeli yang punya utang.</small></div></div>`;
  return `${head}<div class="pg-body"><div class="pcard debt" style="--i:0"><small>Total piutang</small><b class="big">${rp(total)}</b>
    <div class="sub">${groups.length} pembeli · ${rows.length} transaksi · tertua ${ageTxt(old).toLowerCase()}</div></div>
    ${groups.map(debtCard).join('')}<p class="foot">Ketuk transaksi untuk melihatnya di daftar Transaksi.</p></div>`;
}

// ---- Riwayat tambah saldo / modal ----
let histAcc = 'all';
const hrow = (h, recent = false) => `<button class="hrow ${h.reversed ? 'off' : ''}" data-hent="${h.id}"><span class="hic">${ico(ACC_ICON[h.account] ?? 'wallet')}</span>
  <div class="hm">${recent ? `<b>Tambah modal</b><small>${esc(SHORT[h.account])}${h.note ? ` · ${esc(h.note)}` : ''}</small><small>${dm(h.date)} ${h.date.slice(0, 4)}</small>` : `<b>${esc(SHORT[h.account])}</b><small>${h.awal ? 'Saldo awal' : 'Tambah saldo'}${h.note ? ` · ${esc(h.note)}` : ''}</small><small>${dm(h.date)} ${h.date.slice(0, 4)}${h.reversed ? ' · Dibatalkan' : ''}</small>`}</div><strong>+${rp(h.amount)}</strong></button>`;
function saldoHistPage() {
  const all = balanceHistory(book), codes = [...new Set([...all.map(h => h.account), ...(histAcc === 'all' ? [] : [histAcc])])];
  const rows = all.filter(h => histAcc === 'all' || h.account === histAcc), ok = rows.filter(h => !h.reversed), ym = today().slice(0, 7);
  const total = ok.reduce((x, h) => x + h.amount, 0), month = ok.filter(h => h.date.startsWith(ym)).reduce((x, h) => x + h.amount, 0), head = pgHead('Riwayat saldo & modal');
  if (!all.length) return `${head}<div class="pg-body"><div class="done"><span class="okc">${ico('plus')}</span><b>Belum ada riwayat</b><small>Saldo dan modal yang Anda tambahkan akan tercatat di sini.</small><button class="primary" data-newsaldo="1">Tambah saldo / modal</button></div></div>`;
  const groups = [];
  for (const h of rows) { const k = h.date.slice(0, 7); let g = groups.at(-1); if (g?.k !== k) { g = { k, items: [] }; groups.push(g); } g.items.push(h); }
  return `${head}<div class="pg-body"><div class="pcard m-omzet" style="--i:0"><small>Saldo & modal masuk${histAcc === 'all' ? '' : ` · ${esc(SHORT[histAcc])}`}</small><b class="big">${rp(total)}</b>
    <div class="sub">Bulan ini ${rp(month)} · ${ok.length} kali${rows.length > ok.length ? ` · ${rows.length - ok.length} dibatalkan` : ''}</div></div>
    <div class="fchips">${[['all', 'Semua'], ...codes.map(c => [c, SHORT[c]])].map(([c, l]) => `<button data-hacc="${c}" class="${histAcc === c ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>
    ${groups.length ? groups.map(g => `<div class="hg"><div class="hg-h"><b>${MON[+g.k.slice(5) - 1]} ${g.k.slice(0, 4)}</b><small>+${rp(g.items.filter(h => !h.reversed).reduce((x, h) => x + h.amount, 0))}</small></div><div class="hlist">${g.items.map(hrow).join('')}</div></div>`).join('') : '<p class="empty">Belum ada riwayat pada akun ini.</p>'}
    <p class="foot">Ketuk untuk melihat detail atau membatalkan.</p></div>`;
}
function openHist(id) {
  const h = balanceHistory(book).find(x => x.id === id); if (!h) return;
  draft = null;
  const s = SHEET_BOTTOM();
  s.innerHTML = `<div class="box gb"><div class="grab"></div><div class="dh"><h3>${h.awal ? 'Saldo awal' : 'Tambah saldo'}</h3><b class="in">+${rp(h.amount)}</b></div>
    <div class="kv"><span>Akun</span><b>${esc(SHORT[h.account])}</b></div><div class="kv"><span>Tanggal</span><b>${dm(h.date)} ${h.date.slice(0, 4)}</b></div>
    ${h.note ? `<div class="kv"><span>Catatan</span><b>${esc(h.note)}</b></div>` : ''}<div class="kv"><span>No. jurnal</span><b>${esc(h.id)}</b></div>
    ${h.reversed ? `<p class="cft">Sudah dibatalkan (jurnal pembalik ${esc(h.reversedId)}). Riwayat tetap tersimpan.</p>` : `<div class="acts"><button class="ghostdanger" data-hcancel="${h.id}">Batalkan penambahan</button></div>`}</div>`;
}
function askCancelBal(id) {
  const h = balanceHistory(book).find(x => x.id === id); if (!h || h.reversed) return;
  askConfirm({ title: 'Batalkan penambahan saldo?', text: `${rp(h.amount)} akan dikurangi dari ${SHORT[h.account]}. Riwayat tetap tersimpan sebagai dibatalkan. Yakin?`, ok: 'Batalkan', danger: true },
    () => act(() => { cancelBalance(book, id, today()); closeSheet(); toast('Penambahan saldo dibatalkan'); }));
}

// ---- Halaman rincian: kategori, isi kategori, dan kartu dashboard (omzet, untung kotor, dll) ----
const catKey = (kind, name) => `${kind}:${encodeURIComponent(name)}`;
function parseCat(v) {
  const t = String(v), i = t.indexOf(':'), kind = t.slice(0, i);
  if (!['income', 'expense'].includes(kind)) return null;
  try { return { kind, name: decodeURIComponent(t.slice(i + 1)) }; } catch { return null; }
}
// Pemilih periode: satu tombol ringkas + menu kecil yang terbuka tepat di bawah (atau di atas) tombolnya.
const DAY3 = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const dm = (d) => `${+d.slice(8)} ${MON[+d.slice(5, 7) - 1]}`;
function periodHint(k) {
  if (k === 'all') return 'Seluruh riwayat';
  if (k === 'custom' && !customRange) return 'Satu tanggal atau rentang';
  const [a, b] = range(k);
  if (k === 'day' || (k === 'custom' && a === b)) return `${DAY3[new Date(`${b}T00:00:00`).getDay()]}, ${dm(b)}`;
  if (k === 'custom') return `${customDays()} hari`;
  return a.slice(5, 7) === b.slice(5, 7) ? `${+a.slice(8)}–${dm(b)}` : `${dm(a)} – ${dm(b)}`;
}
function periodPick(share = false) {
  const opts = ['day', 'week', 'month', 'year', 'all'].map((k, i) => `<button type="button" role="option" aria-selected="${period === k}" data-period="${k}" class="pdd-opt ${period === k ? 'on' : ''}" style="--i:${i}"><span class="po-t"><b>${LABEL[k]}</b><small>${periodHint(k)}</small></span><i class="po-ck">${ico('check')}</i></button>`).join('');
  const cOn = period === 'custom' && customRange;
  const copt = `<button type="button" role="option" aria-selected="${!!cOn}" data-pcopen="1" class="pdd-opt ${cOn ? 'on' : ''}" style="--i:5"><span class="po-t"><b>${cOn ? esc(LABEL.custom) : 'Pilih tanggal…'}</b><small>${cOn ? (customDays() === 1 ? 'Satu tanggal' : `Rentang ${customDays()} hari`) : 'Satu tanggal atau rentang'}</small></span><i class="po-ck po-go">${cOn ? ico('check') : ico('cal')}</i></button>`;
  return `<div class="pdrow"><div class="pdd"><button type="button" class="pdd-btn" data-pdd="1" aria-haspopup="listbox" aria-expanded="false" aria-label="Pilih periode"><span class="pdd-ic">${ico('cal')}</span><b>${LABEL[period]}</b><span class="pdd-ch">${ico('chev')}</span></button><div class="pdd-menu" role="listbox" aria-label="Periode"><div class="pdd-list">${opts}${copt}</div><div class="pdd-calp"></div></div></div><span class="pdd-hint">${periodHint(period)}</span>${share ? `<button type="button" class="rcbtn" data-recap="1" aria-label="Bagikan rekap">${ico('share')}</button>` : ''}</div>`;
}
const periodSeg = periodPick;
// ---------- Kalender periode (satu tanggal / rentang) di dalam menu periode ----------
let cal = null;
const pad2 = (n) => String(n).padStart(2, '0');
function rememberPeriod() { try { localStorage.setItem('kb-last-period', JSON.stringify({ period, custom: customRange })); } catch {} }
function calStart() {
  const c = period === 'custom' && customRange ? customRange : { a: today(), b: today() };
  cal = { mode: c.a === c.b ? 'single' : 'range', a: c.a, b: c.b, step: 0, y: +c.b.slice(0, 4), m: +c.b.slice(5, 7) - 1 };
}
function calHtml() {
  const t0 = today(), lead = (new Date(cal.y, cal.m, 1).getDay() + 6) % 7, dim = new Date(cal.y, cal.m + 1, 0).getDate(), cells = [];
  for (let i = 0; i < lead; i++) cells.push('<i></i>');
  for (let d = 1; d <= dim; d++) {
    const k = `${cal.y}-${pad2(cal.m + 1)}-${pad2(d)}`, one = cal.a === cal.b;
    const cls = ['cd', k === t0 ? 'td' : '', k === cal.a || k === cal.b ? 'on' : '', !one && k === cal.a ? 'rs' : '', !one && k === cal.b ? 're' : '', !one && k > cal.a && k < cal.b ? 'in' : ''].filter(Boolean).join(' ');
    cells.push(`<button type="button" class="${cls}" data-pcday="${k}" ${k > t0 ? 'disabled' : ''} aria-label="${d} ${MON_FULL[cal.m]} ${cal.y}">${d}</button>`);
  }
  const n = Math.round((Date.parse(`${cal.b}T00:00:00Z`) - Date.parse(`${cal.a}T00:00:00Z`)) / 864e5) + 1;
  const sum = cal.step === 1 ? 'Ketuk tanggal akhir' : cal.a === cal.b ? fmtRange(cal.a, cal.b) : `${fmtRange(cal.a, cal.b)} · ${n} hari`;
  const nextOk = !(cal.y === +t0.slice(0, 4) && cal.m >= +t0.slice(5, 7) - 1) && (cal.y < +t0.slice(0, 4) || cal.m < +t0.slice(5, 7) - 1);
  return `<div class="cal-h"><button type="button" class="cal-back" data-pcback="1" aria-label="Kembali ke daftar periode">${ico('chev')}<span>Periode</span></button>
      ${seg3([['single', 'Satu tanggal'], ['range', 'Rentang']], cal.mode, 'data-pcmode')}</div>
    <div class="cal-nav"><button type="button" data-pcnav="-1" aria-label="Bulan sebelumnya">‹</button><b>${MON_FULL[cal.m]} ${cal.y}</b><button type="button" data-pcnav="1" aria-label="Bulan berikutnya" ${nextOk ? '' : 'disabled'}>›</button></div>
    <div class="cal-w">${['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'].map(x => `<span>${x}</span>`).join('')}</div>
    <div class="cal-g">${cells.join('')}</div>
    <div class="cal-q"><button type="button" data-pcq="yday">Kemarin</button><button type="button" data-pcq="d30">30 hari</button><button type="button" data-pcq="lm">Bulan lalu</button></div>
    <div class="cal-f"><span class="${cal.step === 1 ? 'hint' : ''}">${sum}</span><button type="button" class="primary" data-pcok="1" ${cal.step === 1 ? 'disabled' : ''}>Terapkan</button></div>`;
}
const calRender = (root) => { root.querySelector('.pdd-calp').innerHTML = calHtml(); };
const floorY = () => window.matchMedia?.('(min-width: 1024px)').matches ? window.innerHeight : document.querySelector('nav').getBoundingClientRect().top;
function calEnsureRoom(root) {                         // kalender cukup tinggi: gulirkan baris periode ke atas bila tidak muat di bawah tombol
  if (root.getBoundingClientRect().bottom + 8 + 400 > floorY() - 8) root.scrollIntoView({ block: 'start', behavior: 'smooth' });
}

function closePdd() {
  document.querySelectorAll('.pdd.open').forEach(r => { r.classList.remove('open', 'up'); r.querySelector('[data-pdd]')?.setAttribute('aria-expanded', 'false'); setTimeout(() => { if (!r.classList.contains('open')) r.classList.remove('cal'); }, 220); });
}
function togglePdd(btn) {
  const root = btn.closest('.pdd'), willOpen = !root.classList.contains('open');
  const cn = root.querySelector('.cl-now'); if (cn) cn.textContent = nowLabel();   // jam "sekarang" selalu segar saat menu dibuka
  closePdd();
  if (!willOpen) return;
  const menu = root.querySelector('.pdd-menu'), floor = floorY() - 8;
  root.classList.toggle('up', btn.getBoundingClientRect().bottom + 8 + menu.offsetHeight > floor);   // tidak muat di bawah → buka ke atas
  root.classList.add('open'); btn.setAttribute('aria-expanded', 'true');
}
document.addEventListener('pointerdown', e => { if (!e.target.closest?.('.pdd')) closePdd(); }, true);
const pgHead = (title) => `<div class="pg-head"><button data-pgx="1" aria-label="Kembali">←</button><b>${esc(title)}</b></div>`;
const kvr = (k, v, cls = '') => `<div class="kv"><span>${k}</span><b class="${cls}">${v}</b></div>`;
const byNewest = txOrder;   // tanggal terbaru dulu; dalam satu hari mengikuti urutan manual (bila diatur)
const maxOf = (arr) => arr.reduce((m, v) => Math.max(m, v), 0);

// Daftar transaksi di halaman rincian: urut terbaru / terbesar, dengan "tampilkan lebih banyak".
function txListBlock(rows, valFn, title = 'Transaksi') {
  const sorted = [...rows].sort(pgSort === 'big' ? (x, y) => valFn(y) - valFn(x) || byNewest(x, y) : byNewest), shown = sorted.slice(0, pgLim);
  return `<h3>${title} · ${rows.length}</h3>${seg3([['new', 'Terbaru'], ['big', 'Terbesar']], pgSort, 'data-sort')}
    ${shown.length ? `<div class="items">${shown.map(txItem).join('')}</div>` : '<p class="empty">Belum ada transaksi.</p>'}
    ${rows.length > shown.length ? `<button class="morebtn" data-more="1">Tampilkan lebih banyak (${rows.length - shown.length})</button>` : ''}`;
}

function secHtml(sec) {
  const tot = sec.items.reduce((x, i) => x + Math.abs(i.sum), 0), top = Math.max(1, ...sec.items.map(i => Math.abs(i.sum)));
  const body = sec.items.map(i => {
    const label = sec.acc ? (SHORT[i.key] ?? i.key) : i.key;
    const info = `${i.n} transaksi${sec.share && tot ? ` · ${Math.round(Math.abs(i.sum) / tot * 100)}%` : ''}${sec.margin && i.base > 0 ? ` · margin ${pct1(i.sum / i.base * 100)}%` : ''}`;
    const inner = `<div class="cbi"><div class="cbl"><span>${esc(label)}</span><b class="${i.sum < 0 ? 'out' : ''}">${rp(i.sum)}</b></div><div class="bar"><i style="width:${Math.round(Math.abs(i.sum) / top * 100)}%"></i></div><small>${info}</small></div>`;
    return i.cat ? `<button class="cbrow" data-cat="${esc(catKey(i.cat.kind, i.cat.name))}">${inner}<i class="chev">›</i></button>` : `<div class="cbrow">${inner}</div>`;
  }).join('');
  return `<section class="set"><h4>${esc(sec.title)}</h4>${body || '<p class="empty sm">Belum ada data pada periode ini.</p>'}</section>`;
}

function kategoriPage() {
  const [a, b] = range(), inc = catKind === 'income', list = categoryList(book, catKind, a, b);
  const tot = list.reduce((x, c) => x + c.sum, 0), n = list.reduce((x, c) => x + c.n, 0), net = list.reduce((x, c) => x + c.net, 0), top = Math.max(1, ...list.map(c => c.sum));
  const tabs = seg3([['income', 'Pendapatan'], ['expense', 'Pengeluaran']], catKind, 'data-ck').replace('class="seg3"', `class="seg3 k-${catKind}"`);
  const rowsHtml = list.map(c => `<button class="crow" data-cat="${esc(catKey(catKind, c.name))}" style="--cc:${catColor(c.name)}"><span class="cdot"></span>
    <div class="cm"><b>${esc(c.name)}</b><small>${c.n} transaksi${inc ? ` · untung ${rp(c.net)}` : ''}</small><div class="bar"><i style="width:${Math.round(c.sum / top * 100)}%"></i></div></div>
    <div class="cs"><b>${rp(c.sum)}</b><small>${tot ? Math.round(c.sum / tot * 100) : 0}%</small></div><i class="chev">›</i></button>`).join('');
  return `${pgHead('Kategori')}<div class="pg-body">${tabs}${periodSeg()}
    <div class="pcard ${inc ? 'm-omzet' : 'loss'}"><div class="ph1"><small>${inc ? 'Total penjualan' : 'Total pengeluaran'} · ${LABEL[period]}</small></div><b class="big">${rp(tot)}</b>
      <div class="sub">${n} transaksi · ${list.length} kategori${inc ? ` · untung ${rp(net)}` : ''}</div></div>
    ${rowsHtml ? `<div class="items crows">${rowsHtml}</div>` : `<p class="empty">Belum ada ${inc ? 'penjualan' : 'pengeluaran'} pada periode ini.</p>`}
    <p class="foot">Ketuk kategori untuk melihat isi dan penghitungannya.</p></div>`;
}

function catDetailPage() {
  const { kind, name } = pageArg, inc = kind === 'income', [a, b] = range(), d = categoryDetail(book, kind, name, a, b);
  const kvs = [
    ['Jumlah transaksi', `${d.n}`], [inc ? 'Total penjualan' : 'Total pengeluaran', rp(d.sum)], ['Rata-rata per transaksi', rp(d.avg)],
    ['Terbesar', rp(d.max)], ['Terkecil', rp(d.min)],
    ...(inc ? [['Modal', rp(d.cogs)], ['Biaya tambahan', rp(d.fee)], ['Untung bersih', rp(d.net), d.net < 0 ? 'out' : ''], ['Margin', d.margin === null ? '-' : `${pct1(d.margin)}%`]] : []),
    ...(d.unpaid.n ? [['Belum bayar (semua waktu)', `${d.unpaid.n} · ${rp(d.unpaid.sum)}`]] : []),
    ...Object.entries({ pending: 'Pending', gagal: 'Gagal', dibatalkan: 'Dibatalkan', refund: 'Refund' }).filter(([k]) => d.other[k]).map(([k, l]) => [l, `${d.other[k]} transaksi`]),
  ];
  const pr = d.prices.slice(0, 12), topN = Math.max(1, ...pr.map(x => x.n));
  const priceSec = pr.length ? `<section class="set"><h4>Rincian per nominal</h4>${pr.map(x => `<div class="cbrow"><div class="cbi"><div class="cbl"><span>${rp(x.key)} × ${x.n}</span><b>${rp(x.sum)}</b></div><div class="bar"><i style="width:${Math.round(x.n / topN * 100)}%"></i></div></div></div>`).join('')}${d.prices.length > 12 ? `<p class="cft">dan ${d.prices.length - 12} nominal lain</p>` : ''}</section>` : '';
  return `${pgHead(name)}<div class="pg-body">${periodSeg()}
    <div class="pcard ${inc ? 'm-omzet' : 'loss'}"><div class="ph1"><small>${esc(name)} · ${LABEL[period]}</small></div><b class="big">${rp(d.sum)}</b><div class="sub">${d.n} transaksi${inc && d.n ? ` · untung ${rp(d.net)}` : ''}</div></div>
    <button class="primary newcat k-${kind}" data-newcat="${esc(catKey(kind, name))}">+ Transaksi ${inc ? 'pendapatan' : 'pengeluaran'} kategori ini</button>
    <section class="set"><h4>Penghitungan</h4>${kvs.map(([k, v, c]) => kvr(k, v, c)).join('')}</section>
    ${priceSec}${txListBlock(d.history, t => t.price, 'Riwayat transaksi')}</div>`;
}

const METRICS = {
  omzet: { title: 'Omzet', cls: 'm-omzet', field: 'revenue', adj: 'rev', note: 'Total harga jual dari penjualan yang dihitung pada periode ini.' },
  gross: { title: 'Untung kotor', cls: '', field: 'gross', adj: 'gross', note: 'Omzet dikurangi modal, sebelum pengeluaran.' },
  modal: { title: 'Modal', cls: 'm-modal', field: 'cogs', adj: 'cogs', note: 'Harga pokok dari barang yang terjual.' },
  biaya: { title: 'Pengeluaran', cls: 'loss', field: 'expense', adj: 'exp', note: 'Biaya tambahan penjualan ditambah pengeluaran operasional.' },
  net: { title: 'Untung bersih', cls: '', field: 'net', adj: 'net', note: 'Untung kotor dikurangi pengeluaran.' },
};

function trxPage() {
  const [a, b] = range(), sc = statusCounts(book, a, b), all = live().filter(t => t.date >= a && t.date <= b);
  const rows = trxFilter === 'all' ? all : all.filter(t => t.status === trxFilter);
  const chips = [['all', 'Semua', all.length], ...['berhasil', 'pending', 'gagal', 'dibatalkan', 'refund'].map(k => [k, k[0].toUpperCase() + k.slice(1), sc[k]])]
    .filter(([k, , n]) => k === 'all' || n > 0 || trxFilter === k);
  const kinds = Object.entries(KIND).map(([k, l]) => { const rs = rows.filter(t => t.kind === k); return kvr(l, `${rs.length} transaksi · ${rp(rs.reduce((x, t) => x + t.price, 0))}`, { income: 'in', expense: 'out', transfer: 'tr' }[k]); });
  return `${pgHead('Transaksi')}<div class="pg-body">${periodSeg()}
    <div class="pcard m-omzet"><div class="ph1"><small>Transaksi · ${LABEL[period]}</small></div><b class="big">${sc.berhasil} / ${sc.gagal + sc.dibatalkan}</b><div class="sub">berhasil / gagal atau batal · ${all.length} tercatat</div></div>
    <div class="fchips">${chips.map(([k, l, n]) => `<button data-tf="${k}" class="${trxFilter === k ? 'on' : ''}">${l} ${n}</button>`).join('')}</div>
    <section class="set"><h4>Per jenis</h4>${kinds.join('')}</section>
    ${txListBlock(rows, t => t.price)}</div>`;
}

function metricPage() {
  const key = pageArg.key;
  if (key === 'trx') return trxPage();
  const M = METRICS[key];
  if (!M) return `${pgHead('Rincian')}<div class="pg-body"><p class="empty">Rincian tidak ditemukan.</p></div>`;
  const [a, b] = range(), rows = recognizedRows(book, a, b), rec = reconcile(book, a, b, rows), pl = rec.pl, s = rec.sum;
  const inc = rows.filter(t => t.kind === 'income'), exps = rows.filter(t => t.kind === 'expense'), withCost = inc.filter(t => t.cost > 0);
  const avg = (v, n) => n ? Math.round(v / n) : 0, pctOf = (v, base) => base > 0 ? `${pct1(v / base * 100)}%` : '-';
  const owedSum = piutangList().reduce((x, t) => x + t.price, 0), pr = prevRange(), val = pl[M.field];
  const chip = pr ? deltaChip(val, profitLoss(book, pr[0], pr[1])[M.field], pr[2], key === 'modal' || key === 'biaya') : '';
  let kvs, list, valFn;
  if (key === 'omzet') {
    kvs = [['Jumlah penjualan', `${inc.length}`], ['Rata-rata per penjualan', rp(avg(s.rev, inc.length))], ['Penjualan terbesar', rp(maxOf(inc.map(t => t.price)))], ['Untung kotor', rp(pl.gross)],
      ...(book.settings.basis === 'lunas' && owedSum ? [['Piutang (belum dihitung)', rp(owedSum)]] : [])];
    list = inc; valFn = t => t.price;
  } else if (key === 'gross') {
    kvs = [['Omzet', rp(pl.revenue)], ['Modal', rp(-pl.cogs)], ['Untung kotor', rp(pl.gross)], ['Margin kotor', pctOf(pl.gross, pl.revenue)]];
    list = inc; valFn = t => t.price - t.cost;
  } else if (key === 'modal') {
    kvs = [['Total modal', rp(pl.cogs)], ['Porsi dari omzet', pctOf(pl.cogs, pl.revenue)], ['Penjualan bermodal', `${withCost.length}`], ['Rata-rata modal', rp(avg(s.cogs, withCost.length))]];
    list = withCost; valFn = t => t.cost;
  } else if (key === 'biaya') {
    kvs = [['Biaya tambahan penjualan', rp(inc.reduce((x, t) => x + t.fee, 0))], ['Pengeluaran operasional', rp(exps.reduce((x, t) => x + t.price, 0))], ['Jumlah pengeluaran', `${exps.length}`], ['Porsi dari omzet', pctOf(pl.expense, pl.revenue)]];
    list = rows.filter(t => t.kind === 'expense' || t.fee > 0); valFn = t => t.kind === 'expense' ? t.price : t.fee;
  } else {
    kvs = [['Omzet', rp(pl.revenue)], ['Modal', rp(-pl.cogs)], ['Pengeluaran', rp(-pl.expense)], ['Untung bersih', rp(pl.net), pl.net < 0 ? 'out' : ''], ['Margin bersih', pctOf(pl.net, pl.revenue)]];
    list = rows; valFn = t => t.kind === 'income' ? t.price - t.cost - t.fee : -t.price;
  }
  const adj = rec.adj[M.adj], pend = rec.pend[M.adj];
  if (pend) kvs.push([pend > 0 ? 'Modal / biaya penjualan belum lunas' : 'Modal / biaya dihitung di hari transaksi', rp(pend)]);
  if (adj) kvs.push(['Selisih refund / pembatalan', rp(adj)]);
  return `${pgHead(M.title)}<div class="pg-body">${periodSeg()}
    <div class="pcard ${key === 'net' && val < 0 ? 'loss' : M.cls}"><div class="ph1"><small>${M.title} · ${LABEL[period]}</small>${chip}</div><b class="big">${rp(val)}</b><div class="sub">${M.note}</div></div>
    <section class="set"><h4>Ringkasan</h4>${kvs.map(([k, v, c]) => kvr(k, v, c)).join('')}${adj ? '<p class="cft">Angka utama dihitung dari jurnal. Daftar di bawah hanya memuat transaksi yang masih berhasil, jadi refund atau pembatalan yang dicatat pada tanggal berbeda muncul sebagai selisih.</p>' : ''}</section>
    ${metricSections(key, rows).map(secHtml).join('')}
    ${txListBlock(list, valFn)}</div>`;
}

const seg3 = (items, cur, attr) => `<div class="seg3" style="--n:${items.length};--i:${Math.max(0, items.findIndex(x => x[0] === cur))}"><i></i>${items.map(([v, l]) => `<button ${attr}="${v}" class="${v === cur ? 'on' : ''}">${l}</button>`).join('')}</div>`;
const BASIS_NOTE = { lunas: 'Pendapatan dari penjualan yang belum dibayar baru dihitung pada hari pembeli melunasi. Modal dan biaya penjualannya tetap dihitung sejak hari transaksi.', transaksi: 'Penjualan langsung dihitung pada hari transaksi, walau pembeli belum membayar.' };

function settingsPage() {
  const sec = (i, title, body, cls = '') => `<section class="set ${cls}" style="--i:${i}"><h4>${title}</h4>${body}</section>`;
  return `<div class="pg-head"><button data-pgx="1" aria-label="Kembali">←</button><b>Pengaturan</b></div><div class="pg-body">
    ${sec(0, 'Tampilan', seg3([['auto', 'Otomatis'], ['light', 'Terang'], ['dark', 'Gelap']], theme, 'data-theme-set'))}
    ${sec(1, 'Pendapatan dihitung saat', seg3([['lunas', 'Sudah lunas'], ['transaksi', 'Transaksi']], book.settings.basis, 'data-basis') + `<p class="cft" id="basisnote">${BASIS_NOTE[book.settings.basis]}</p>`)}
    ${sec(2, 'Nama usaha', `<div class="addcat"><input id="shopin" maxlength="30" value="${esc(book.settings.shop)}" placeholder="Tampil di atas aplikasi" autocomplete="off"><button data-saveshop="1">Simpan</button></div>`)}
    ${sec(3, 'Periode saat membuka aplikasi', startPeriodHtml())}
    ${sec(4, 'Target bulanan', `<div class="addcat"><input id="goalin" inputmode="numeric" maxlength="16" value="${book.settings.goal ? new Intl.NumberFormat('id-ID').format(book.settings.goal) : ''}" placeholder="mis. 5.000.000 (kosong = tanpa target)" autocomplete="off"><button data-savegoal="1">Simpan</button></div>${seg3([['net', 'Untung bersih'], ['revenue', 'Omzet']], book.settings.goalKind, 'data-goalkind')}<p class="cft">Kartu target di Dashboard menampilkan capaian bulan berjalan, kebutuhan per hari, dan proyeksi akhir bulan.</p>`)}
    ${sec(5, 'Data', `<div class="bento"><button class="tile act" data-bkexp="1"><span class="ic">${ico('download')}</span><b>Ekspor cadangan</b></button><button class="tile act" data-bkimp="1"><span class="ic">${ico('upload')}</span><b>Impor cadangan</b></button></div>
      <p class="cft">Simpan cadangan berkala agar data aman jika HP hilang atau diganti.</p>`)}
    ${sec(6, 'Zona bahaya', '<button class="dangerlink flat" data-reset="1">Hapus semua data</button>', 'zone')}
    <p class="foot" style="--i:7">Katastic v${VERSION} · data tersimpan di perangkat ini</p></div>`;
}

const SP_OPTS = [['day', 'Hari ini', 'Transaksi hari ini saja'], ['week', '7 hari terakhir', 'Bawaan · enam hari lalu sampai hari ini'], ['month', 'Bulan ini', 'Tanggal 1 sampai hari ini'], ['year', 'Tahun ini', 'Januari sampai hari ini'], ['all', 'Semua waktu', 'Seluruh riwayat'], ['last', 'Terakhir dipakai', 'Mengingat pilihan terakhir Anda'], ['custom', 'Tanggal tertentu', 'Satu tanggal atau rentang tetap']];
const spLabel = () => { const c = book.settings.startCustom, v = book.settings.startPeriod; return v === 'custom' && c ? fmtRange(c.a, c.b) : (SP_OPTS.find(o => o[0] === v) ?? SP_OPTS[1])[1]; };
function startPeriodHtml() {
  const cur = book.settings.startPeriod ?? 'week', c = book.settings.startCustom;
  return `<div class="pdd fdd sdd"><button type="button" class="fbtn act" data-pdd="1" aria-haspopup="listbox" aria-expanded="false"><span>Saat aplikasi dibuka</span><b id="splab">${esc(spLabel())}</b>${ico('chev')}</button>
    <div class="pdd-menu" role="listbox" aria-label="Periode awal">${SP_OPTS.map(([v, l, sub], i) => `<button type="button" role="option" aria-selected="${v === cur}" data-sp="${v}" class="pdd-opt ${v === cur ? 'on' : ''}" style="--i:${i}"><span class="po-t"><b>${l}</b><small>${sub}</small></span><i class="po-ck">${ico('check')}</i></button>`).join('')}</div></div>
    <div class="spc ${cur === 'custom' ? 'open' : ''}"><div class="spc-i"><div class="spc-g"><label>Dari<input type="date" id="spa" value="${c?.a ?? ''}" max="${today()}"></label><label>Sampai<input type="date" id="spb" value="${c && c.b !== c.a ? c.b : ''}" max="${today()}"></label></div>
      <p class="cft">Kosongkan “Sampai” untuk memilih satu tanggal saja.</p><button type="button" class="spsave" data-spsave="1">Simpan tanggal</button></div></div>
    <p class="cft">Periode ini dipakai di Dashboard dan halaman rincian setiap kali aplikasi dibuka. Anda tetap bisa mengganti periode kapan saja.</p>`;
}
function syncSp() {
  $('#splab') && ($('#splab').textContent = spLabel());
  document.querySelectorAll('.sdd .pdd-opt').forEach(o => { const on = o.dataset.sp === book.settings.startPeriod; o.classList.toggle('on', on); o.setAttribute('aria-selected', on); });
  $('.spc')?.classList.toggle('open', book.settings.startPeriod === 'custom');
}

const PAGES = () => ({ saldohist: saldoHistPage, settings: settingsPage, piutang: piutangPage, kategori: kategoriPage, catdetail: catDetailPage, metric: metricPage });
function renderPage(again = false, keep = again) {
  const p = $('#page'), fresh = p.hidden || p.classList.contains('out');
  const sc = keep ? (p.querySelector('.pg-body')?.scrollTop ?? 0) : 0;
  pgTok++; p.className = fresh && !again ? 'page' : 'page still'; p.hidden = false;
  p.innerHTML = (PAGES()[pageName] ?? piutangPage)();
  if (sc) { const nb = p.querySelector('.pg-body'); if (nb) nb.scrollTop = sc; }
}
const pgSnap = () => ({ name: pageName, arg: pageArg, sc: $('#page .pg-body')?.scrollTop ?? 0, sort: pgSort, lim: pgLim, tf: trxFilter, ck: catKind });
function openPage(name, arg = {}) {
  const open = !!pageName && !$('#page').hidden;
  if (open) pgStack.push(pgSnap()); else pgStack = [];
  pageName = name; pageArg = arg; pgSort = 'new'; pgLim = 30; trxFilter = 'all';
  if (name === 'kategori') catKind = arg.kind ?? 'income';
  if (name === 'saldohist') histAcc = arg.acc ?? 'all';
  renderPage(open, false);
}
function pageBack() {
  const st = pgStack.pop();
  if (!st) { closePage(); return; }
  pageName = st.name; pageArg = st.arg; pgSort = st.sort; pgLim = st.lim; trxFilter = st.tf; catKind = st.ck;
  renderPage(true, false);
  const b = $('#page .pg-body'); if (b) b.scrollTop = st.sc;
}
function closePage() {
  if (!pageName) return;
  pageName = null; pgStack = [];
  const p = $('#page'), my = ++pgTok; p.classList.add('out');
  setTimeout(() => { if (pgTok === my) { p.hidden = true; p.innerHTML = ''; p.classList.remove('out'); } }, 240);
}

// Dari daftar piutang langsung ke barisnya di tab Transaksi, dengan sorotan sebentar.
function goToTx(id) {
  const t = book.transactions.find(x => x.id === id); if (!t || t.deleted) return;
  view = 'tx'; txTab = 'day'; txq = ''; txSearch = false; mon = { y: +t.date.slice(0, 4), m: +t.date.slice(5, 7) - 1 };
  render(); closePage();
  setTimeout(() => {
    const el = document.querySelector(`#main [data-open="${t.id}"]`); if (!el) return;
    el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('flash');
    setTimeout(() => el.classList.remove('flash'), 2400);
  }, 300);
}

function applyTheme() {
  const r = document.documentElement;
  if (theme === 'auto') r.removeAttribute('data-theme'); else r.dataset.theme = theme;
  try { localStorage.setItem('kb-theme', theme); } catch {}
}
function slideSeg(btn) {
  const bar = btn.closest('.seg3'), all = [...bar.querySelectorAll('button')];
  all.forEach(b => b.classList.toggle('on', b === btn)); bar.style.setProperty('--i', all.indexOf(btn));
}

const ctStats = (c) => {
  const ts = c.number ? live().filter(t => numKey(t.target) === numKey(c.number)) : [];
  return ts.length ? `${ts.length} transaksi · terakhir ${fmtDay(ts.map(t => t.date).sort().at(-1))}` : 'Belum ada transaksi';
};

function ctCard(c) {
  const nm = c.name || c.number;
  return `<div class="ct"><div class="cth"><span class="av" style="--cc:${catColor(nm)}">${esc(nm.trim()[0].toUpperCase())}</span>
    <div class="ctm"><b>${esc(nm)}</b>${c.label ? `<em class="lb">${esc(c.label)}</em>` : ''}</div><button class="icb" data-ctedit="${c.id}" aria-label="Ubah">${ico('edit')}</button></div>
    ${c.number ? `<button class="numcopy" data-copy="${esc(c.number)}"><span>${esc(c.number)}</span>${ico('copy')}</button>` : ''}
    ${c.note ? `<p class="ctn">${esc(c.note)}</p>` : ''}
    <div class="ctf"><small>${ctStats(c)}</small><button class="link" data-ctnew="${c.id}">+ Transaksi</button></div></div>`;
}

let pSort = 'nama';
// Statistik per produk dari semua transaksi pendapatan: jumlah terjual dan untung (hanya bila modal diisi).
function prStats() {
  const m = new Map();
  for (const t of live()) if (t.kind === 'income') for (const i of t.items ?? []) {
    const k = i.n.toLowerCase(), r = m.get(k) ?? { q: 0, rev: 0, gain: 0 };
    r.q += i.q; r.rev += i.q * i.p; if (i.c) r.gain += i.q * (i.p - i.c); m.set(k, r);
  }
  return m;
}
function prCard(x, st) {
  const r = st.get(x.name.toLowerCase());
  return `<div class="ct"><div class="cth"><span class="av" style="--cc:${catColor(x.name)}">${esc(x.name.trim()[0].toUpperCase())}</span>
    <div class="ctm"><b>${esc(x.name)}</b></div><button class="icb" data-predit="${x.id}" aria-label="Ubah">${ico('edit')}</button></div>
    <div class="ctf"><small>${x.price ? rp(x.price) : 'Harga belum diisi'}${x.cost ? ` · modal ${rp(x.cost)}` : ''}</small></div>
    <div class="prst">${r ? `<span><b>${r.q}×</b> terjual</span><span>omzet <b>${rp(r.rev)}</b></span>${r.gain ? `<span class="up">untung <b>${rp(r.gain)}</b></span>` : ''}` : '<span>Belum pernah terjual</span>'}</div></div>`;
}
function openPr(id = null) {
  const x = id ? book.products.find(v => v.id === id) : null; if (id && !x) return;
  draft = null;
  const s = SHEET_BOTTOM();
  s.innerHTML = `<form id="pf" class="box" data-id="${x ? x.id : ''}"><h3>${x ? 'Ubah produk' : 'Produk baru'}</h3>
    <label class="cfld"><span>Nama produk</span><input name="name" maxlength="40" value="${x ? esc(x.name) : ''}" placeholder="Mis. Pulsa 10rb, Voucher Garena" autocomplete="off"></label>
    <label class="cfld"><span>Harga jual</span><input name="price" inputmode="numeric" value="${nf(x?.price)}" placeholder="0" autocomplete="off"></label>
    <label class="cfld"><span>Modal (opsional)</span><input name="cost" inputmode="numeric" value="${nf(x?.cost)}" placeholder="0" autocomplete="off"></label>
    <div class="acts"><button type="button" data-x="1">Batal</button>${x ? `<button type="button" class="ghostdanger" data-prdel="${x.id}">Hapus</button>` : ''}<button class="primary">Simpan</button></div></form>`;
}
function notesBody() {
  if (nTab === 'pr') {
    const pl = searchProducts(book, nq), st = prStats(), g = (x) => st.get(x.name.toLowerCase()) ?? { q: 0, gain: 0 };
    if (pSort === 'laris') pl.sort((a, b) => g(b).q - g(a).q); else if (pSort === 'untung') pl.sort((a, b) => g(b).gain - g(a).gain);
    if (pl.length) return `${pl.length > 1 ? seg3([['nama', 'A–Z'], ['laris', 'Terlaris'], ['untung', 'Untung']], pSort, 'data-psort') : ''}<p class="rescount">${pl.length} produk</p><div class="ctgrid">${pl.map(x => prCard(x, st)).join('')}</div>`;
    return nq.trim() ? '<p class="empty">Tidak ada produk yang cocok.</p>' : `<div class="hint"><b>Belum ada produk</b><small>Simpan produk yang sering dibeli beserta harganya. Saat mencatat penjualan, tinggal ketuk untuk menambahkannya.</small></div>`;
  }
  const list = searchContacts(book, nq);
  if (list.length) return `<p class="rescount">${list.length} pelanggan</p><div class="ctgrid">${list.map(ctCard).join('')}</div>`;
  return nq.trim() ? '<p class="empty">Tidak ada catatan yang cocok.</p>'
    : `<div class="hint"><b>Belum ada catatan</b><small>Simpan nomor HP, ID pelanggan PLN, ID game, dll agar tidak perlu bertanya lagi. Ketuk + untuk menambah.</small></div>`;
}

function notesView() {
  return `${seg3([['ct', 'Pelanggan'], ['pr', 'Produk']], nTab, 'data-ntab')}<div class="search">${ico('search')}<input id="nq" type="search" placeholder="${nTab === 'pr' ? 'Cari produk' : 'Cari nama / nomor / label'}" value="${esc(nq)}" autocomplete="off"></div>
    <div id="nbody">${notesBody()}</div><button class="fab" data-newct="1" aria-label="${nTab === 'pr' ? 'Produk baru' : 'Catatan baru'}">+</button>`;
}

function openCt(id = null, pre = {}) {
  const c = id ? book.contacts.find(x => x.id === id) : null; if (id && !c) return;
  const v = c ?? { name: '', number: '', label: '', note: '', ...pre };
  draft = null;
  const s = SHEET_BOTTOM();
  s.innerHTML = `<form id="cf" class="box" data-id="${c ? c.id : ''}"><h3>${c ? 'Ubah catatan' : 'Catatan baru'}</h3>
    <label class="cfld"><span>Nama</span><input name="name" maxlength="40" value="${esc(v.name)}" placeholder="Mis. Bu Rina" autocomplete="off"></label>
    <label class="cfld"><span>No. HP / ID pelanggan</span><input name="number" maxlength="40" value="${esc(v.number)}" placeholder="0812…, ID PLN, ID game" autocomplete="off"></label>
    <label class="cfld"><span>Label</span><input name="label" maxlength="20" list="lbls" value="${esc(v.label)}" placeholder="Pulsa, PLN, Game…" autocomplete="off"></label>
    <datalist id="lbls">${book.categories.income.map(x => `<option value="${esc(x)}">`).join('')}</datalist>
    <label class="cfld"><span>Catatan</span><textarea name="note" rows="3" maxlength="200" placeholder="Opsional, mis. operator atau tanggal bayar langganan">${esc(v.note)}</textarea></label>
    <div class="acts"><button type="button" data-x="1">Batal</button>${c ? `<button type="button" class="ghostdanger" data-ctdel="${c.id}">Hapus</button>` : ''}<button class="primary">Simpan</button></div></form>`;
}

function newFromContact(id) {
  const c = book.contacts.find(x => x.id === id); if (!c) return;
  openForm('income');
  draft.target = c.number; draft.name = c.name;
  if (book.categories.income.includes(c.label)) draft.category = c.label;
  renderForm();
}

// ---- Akun: kelola & hapus ----
function openAcc(code) {
  const a = book.accounts[code]; if (!a) return;
  const bal = balance(book, code), n = live().filter(t => t.method === code || t.source === code).length;
  draft = null;
  const s = SHEET_BOTTOM();
  s.innerHTML = `<div class="box"><div class="dh"><h3>${esc(SHORT[code])}</h3><b>${rp(bal)}</b></div>
    <div class="kv"><span>Transaksi terkait</span><b>${n}</b></div>
    ${PROTECTED_ACCOUNTS.includes(code) ? '<p class="cft">Kas Tunai adalah akun utama dan tidak bisa dihapus.</p>' : ''}
    <div class="acts"><button class="primary" data-addsaldo="${code}">Tambah saldo</button><button data-hist="${code}">Riwayat saldo</button>${PROTECTED_ACCOUNTS.includes(code) ? '' : `<button class="ghostdanger" data-accdel="${code}">Hapus akun</button>`}<button data-x="1">Tutup</button></div></div>`;
}

function openAccDel(code) {
  const bal = balance(book, code);
  const openRef = live().some(t => (t.method === code || t.source === code) && (t.status === 'pending' || (t.kind === 'income' && t.status === 'berhasil' && t.paid === false)));
  const dests = activeCodes().filter(c => c !== code);
  const need = bal > 0 || openRef;
  const s = SHEET_BOTTOM();
  s.innerHTML = `<div class="box"><h3>Hapus akun ${esc(SHORT[code])}?</h3>
    <p class="cft">${bal > 0 ? `Saldo ${rp(bal)} akan dipindahkan ke akun di bawah. ` : ''}${openRef && bal === 0 ? 'Ada transaksi yang belum selesai pada akun ini, akan dialihkan ke akun di bawah. ' : ''}Riwayat transaksi dan laporan tidak berubah, akun bisa diaktifkan lagi dari menu Kas.</p>
    ${need ? `<div class="fr col"><span>Pindahkan ke</span>${pick('moveTo', dests.map(c => [c, SHORT[c]]), dests.includes('1101') ? '1101' : dests[0])}</div>` : ''}
    <div class="acts"><button data-x="1">Batal</button><button class="danger" data-accdo="${code}">Hapus akun</button></div></div>`;
}

// ---- Cadangan data ----
async function exportBackup() {
  let text; try { text = await backupText(); } catch { text = snapshot(book); toast('Gambar tidak ikut dicadangkan'); }
  const name = `katastic-${today()}.json`, file = new File([text], name, { type: 'application/json' });
  try { if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: 'Cadangan Katastic' }); return; } }
  catch (e) { if (e.name === 'AbortError') return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(file); a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast('Cadangan diunduh');
}

async function importBackup(file) {
  if (!file) return;
  if (demo) { toast('Keluar dari mode contoh dulu'); return; }
  try {
    const raw = JSON.parse(await file.text()), pack = (raw && typeof raw === 'object' && raw._files) || {};
    if (raw && typeof raw === 'object') delete raw._files;
    const next = restore(raw), nImg = Object.keys(pack).length;
    askConfirm({ title: 'Ganti semua data?', text: `Cadangan berisi ${next.transactions.filter(t => !t.deleted).length} transaksi, ${next.contacts.length} catatan${nImg ? `, dan ${nImg} gambar` : ''}. Data di perangkat ini akan diganti.`, ok: 'Ganti data', danger: true },
      async () => {
        try { if (nImg) await putPack(pack); } catch { toast('Gambar cadangan gagal dipulihkan. Data lama tidak diubah.'); return; }
        if (await act(() => { book = next; toast('Cadangan dipulihkan'); })) pruneFiles(true);
      });
  } catch (e) { toast(`File cadangan tidak valid: ${e.message}`); }
}

const viewHtml = (v) => (demo ? '<div class="demo"><span>Mode contoh: data tidak disimpan</span><button data-demoexit="1">Keluar</button></div>' : '') + { home, tx: txView, notes: notesView, kas: kasView }[v]();
function render() {
  if (!book) return;
  $('#main').className = ''; $('#main').innerHTML = viewHtml(view);
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.v === view));
  $('#shop').textContent = book.settings.shop || 'Katastic';
  document.querySelectorAll('.chscroll').forEach(el => { el.scrollLeft = el.scrollWidth; });
  if (pageName && pageName !== 'settings') renderPage(true);
  syncSel();
}

// ---- Lampiran gambar, baca dari gambar (OCR), penampil, dan menu pilihan slide-up ----
const urlCache = new Map();
let viewerSt = null, ocrSt = null, ocrRun = 0, chooseOpts = [], chooseFn = null, fileTarget = null, detailId = null, lastTap = 0;
const fmtSize = (n) => n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`;
const toRec = async (blob, thumb) => ({ type: blob.type, buf: await blob.arrayBuffer(), tType: thumb.type, tBuf: await thumb.arrayBuffer() });
const hideSheet = (el) => {
  if (el.hidden) return;
  el.classList.add('out');
  setTimeout(() => { if (el.classList.contains('out')) { el.hidden = true; el.innerHTML = ''; el.classList.remove('out'); } }, 200);
};

async function blobOf(id, thumb) {
  const p = draft?.pend?.get(id);
  if (p) return thumb ? p.thumb : p.blob;
  const r = await getFile(id);
  return r ? new Blob([thumb ? r.tBuf : r.buf], { type: thumb ? r.tType : r.type }) : null;
}
async function urlFor(id, thumb) {
  const key = `${thumb ? 't' : 'f'}:${id}`;
  if (urlCache.has(key)) return urlCache.get(key);
  const b = await blobOf(id, thumb); if (!b) return null;
  const u = URL.createObjectURL(b); urlCache.set(key, u); return u;
}
function dropUrls(ids, full = true) {
  for (const id of ids) for (const k of full ? [`t:${id}`, `f:${id}`] : [`f:${id}`]) { const u = urlCache.get(k); if (u) { URL.revokeObjectURL(u); urlCache.delete(k); } }
}
// Isi <img data-fid> dari penyimpanan (data-full="1" = ukuran penuh). Gambar yang hilang diganti penanda.
function hydrate(root = document) {
  root.querySelectorAll('img[data-fid]:not([src])').forEach(im => {
    const id = im.dataset.fid, thumb = im.dataset.full !== '1', hit = urlCache.get(`${thumb ? 't' : 'f'}:${id}`);
    if (hit) { im.src = hit; return; }
    const miss = () => { if (im.isConnected) { const m = document.createElement('span'); m.className = 'thmiss'; m.textContent = 'Gambar tidak ada di perangkat ini'; im.replaceWith(m); } };
    urlFor(id, thumb).then(u => { if (!im.isConnected) return; if (u) im.src = u; else miss(); }).catch(miss);
  });
}

async function prepImage(file) {
  if (!String(file.type).startsWith('image/')) throw new Error('File harus berupa gambar');
  if (file.size > 25e6) throw new Error('Gambar terlalu besar (maksimal 25 MB)');
  let src, w, h;
  try { src = await createImageBitmap(file); w = src.width; h = src.height; }
  catch {
    src = await new Promise((res, rej) => { const im = new Image(), u = URL.createObjectURL(file); im.onload = () => { URL.revokeObjectURL(u); res(im); }; im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Gambar tidak bisa dibaca')); }; im.src = u; });
    w = src.naturalWidth; h = src.naturalHeight;
  }
  if (!w || !h) throw new Error('Gambar tidak bisa dibaca');
  const draw = (max) => {
    const k = Math.min(1, max / Math.max(w, h)), cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(w * k)); cv.height = Math.max(1, Math.round(h * k));
    const c = cv.getContext('2d'); c.fillStyle = '#fff'; c.fillRect(0, 0, cv.width, cv.height); c.drawImage(src, 0, 0, cv.width, cv.height); return cv;
  };
  const jpg = (cv, q) => new Promise((res, rej) => cv.toBlob(b => b ? res(b) : rej(new Error('Gagal memproses gambar')), 'image/jpeg', q));
  const big = draw(1600), blob = await jpg(big, 0.82), thumb = await jpg(draw(240), 0.7);
  src.close?.();
  const name = ((file.name || 'gambar').replace(/\.[^.]+$/, '').slice(0, 50) || 'gambar') + '.jpg';
  return { meta: { id: newFileId(), name, w: big.width, h: big.height, size: blob.size, at: new Date().toISOString(), text: '' }, blob, thumb };
}

function pickImages(o) {
  if (demo || !storage) { toast('Lampiran gambar tidak tersedia di mode contoh atau tanpa penyimpanan perangkat'); return; }
  const have = o.ctx === 'draft' ? draft?.files.length ?? 0 : filesOf(book.transactions.find(x => x.id === o.txId)).length;
  if (have >= MAX_FILES) { toast(`Maksimal ${MAX_FILES} gambar per transaksi`); return; }
  fileTarget = o; $('#fin').click();
}

async function handleFiles(list) {
  const o = fileTarget; fileTarget = null; if (!o || !list.length) return;
  const d = draft, tx = o.ctx === 'tx' ? book.transactions.find(x => x.id === o.txId) : null;
  if (o.ctx === 'draft' ? !d : !tx || tx.deleted) return;
  const room = MAX_FILES - (o.ctx === 'draft' ? d.files.length : filesOf(tx).length), picked = list.slice(0, room);
  toast(list.length > room ? `Hanya ${room} gambar yang ditambahkan (maksimal ${MAX_FILES})` : 'Memproses gambar…');
  const got = [];
  for (const f of picked) { try { got.push(await prepImage(f)); } catch (e) { toast(e.message); } }
  if (!got.length) return;
  if (o.ctx === 'draft') {
    if (draft !== d) return;
    for (const r of got) { d.files.push(r.meta); d.pend.set(r.meta.id, { blob: r.blob, thumb: r.thumb }); }
    renderForm();
    if (o.read) startOcr(got[0].meta.id, 'draft');
    return;
  }
  try { for (const r of got) await putFile(r.meta.id, await toRec(r.blob, r.thumb)); }
  catch { await delFiles(got.map(r => r.meta.id)).catch(() => {}); toast('Gagal menyimpan gambar di perangkat'); return; }
  const ok = await act(() => setFiles(book, tx.id, [...filesOf(tx), ...got.map(r => r.meta)]));
  if (!ok) await delFiles(got.map(r => r.meta.id)).catch(() => {});
  else if (detailId === tx.id && !$('#sheet').hidden) openDetail(tx.id);
}

// Hapus gambar yang tidak dirujuk buku lagi. Gambar yang baru dibuat (< 10 menit) dilewati.
async function pruneFiles(all = false) {
  if (!storage || demo) return;
  try {
    const keep = fileIdsInUse(book);
    await delFiles((await fileKeys()).filter(k => !keep.has(k) && (all || !(Date.now() - parseInt(String(k).slice(1, 9), 36) < 6e5))));
  } catch {}
}

// Struk berupa gambar (canvas 2D, putih seperti kertas), bisa dibagikan atau disimpan sebagai PNG.
async function strukBlob(t, shop) {
  const S = 3, W = 380, P = 26, tr = t.kind === 'transfer', col = { income: '#2563eb', expense: '#c8242b', transfer: '#7c4dde' }[t.kind];
  const F = (w, z) => `${w} ${z}px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`;
  const rows = [['No', trxNo(t)], ['Tanggal', `${t.date}${t.time ? ' ' + t.time : ''}`], ['Jenis', KIND[t.kind]]];
  if (tr) rows.push(['Dari', SHORT[t.source]], ['Ke', SHORT[t.method]]);
  else { rows.push(['Produk', t.product]); if (t.category !== t.product) rows.push(['Kategori', t.category]); }
  if (t.items?.length) rows.push(['Barang', itemsLine(t.items)]);
  if (t.target) rows.push(['No./ID', t.target]);
  if (t.note) rows.push(['Catatan', t.note]);
  const status = t.kind === 'income' && ['pending', 'berhasil'].includes(t.status) ? (t.paid === false ? 'BELUM BAYAR' : 'LUNAS') : t.status !== 'berhasil' ? t.status.toUpperCase() : '';
  const wrap = (c, text, maxW) => {
    const out = []; let cur = '';
    for (const w of String(text).split(/\s+/)) {
      let word = w;
      while (c.measureText(word).width > maxW) { let k = word.length; while (k > 1 && c.measureText(word.slice(0, k)).width > maxW) k--; if (cur) { out.push(cur); cur = ''; } out.push(word.slice(0, k)); word = word.slice(k); }
      const nx = cur ? `${cur} ${word}` : word;
      if (c.measureText(nx).width <= maxW) cur = nx; else { out.push(cur); cur = word; }
    }
    if (cur) out.push(cur); return out;
  };
  const run = (c) => {
    let y = 0; c.textBaseline = 'alphabetic';
    c.fillStyle = col; c.fillRect(0, 0, W, 6); y = 44;
    c.textAlign = 'center'; c.fillStyle = '#16181d'; c.font = F(800, 20);
    for (const ln of wrap(c, (shop || 'Katastic').toUpperCase(), W - 2 * P)) { c.fillText(ln, W / 2, y); y += 25; }
    c.fillStyle = '#6a707c'; c.font = F(600, 11); c.fillText('S T R U K   T R A N S A K S I', W / 2, y + 2); y += 22;
    const dash = () => { c.save(); c.strokeStyle = '#c9ccd3'; c.setLineDash([5, 4]); c.lineWidth = 1; c.beginPath(); c.moveTo(P, y); c.lineTo(W - P, y); c.stroke(); c.restore(); y += 20; };
    dash();
    for (const [k, v] of rows) {
      c.font = F(500, 13); c.fillStyle = '#6a707c'; c.textAlign = 'left'; c.fillText(k, P, y);
      const lw = c.measureText(k).width + 16; c.font = F(650, 13.5); c.fillStyle = '#16181d'; c.textAlign = 'right';
      const lines = wrap(c, v, W - 2 * P - lw);
      lines.forEach((ln, i) => c.fillText(ln, W - P, y + i * 18)); y += lines.length * 18 + 8;
    }
    y += 2; dash();
    const money = (k, v, big, color = '#16181d') => {
      c.textAlign = 'left'; c.font = F(big ? 800 : 500, big ? 14 : 13); c.fillStyle = big ? '#16181d' : '#6a707c'; c.fillText(k, P, y + (big ? 8 : 0));
      c.textAlign = 'right'; c.font = F(big ? 800 : 650, big ? 26 : 13.5); c.fillStyle = color; c.fillText(rp(v), W - P, y + (big ? 8 : 0)); y += big ? 40 : 22;
    };
    if (tr) { money('Jumlah', t.price, false); if (t.fee) money('Pajak', t.fee, false); money('TOTAL', t.price + (t.fee ?? 0), true, col); }
    else money('TOTAL', t.price, true, col);
    if (status) {
      c.font = F(800, 12); const w = c.measureText(status).width + 28, x = (W - w) / 2;
      c.fillStyle = status === 'LUNAS' ? '#e3f4e9' : status === 'BELUM BAYAR' ? '#fdf0d9' : '#fcebec';
      c.beginPath(); c.roundRect(x, y - 4, w, 26, 13); c.fill();
      c.fillStyle = status === 'LUNAS' ? '#15803d' : status === 'BELUM BAYAR' ? '#b45309' : '#c8242b'; c.textAlign = 'center'; c.fillText(status, W / 2, y + 14); y += 40;
    }
    dash(); c.textAlign = 'center'; c.fillStyle = '#6a707c'; c.font = F(500, 12.5); c.fillText('Terima kasih', W / 2, y); y += 28;
    return y;
  };
  const probe = document.createElement('canvas'); probe.width = W; probe.height = 1600;
  const H = run(probe.getContext('2d'));
  const cv = document.createElement('canvas'); cv.width = W * S; cv.height = H * S;
  const c = cv.getContext('2d'); c.scale(S, S); c.fillStyle = '#fff'; c.fillRect(0, 0, W, H); run(c);
  return new Promise((res, rej) => cv.toBlob(b => b ? res(b) : rej(new Error('Gagal membuat gambar')), 'image/png'));
}
const revokeStruk = () => { if (strukUrl) URL.revokeObjectURL(strukUrl); strukUrl = null; strukCache = null; };
async function openStruk(id) {
  const t = book.transactions.find(x => x.id === id); if (!t) return;
  revokeStruk();
  const s = SHEET_BOTTOM();
  s.innerHTML = `<div class="box gb det"><div class="grab"></div><div class="dbody"><h3>Struk ${trxNo(t)}</h3><div class="strukbox" data-sid="${id}"><p class="empty">Membuat struk…</p></div></div>
    <div class="acts two"><button class="primary wide" data-strukshare="${id}">Bagikan gambar</button><button data-struksave="${id}">Simpan</button><button data-strukcopy="${id}">Salin teks</button><button class="wide" data-strukx="${id}">Kembali</button></div></div>`;
  try {
    const blob = await strukBlob(t, book.settings.shop), box = $('#sheet .strukbox');
    if (!box || box.dataset.sid !== id) return;
    strukCache = { id, blob }; strukUrl = URL.createObjectURL(blob);
    box.innerHTML = `<img class="strukimg" src="${strukUrl}" alt="Struk ${trxNo(t)}">`;
  } catch (e) { const box = $('#sheet .strukbox'); if (box) box.innerHTML = '<p class="empty">Struk gambar gagal dibuat. Pakai Salin teks.</p>'; }
}
async function strukFile(id) {
  const t = book.transactions.find(x => x.id === id); if (!t) return null;
  const blob = strukCache?.id === id ? strukCache.blob : await strukBlob(t, book.settings.shop);
  return { t, blob, name: `${trxNo(t)}.png` };
}
async function strukSave(id) {
  const f = await strukFile(id); if (!f) return;
  const a = document.createElement('a'), u = URL.createObjectURL(f.blob); a.href = u; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 4000); toast('Struk disimpan sebagai gambar');
}
async function strukShare(id) {
  try {
    const f = await strukFile(id); if (!f) return;
    const file = new File([f.blob], f.name, { type: 'image/png' });
    if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: `Struk ${trxNo(f.t)}` }); return; }
  } catch (e) { if (e?.name === 'AbortError') return; }
  strukSave(id);
}

// ---- Penampil gambar ----
const viewerFiles = () => !viewerSt ? [] : viewerSt.ctx === 'draft' ? draft?.files ?? [] : filesOf(book.transactions.find(x => x.id === viewerSt.txId));
function openViewer(i, ctx, txId = null) { viewerSt = { i: Math.max(0, i), ctx, txId, z: 1 }; renderViewer(); }
function closeViewer() { if (viewerSt) dropUrls(viewerFiles().map(f => f.id), false); viewerSt = null; const v = $('#viewer'); v.hidden = true; v.innerHTML = ''; }
function renderViewer() {
  const s = viewerSt, files = viewerFiles();
  if (!s || !files.length) { closeViewer(); return; }
  s.i = Math.max(0, Math.min(s.i, files.length - 1));
  const f = files[s.i], v = $('#viewer'), many = files.length > 1;
  v.hidden = false;
  v.innerHTML = `<div class="v-top"><button data-vx="1" aria-label="Tutup">✕</button><div class="v-t"><b>${esc(f.name)}</b><small>${s.i + 1}/${files.length} · ${f.w}×${f.h} · ${fmtSize(f.size)}</small></div>
    <button data-vz="out" aria-label="Perkecil">−</button><button data-vz="in" aria-label="Perbesar">+</button></div>
    <div class="v-body ${s.z > 1 ? 'zoom' : ''}" id="vbody" style="--z:${s.z}"><img id="vimg" data-fid="${esc(f.id)}" data-full="1" alt=""></div>
    <div class="v-bot">${many ? `<button data-vnav="-1" aria-label="Sebelumnya" ${s.i === 0 ? 'disabled' : ''}>‹</button>` : ''}<button data-vread="1">${ico('scan')} ${f.text ? 'Teks gambar' : 'Baca teks'}</button><button class="danger" data-vdel="1">${ico('trash')} Hapus</button>${many ? `<button data-vnav="1" aria-label="Berikutnya" ${s.i === files.length - 1 ? 'disabled' : ''}>›</button>` : ''}</div>`;
  hydrate(v);
}
function setZoom(nz) {
  const b = $('#vbody'); if (!b || !viewerSt) return;
  const cx = (b.scrollLeft + b.clientWidth / 2) / b.scrollWidth, cy = (b.scrollTop + b.clientHeight / 2) / b.scrollHeight;
  viewerSt.z = Math.max(1, Math.min(4, nz)); b.classList.toggle('zoom', viewerSt.z > 1); b.style.setProperty('--z', viewerSt.z);
  b.scrollLeft = cx * b.scrollWidth - b.clientWidth / 2; b.scrollTop = cy * b.scrollHeight - b.clientHeight / 2;
}
function askRemoveFile() {
  const s = viewerSt, f = viewerFiles()[s?.i]; if (!f) return;
  askConfirm({ title: 'Hapus gambar?', text: s.ctx === 'tx' ? 'Gambar ini dihapus dari transaksi.' : 'Gambar ini dilepas dari form.', ok: 'Hapus', danger: true }, async () => {
    if (s.ctx === 'draft') { if (!draft) return; draft.files = draft.files.filter(x => x.id !== f.id); draft.pend.delete(f.id); renderForm(); renderViewer(); return; }
    const tx = book.transactions.find(x => x.id === s.txId); if (!tx) return;
    if (await act(() => setFiles(book, tx.id, filesOf(tx).filter(x => x.id !== f.id)))) {
      delFiles([f.id]).catch(() => {}); dropUrls([f.id]);
      if (detailId === tx.id) openDetail(tx.id);
      renderViewer();
    }
  });
}

// ---- Baca teks dari gambar (OCR) ----
const OCR_LABEL = { price: 'Nominal', date: 'Tanggal', time: 'Jam', target: 'No. / ID', name: 'Pelanggan', category: 'Kategori', note: 'Catatan' };
function parseOcr() {
  const s = ocrSt, d = draft, tx = s.ctx === 'tx' ? book.transactions.find(x => x.id === s.txId) : null, kind = d?.kind ?? tx?.kind ?? 'income';
  s.sug = parseReceiptText(s.text, { today: today(), kind, categories: book.categories[kind] ?? [] }); s.sel = new Set();
  if (s.ctx !== 'draft' || !d) return;
  const cur = { price: d.price, date: d.date, time: d.time, target: d.target, name: d.name, category: d.category, note: d.memo };
  for (const [k, v] of Object.entries(s.sug)) {
    if (cur[k] === String(v.value)) continue;
    if (!d.editId || !cur[k]) s.sel.add(k);
  }
}
function renderOcr() {
  const s = ocrSt, c = $('#ocr'); if (!s) return;
  c.className = 'sheet bottom'; c.hidden = false;
  const show = (k, v) => k === 'price' ? rp(v) : String(v), edit = s.ctx === 'draft';
  let body;
  if (s.phase === 'load') body = `<div class="ocr-load"><b id="ocrmsg">${esc(s.msg)}</b><div class="pbar"><i id="ocrbar" style="width:${Math.round(s.pct * 100)}%"></i></div>
    <small>Gambar dibaca di perangkat ini dan tidak dikirim ke mana pun. Pertama kali, mesin baca diunduh dulu (perlu internet).</small></div><div class="acts"><button data-ocrx="1">Batal</button></div>`;
  else {
    const keys = Object.keys(s.sug);
    body = `${s.phase === 'err' ? `<p class="ocr-err">${esc(s.msg)}</p>` : ''}
      ${keys.length ? `<div class="orows">${keys.map(k => `<label class="orow ${edit ? '' : 'info'}">${edit ? `<input type="checkbox" data-ock="${k}" ${s.sel.has(k) ? 'checked' : ''}>` : ''}<span>${OCR_LABEL[k]}</span><b>${esc(show(k, s.sug[k].value))}</b></label>`).join('')}</div>`
        : `<p class="cft">${s.text.trim() ? 'Belum ada isian yang bisa dikenali dari teks ini.' : 'Belum ada teks. Ketik atau tempel teksnya di bawah, lalu tekan Cek ulang isian.'}</p>`}
      <label class="cfld"><span>Teks dari gambar (boleh diedit atau ditempel)</span><textarea id="ocrtxt" rows="5" maxlength="3000">${esc(s.text)}</textarea></label>
      <div class="acts">${edit ? `<button class="primary" data-ocrapply="1" ${s.sel.size ? '' : 'disabled'}>Terapkan ke form</button>` : '<button class="primary" data-ocrsave="1">Simpan teks</button>'}
      <button data-ocrre="1">Cek ulang isian</button><button data-ocrrun="1">Baca ulang gambar</button><button data-ocrcopy="1">${ico('copy')} Salin teks</button><button data-ocrx="1">Tutup</button></div>`;
  }
  c.innerHTML = `<div class="box gb"><div class="grab"></div><h3>Baca dari gambar</h3>${body}</div>`;
}
function closeOcr() { ocrRun++; ocrSt = null; hideSheet($('#ocr')); }

function syncOcrText() {
  const s = ocrSt, ta = $('#ocrtxt'); if (!s) return null;
  if (ta) s.text = ta.value.slice(0, 3000);
  if (s.ctx === 'draft') { const f = draft?.files.find(x => x.id === s.id); if (f) f.text = s.text; return null; }
  const tx = book.transactions.find(x => x.id === s.txId); if (!tx || tx.deleted) return null;
  return act(() => setFiles(book, tx.id, filesOf(tx).map(x => x.id === s.id ? { ...x, text: s.text } : x)));
}

async function startOcr(id, ctx, txId = null, force = false) {
  const f = (ctx === 'draft' ? draft?.files : filesOf(book.transactions.find(x => x.id === txId)))?.find(x => x.id === id); if (!f) return;
  const my = ++ocrRun;
  ocrSt = { id, ctx, txId, text: f.text || '', phase: f.text && !force ? 'done' : 'load', msg: 'Menyiapkan…', pct: 0, sug: {}, sel: new Set() };
  if (ocrSt.phase === 'done') { parseOcr(); renderOcr(); return; }
  renderOcr();
  try {
    const blob = await blobOf(id, false); if (!blob) throw new Error('Gambar tidak ditemukan di perangkat ini');
    const text = await readImageText(blob, (msg, pct) => {
      if (ocrRun !== my || !ocrSt) return; ocrSt.msg = msg; ocrSt.pct = pct;
      const m = $('#ocrmsg'), b = $('#ocrbar'); if (m) m.textContent = `${msg} ${Math.round(pct * 100)}%`; if (b) b.style.width = `${Math.round(pct * 100)}%`;
    });
    if (ocrRun !== my || !ocrSt) return;
    ocrSt.text = text.trim().slice(0, 3000); await syncOcrText();
    if (ocrRun !== my || !ocrSt) return;
    ocrSt.phase = 'done'; parseOcr(); renderOcr();
  } catch (e) {
    if (ocrRun !== my || !ocrSt) return;
    ocrSt.phase = 'err'; ocrSt.msg = e.message; parseOcr(); renderOcr();
  }
}

function applyOcr() {
  const s = ocrSt, d = draft; if (!s || !d) return;
  if ($('#ocrtxt') && $('#ocrtxt').value !== s.text) { syncOcrText(); parseOcr(); renderOcr(); toast('Teks berubah. Periksa isian lalu tekan Terapkan lagi.'); return; }
  const set = { price: v => { d.price = String(v); }, date: v => { d.date = v; }, time: v => { d.time = v; }, target: v => { d.target = v; }, name: v => { d.name = v; }, category: v => { d.category = v; },
    note: v => { d.memo = (d.memo ? `${d.memo}\n${v}` : v).slice(0, 200); } };
  for (const k of s.sel) if (s.sug[k] && set[k]) set[k](s.sug[k].value);
  syncOcrText(); closeOcr(); renderForm(); toast('Isian diterapkan. Periksa lalu tekan Simpan.');
}

// ---- Menu pilihan slide-up (pengganti dropdown bawaan) ----
function openChoose({ title, options, value, onPick }) {
  chooseOpts = options; chooseFn = onPick;
  const c = $('#choose'); c.className = 'sheet bottom'; c.hidden = false;
  c.innerHTML = `<div class="box gb"><div class="grab"></div><h3>${esc(title)}</h3><div class="clist">${options.map((o, i) =>
    `<button type="button" class="copt ${o.v === value ? 'on' : ''}" data-cpick="${i}"><span>${esc(o.l)}</span>${o.s ? `<small>${esc(o.s)}</small>` : ''}<i class="rad"></i></button>`).join('')}</div></div>`;
  const l = c.querySelector('.clist'), on = l.querySelector('.on'); if (on) l.scrollTop = on.offsetTop - l.clientHeight / 2 + on.offsetHeight / 2;
}
function closeChoose() { chooseFn = null; hideSheet($('#choose')); }
function openFilterChoose(kind) {
  const again = () => { render(); $('#main').classList.add('still'); };
  if (kind === 'st') openChoose({ title: 'Filter status', options: ST_OPT.map(([v, l]) => ({ v, l })), value: txSt, onPick: (v) => { txSt = v; again(); } });
  else openChoose({ title: 'Filter kategori', value: txCat, onPick: (v) => { txCat = v; again(); },
    options: [{ v: 'all', l: 'Semua kategori' }, ...txCats().map(c => ({ v: c, l: c, s: `${live().filter(t => t.category === c).length}` }))] });
}

// Semua tombol baru lewat sini; true = sudah ditangani.
function fileClick(d, t) {
  if (d.paidtg) { if (draft) { draft.paid = draft.paid === '1' ? '0' : '1'; t.className = `paychip ${draft.paid === '1' ? 'ok' : 'no'}`; t.textContent = draft.paid === '1' ? 'Sudah bayar' : 'Belum bayar'; } }
  else if (d.struk) openStruk(d.struk);
  else if (d.strukcopy) { const x = book.transactions.find(v => v.id === d.strukcopy); if (x) copyText(strukText(x, book.settings.shop), 'Teks struk disalin'); }
  else if (d.strukshare) strukShare(d.strukshare);
  else if (d.struksave) strukSave(d.struksave);
  else if (d.strukx) { revokeStruk(); openDetail(d.strukx); }
  else if (d.cpick !== undefined) { const o = chooseOpts[+d.cpick], f = chooseFn; closeChoose(); if (o && f) f(o.v); }
  else if (d.fk) { if (d.fk === 'st') txSt = d.fv; else txCat = d.fv; render(); $('#main').classList.add('still'); }
  else if (d.fadd || d.fread) pickImages({ ctx: 'draft', read: !!d.fread });
  else if (d.ftxadd) pickImages({ ctx: 'tx', txId: d.ftxadd });
  else if (d.fv !== undefined) {
    const tx = d.ftx ? book.transactions.find(x => x.id === d.ftx) : null, list = tx ? filesOf(tx) : draft?.files ?? [];
    openViewer(list.findIndex(f => f.id === d.fv), tx ? 'tx' : 'draft', tx?.id ?? null);
  }
  else if (d.frm !== undefined) { if (draft) { draft.files = draft.files.filter(f => f.id !== d.frm); draft.pend.delete(d.frm); renderForm(); } }
  else if (d.vx) closeViewer();
  else if (d.vz) setZoom(viewerSt.z * (d.vz === 'in' ? 1.6 : 1 / 1.6));
  else if (d.vnav) { viewerSt.i += Number(d.vnav); viewerSt.z = 1; renderViewer(); }
  else if (d.vread) { const f = viewerFiles()[viewerSt.i]; if (f) startOcr(f.id, viewerSt.ctx, viewerSt.txId); }
  else if (d.vdel) askRemoveFile();
  else if (d.ocrx) closeOcr();
  else if (d.ocrre) { syncOcrText(); parseOcr(); renderOcr(); }
  else if (d.ocrrun) startOcr(ocrSt.id, ocrSt.ctx, ocrSt.txId, true);
  else if (d.ocrcopy) copyText($('#ocrtxt')?.value ?? '', 'Teks disalin');
  else if (d.ocrapply) applyOcr();
  else if (d.ocrsave) Promise.resolve(syncOcrText()).then(() => toast('Teks disimpan'));
  else return false;
  return true;
}

// Tarik pegangan di atas menu ke bawah untuk menutup (menu pilihan, detail transaksi, hasil bacaan).
const SWIPE_CLOSE = { sheet: () => closeSheet(), pick: () => closePicker(), choose: () => closeChoose(), ocr: () => closeOcr() };
document.addEventListener('pointerdown', e => {
  const g = e.target.closest?.('.grab'), sh = g?.closest('.sheet'), box = g?.closest('.box'); if (!g || !sh || !box || !SWIPE_CLOSE[sh.id]) return;
  const y0 = e.clientY, t0 = performance.now(); let dy = 0;
  try { g.setPointerCapture(e.pointerId); } catch {}
  box.style.transition = 'none';
  const mv = (ev) => { dy = Math.max(0, ev.clientY - y0); box.style.transform = `translateY(${dy}px)`; };
  const up = () => {
    g.removeEventListener('pointermove', mv); g.removeEventListener('pointerup', up); g.removeEventListener('pointercancel', up);
    box.style.transition = 'transform .18s ease';
    if (dy > 90 || (dy > 30 && dy / Math.max(1, performance.now() - t0) > 0.5)) { box.style.transform = 'translateY(105%)'; setTimeout(() => SWIPE_CLOSE[sh.id](), 140); }
    else { box.style.transform = ''; setTimeout(() => { box.style.transition = ''; }, 200); }
  };
  g.addEventListener('pointermove', mv); g.addEventListener('pointerup', up); g.addEventListener('pointercancel', up);
});

// ---- Cadangan: gambar ikut disimpan di dalam file JSON (data URL) ----
const dataUrl = (buf, type) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(new Blob([buf], { type })); });
async function backupText() {
  const ids = [...fileIdsInUse(book)];
  if (!ids.length || !storage) return snapshot(book);
  const o = JSON.parse(snapshot(book)); o._files = {};
  for (const id of ids) { const r = await getFile(id); if (r) o._files[id] = { u: await dataUrl(r.buf, r.type), t: await dataUrl(r.tBuf, r.tType) }; }
  return JSON.stringify(o);
}
async function putPack(pack) {
  const ok = (v) => typeof v === 'string' && /^data:image\/(jpeg|png|webp);base64,/.test(v);   // hanya data URL gambar, tidak pernah mengambil alamat luar
  for (const [id, p] of Object.entries(pack)) {
    if (!/^F[0-9a-z]{6,24}$/.test(id) || !ok(p?.u) || !ok(p?.t)) continue;
    const [a, b] = await Promise.all([fetch(p.u).then(r => r.blob()), fetch(p.t).then(r => r.blob())]);
    await putFile(id, await toRec(a, b));
  }
}

// Periode yang dipilih otomatis saat aplikasi dibuka (Pengaturan → Periode saat membuka aplikasi).
function applyStartPeriod() {
  const sp = book.settings.startPeriod ?? 'week', ok = (c) => c && /^\d{4}-\d{2}-\d{2}$/.test(c.a) && /^\d{4}-\d{2}-\d{2}$/.test(c.b) && c.a <= c.b;
  if (sp === 'custom' && ok(book.settings.startCustom)) { period = 'custom'; customRange = { ...book.settings.startCustom }; return; }
  if (sp === 'last') {
    try {
      const v = JSON.parse(localStorage.getItem('kb-last-period') || 'null');
      if (v && ['day', 'week', 'month', 'year', 'all'].includes(v.period)) { period = v.period; return; }
      if (v?.period === 'custom' && ok(v.custom)) { period = 'custom'; customRange = { ...v.custom }; return; }
    } catch {}
    period = 'week'; return;
  }
  period = ['day', 'week', 'month', 'year', 'all'].includes(sp) ? sp : 'week';
}

async function act(fn) {
  try { fn(); if (storage) await saveSnapshot(snapshot(book)); render(); return true; } catch (e) { toast(e.message); return false; }
}

// ---- Geser layar antar menu utama (Dashboard, Transaksi, Catatan, Kas) ----
// Halaman mengikuti jari (bisa ditahan di tengah), menu di sebelahnya ikut terlihat. Lepas: lanjut bila cukup jauh / cepat, kalau tidak kembali.
const VIEWS = ['home', 'tx', 'notes', 'kas'];
const reduceMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const noOverlay = () => ['#sheet', '#page', '#calc', '#pick', '#confirm', '#choose', '#ocr', '#viewer'].every(q => $(q).hidden);
let sw = null, swBusy = false, swBlock = 0;
const vw = () => document.documentElement.clientWidth;
function killPeek() { $('#peek')?.remove(); }
const setNav = (v) => document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.v === v));   // penanda menu bawah
// Saat geser, halaman aktif & halaman tetangga dijadikan panel 'fixed' seukuran layar (bukan layer setinggi seluruh konten).
// Layer raksasa inilah yang bikin geseran seret dan membuat menu bawah ikut terhapus oleh GPU/WebView.
let frozen = null;
function freeze() {
  if (frozen) return frozen;
  closePdd();
  const m = $('#main'), r = m.getBoundingClientRect(), hb = Math.max(0, document.querySelector('header').getBoundingClientRect().bottom), sy = Math.max(0, window.scrollY);
  frozen = { sy, hb, left: r.left, width: r.width };
  document.body.style.minHeight = `${document.documentElement.scrollHeight}px`;   // tinggi dokumen tetap → posisi scroll tidak bergeser
  Object.assign(m.style, { position: 'fixed', top: `${hb}px`, left: `${r.left}px`, width: `${r.width}px`, height: `calc(100dvh - ${hb}px)`, minHeight: '0', margin: '0', overflow: 'hidden', zIndex: '1' });
  m.scrollTop = sy;
  return frozen;
}
function makePeek(v, dir) {
  killPeek();
  const f = freeze(), el = document.createElement('main');
  el.id = 'peek'; el.className = 'still'; el.setAttribute('aria-hidden', 'true'); el.inert = true;
  el.innerHTML = viewHtml(v);
  Object.assign(el.style, { top: `${f.hb}px`, left: `${f.left}px`, width: `${f.width}px`, height: `calc(100dvh - ${f.hb}px)`, transform: `translate3d(${dir * vw()}px,0,0)` });
  document.body.appendChild(el);
  el.querySelectorAll('.chscroll').forEach(c => { c.scrollLeft = c.scrollWidth; });
  return el;
}
const applyX = (x, dir) => { $('#main').style.transform = `translate3d(${x}px,0,0)`; const p = $('#peek'); if (p) p.style.transform = `translate3d(${x + dir * vw()}px,0,0)`; };
let rafId = 0, rafArgs = null;
const setX = (x, dir, now = false) => {                                          // gabungkan banyak pointermove jadi 1 update per frame (lebih mulus)
  if (now) { cancelAnimationFrame(rafId); rafId = 0; rafArgs = null; applyX(x, dir); return; }
  rafArgs = [x, dir];
  if (!rafId) rafId = requestAnimationFrame(() => { rafId = 0; const a = rafArgs; rafArgs = null; if (a) applyX(a[0], a[1]); });
};
const inHScroll = (el) => { for (let n = el; n && n !== document.body; n = n.parentElement) { if (n.scrollWidth > n.clientWidth + 2 && /(auto|scroll)/.test(getComputedStyle(n).overflowX)) return true; } return false; };

// Selesaikan geseran: animasi ke ujung (lanjut) atau kembali (batal), lalu ganti menu.
function swFinish(to, dir, x = 0, ms = 300) {
  swBusy = true;
  setNav(to || view);                                                          // penanda menu langsung pindah saat dilepas, tidak menunggu animasi selesai
  const m = $('#main'), p = $('#peek'), W = vw();
  if (rafId) setX(x, dir, true);
  const done = () => {
    const f = frozen, pk = $('#peek');
    cancelAnimationFrame(rafId); rafId = 0; rafArgs = null;
    m.style.cssText = ''; document.body.style.minHeight = ''; frozen = null;
    if (to) {
      view = to; window.scrollTo(0, 0);
      if (pk) {                                                                  // pakai ulang isi halaman tetangga (tanpa render ulang → tidak ada jeda di akhir geseran)
        m.className = 'still'; m.replaceChildren(...pk.childNodes);
        setNav(view);
      } else { render(); $('#main').classList.add('still'); }
    } else if (f?.sy) window.scrollTo(0, f.sy);
    killPeek(); document.documentElement.classList.remove('swiping'); swBusy = false;
  };
  if (reduceMotion()) { done(); return; }
  const ease = `transform ${ms}ms cubic-bezier(.2,.85,.25,1)`;
  m.style.transition = ease; if (p) p.style.transition = ease;
  void m.offsetWidth;
  if (to) setX(-dir * W, dir, true); else setX(0, dir, true);
  let fin = false; const once = () => { if (!fin) { fin = true; m.removeEventListener('transitionend', onEnd); done(); } };
  const onEnd = (ev) => { if (ev.target === m && ev.propertyName === 'transform') once(); };
  m.addEventListener('transitionend', onEnd); setTimeout(once, ms + 80);
}

function goView(v) {
  if (v === view || reduceMotion() || !noOverlay() || swBusy || !book) { view = v; render(); return; }
  const dir = VIEWS.indexOf(v) > VIEWS.indexOf(view) ? 1 : -1;
  document.documentElement.classList.add('swiping');
  makePeek(v, dir); swFinish(v, dir, 0, 320);
}

document.addEventListener('pointerdown', e => {
  sw = null;
  if (!book || swBusy || e.pointerType === 'mouse' || !e.isPrimary || !noOverlay()) return;
  if (e.clientX < 12 || e.clientX > vw() - 12) return;                       // tepi layar dipakai gestur sistem
  if (!(e.target.closest?.('#main') || e.target === document.body || e.target === document.documentElement) || e.target.closest('input, textarea, select, .grab, .grip, .hv-bars') || inHScroll(e.target)) return;
  sw = { id: e.pointerId, x0: e.clientX, y0: e.clientY, lock: false, dir: 0, x: 0, vx: 0, lx: e.clientX, lt: performance.now() };
});
document.addEventListener('pointermove', e => {
  if (!sw || e.pointerId !== sw.id) return;
  const dx = e.clientX - sw.x0, dy = e.clientY - sw.y0;
  if (!sw.lock) {
    if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx)) { sw = null; return; }
    if (Math.abs(dx) < 8 || Math.abs(dx) < Math.abs(dy) * 1.1) return;
    sw.lock = true; sw.x0 += Math.sign(dx) * 8; document.documentElement.classList.add('swiping'); getSelection()?.removeAllRanges(); freeze();
  }
  const x = e.clientX - sw.x0, i = VIEWS.indexOf(view), dir = x < 0 ? 1 : -1, to = VIEWS[i + dir], now = performance.now();
  if (dir !== sw.dir) { sw.dir = dir; if (to) makePeek(to, dir); else killPeek(); }
  const want = to && Math.abs(x) > vw() * 0.28 ? to : view;                    // penanda ikut berpindah begitu geseran cukup jauh
  if (sw.nav !== want) { sw.nav = want; setNav(want); }
  sw.vx = 0.8 * sw.vx + 0.2 * ((e.clientX - sw.lx) / Math.max(1, now - sw.lt)); sw.lx = e.clientX; sw.lt = now;
  sw.x = to ? x : x * 0.28;                                                    // ujung daftar: terasa menahan
  setX(sw.x, dir);
});
const swEnd = (e) => {
  if (!sw || e.pointerId !== sw.id) return;
  const s = sw; sw = null; if (!s.lock) return;
  swBlock = Date.now() + 350;
  const to = VIEWS[VIEWS.indexOf(view) + s.dir], W = vw();
  const go = e.type === 'pointerup' && to && (Math.abs(s.x) > W * 0.28 || (Math.abs(s.vx) > 0.45 && Math.sign(s.vx) === -s.dir));
  swFinish(go ? to : null, s.dir, s.x, go ? 280 : 240);
};
document.addEventListener('pointerup', swEnd); document.addEventListener('pointercancel', swEnd);
document.addEventListener('click', e => { if (Date.now() < swBlock) { e.stopPropagation(); e.preventDefault(); } }, true);

document.addEventListener('click', e => {
  if (!book) return;
  if (e.target.closest('#sheet.out')) return;
  const g = e.target.closest('.grp');
  if (g) {
    g.closest('svg').querySelectorAll('.grp').forEach(x => { x.classList.remove('def'); x.classList.toggle('sel', x === g); });
    const dd = g.dataset; g.closest('.chart').querySelector('.readout').innerHTML = rdHtml(dd.l, +dd.i, +dd.o, dd.pi === '' ? null : +dd.pi, dd.po === '' ? null : +dd.po);
    return;
  }
  const nf = e.target.closest('.num');
  if (nf && draft) {
    draft.field = nf.dataset.f; draft.pad = true;
    document.querySelectorAll('#sheet .num').forEach(x => x.classList.toggle('on', x === nf));
    $('#pad').hidden = false; $('#padt').textContent = lbl(draft.field);
    document.activeElement?.blur();
    return;
  }
  if (e.target.id === 'confirm') { closeConfirm(); return; }
  if (e.target.id === 'calc') { closeCalc(); return; }
  if (e.target.id === 'pick') { closePicker(); return; }
  if (e.target.id === 'choose') { closeChoose(); return; }
  if (e.target.id === 'ocr') { closeOcr(); return; }
  if (e.target.id === 'vimg') { const now = Date.now(); if (now - lastTap < 320) setZoom(viewerSt.z > 1 ? 1 : 2.5); lastTap = now; return; }
  const pr = e.target.closest('.pk');
  if (pr && draft) { openPicker(pr.dataset.pk); return; }
  const sh = $('#sheet');
  if (e.target === sh && sh.classList.contains('bottom')) { closeSheet(); return; }
  const t = e.target.closest('button');
  if (!t) {
    const op = e.target.closest('[data-open]'), go = e.target.closest('[data-goto]'), mt = e.target.closest('[data-metric]'), pc = e.target.closest('[data-cat]'), pa = e.target.closest('[data-catall]');
    if (op) openDetail(op.dataset.open); else if (go) goToTx(go.dataset.goto); else if (mt) openPage('metric', { key: mt.dataset.metric });
    else if (pc) { const c = parseCat(pc.dataset.cat); if (c) openPage('catdetail', c); } else if (pa) openPage('kategori', { kind: pa.dataset.catall });
    return;
  }
  const d = t.dataset;
  if (fileClick(d, t)) return;
  if (d.pick !== undefined) {
    const p = t.closest('.pick'), inp = p.querySelector('input');
    inp.value = d.pick;
    if (draft && t.closest('#sheet')) draft[inp.name] = d.pick;
    p.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === t));
  }
  else if (d.key) keypad(d.key);
  else if (d.kind) { setKind(d.kind); renderForm(); }
  else if (d.c !== undefined) calcKey(d.c);
  else if (d.txs) { txSearch = true; $('.sbx')?.classList.add('open'); t.classList.add('on'); t.setAttribute('aria-expanded', 'true'); setTimeout(() => $('#txq')?.focus(), 60); }
  else if (d.txsx) { txq = ''; txSearch = false; const i = $('#txq'); if (i) { i.value = ''; i.blur(); } $('.sbx')?.classList.remove('open'); const b = $('.sico'); if (b) { b.classList.remove('on'); b.setAttribute('aria-expanded', 'false'); } $('#tvb').innerHTML = txBody(); }
  else if (d.txk) { txKind = d.txk; render(); $('#main').classList.add('still'); }
  else if (d.txreset) { txKind = txSt = txCat = 'all'; render(); $('#main').classList.add('still'); }
  else if (d.txgo) { txKind = d.txgo; txSt = txCat = 'all'; txq = ''; txSearch = false; view = 'tx'; render(); }
  else if (d.tab) { txTab = d.tab; render(); }
  else if (d.yr) { mon.y += Number(d.yr); render(); }
  else if (d.tg) { if (openKeys.has(d.tg)) openKeys.delete(d.tg); else { openKeys.add(d.tg); fresh = d.tg; } render(); fresh = ''; $('#main').classList.add('still'); }
  else if (d.day) { selDay = d.day; render(); $('#main').classList.add('still'); }
  else if (d.pm) { pieMode = d.pm; render(); $('#main').classList.add('still'); }
  else if (d.pkind) { pieKind = d.pkind; render(); $('#main').classList.add('still'); }
  else if (d.fold) toggleFold(t);
  else if (d.hr !== undefined) selHr(t);
  else if (d.cm) { chartMode = d.cm; render(); $('#main').classList.add('still'); }
  else if (d.catall) openPage('kategori', { kind: d.catall });
  else if (d.edit) { t.classList.add('pressed'); const id = d.edit; setTimeout(() => openEdit(id), 220); }
  else if (d.pkx) closePicker();
  else if (d.pv !== undefined) {
    if (pkName === 'contact') { const c = book.contacts.find(x => x.id === d.pv); if (c) { draft.target = c.number; if (!draft.name.trim()) draft.name = c.name; closePicker(); renderForm(); } }
    else { draft[pkName] = d.pv; closePicker(); syncRows(); }
  }
  else if (d.itpr) { const x = book.products.find(v => v.id === d.itpr); if (x) { addItem({ n: x.name, p: x.price, c: x.cost }); $('#pick [name=itn]').value = ''; refreshCat(); } }
  else if (d.ited !== undefined) { itEdit = itEdit === +d.ited ? null : +d.ited; refreshItems(); }
  else if (d.itq !== undefined) { const it = draft.items[+d.itq]; if (it) { it.q += +d.dq; if (it.q < 1) draft.items.splice(+d.itq, 1); else if (it.q > 999) it.q = 999; refreshItems(); } }
  else if (d.itadd) {
    const n = $('#pick [name=itn]').value.trim(), p = digits($('#pick [name=itp]').value), c = digits($('#pick [name=itm]').value);
    if (!n) return toast('Isi nama produk');
    const save = $('#pick [name=itsv]').checked && !book.products.some(v => v.name.toLowerCase() === n.toLowerCase());
    (save ? act(() => addProduct(book, { name: n, price: p, cost: c })) : Promise.resolve(true)).then(ok => { if (ok === false) return; addItem({ n, p, c }); renderItems(); });
  }
  else if (d.ntab) { nTab = d.ntab; nq = ''; render(); $('#main').classList.add('still'); }
  else if (d.psort) { pSort = d.psort; $('#nbody').innerHTML = notesBody(); }
  else if (d.newpr) openPr();
  else if (d.predit) openPr(d.predit);
  else if (d.prdel) askConfirm({ title: 'Hapus produk?', text: 'Produk dihapus dari daftar. Transaksi yang sudah tercatat tidak berubah.', ok: 'Hapus', danger: true },
    () => act(() => { removeProduct(book, d.prdel); closeSheet(); toast('Produk dihapus'); }));
  else if (d.pkm) { pkManage = !pkManage; renderPicker(); }
  else if (d.pd !== undefined) {
    const isCat = pkName === 'category', nm = isCat ? d.pd : (SHORT[d.pd] || d.pd);
    askConfirm({ title: `Hapus “${nm}”?`, text: isCat ? 'Pilihan ini dihapus dari daftar kategori. Transaksi yang sudah tercatat tidak berubah.' : 'Akun ini dihapus dari daftar pilihan.', ok: 'Hapus', danger: true }, () => act(() => {
      if (isCat) { removeCategory(book, draft.kind, d.pd); if (draft.category === d.pd) draft.category = book.categories[draft.kind][0]; }
      else { removeAccount(book, d.pd); for (const f of ['method', 'source']) if (draft[f] === d.pd) draft[f] = '1101'; }
      renderPicker(); syncRows();
    }));
  }
  else if (d.padd) {
    const v = $('#pick [name=newopt]').value;
    act(() => { if (pkName === 'category') draft.category = addCategory(book, draft.kind, v); else draft[pkName] = addAccount(book, v); closePicker(); syncRows(); });
  }
  else if (d.settle) act(() => { settleTransaction(book, d.settle, today()); closeSheet(); toast('Ditandai sudah bayar'); });
  else if (d.cf) { const f = cfFn; closeConfirm(); if (d.cf === 'ok' && f) f(); }
  else if (d.metric) openPage('metric', { key: d.metric });
  else if (d.cat) { const c = parseCat(d.cat); if (c) { closeSheet(); openPage('catdetail', c); } }
  else if (d.clmode) { const id = d.clid, m = d.clmode; closePdd(); cloneTx(id, m); }
  else if (d.newcat) { const c = parseCat(d.newcat); if (c) newInCategory(c); }
  else if (d.sort) { pgSort = d.sort; pgLim = 30; renderPage(true); }
  else if (d.more) { pgLim += 30; renderPage(true); }
  else if (d.tf) { trxFilter = d.tf; pgLim = 30; renderPage(true); }
  else if (d.ck) { catKind = d.ck; renderPage(true); }
  else if (d.page) { openPage(d.page); if (d.goalfocus) setTimeout(() => $('#goalin')?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 420); }
  else if (d.pgx) pageBack();
  else if (d.copytx) { const tx = book.transactions.find(x => x.id === d.copytx); if (tx) copyText(receiptText(tx), 'Detail transaksi disalin'); }
  else if (d.bill) { const rows = d.bill.split(',').map(id => book.transactions.find(x => x.id === id)).filter(Boolean); if (rows.length) copyText(reminderText(rows, book.settings.shop), 'Pesan tagihan disalin'); }
  else if (d.payall) {
    const ids = d.payall.split(','), run = () => act(() => { ids.forEach(id => setPaid(book, id, true, today())); toast(ids.length > 1 ? `${ids.length} transaksi ditandai lunas` : 'Ditandai sudah bayar'); });
    if (ids.length === 1) run();
    else askConfirm({ title: 'Lunasi semua?', text: `${ids.length} transaksi dicatat sudah dibayar dan uangnya masuk ke akun tujuan masing-masing.`, ok: 'Ya, lunas' }, run);
  }
  else if (d.themeSet) { theme = d.themeSet; applyTheme(); slideSeg(t); }
  else if (d.basis) { slideSeg(t); $('#basisnote').textContent = BASIS_NOTE[d.basis]; act(() => setSettings(book, { basis: d.basis })); }
  else if (d.sp) {
    closePdd();
    if (d.sp === 'custom') { $('.spc')?.classList.add('open'); $('#splab').textContent = 'Tanggal tertentu'; setTimeout(() => $('#spa')?.focus(), 250); return; }
    act(() => { setSettings(book, { startPeriod: d.sp }); }).then(ok => { if (ok) { syncSp(); toast(`Periode awal: ${spLabel()}`); } });
  }
  else if (d.spsave) {
    const a = $('#spa').value, b = $('#spb').value || a;
    if (!a) { toast('Isi tanggal awal'); return; }
    act(() => { setSettings(book, { startCustom: { a, b }, startPeriod: 'custom' }); }).then(ok => { if (ok) { syncSp(); toast('Periode awal disimpan'); } });
  }
  else if (d.savegoal) { const raw = $('#goalin').value.trim(); let v = 0; try { v = raw ? parseRupiah(raw) : 0; } catch { toast('Target tidak valid'); return; } act(() => { setSettings(book, { goal: v }); toast(v ? 'Target disimpan' : 'Target dihapus'); }); }
  else if (d.goalkind) { slideSeg(t); act(() => setSettings(book, { goalKind: d.goalkind })); }
  else if (d.recap) openRecap();
  else if (d.rcshare) { navigator.share?.({ text: recapTxt }).catch(() => {}); }
  else if (d.rccopy) copyText(recapTxt, 'Rekap disalin');
  else if (d.saveshop) act(() => { setSettings(book, { shop: $('#shopin').value }); toast('Nama usaha disimpan'); });
  else if (d.reset) {
    if (demo) { toast('Keluar dari mode contoh dulu'); return; }
    askConfirm({ title: 'Hapus semua data?', text: 'Semua transaksi, akun, dan catatan di perangkat ini dihapus permanen. Ekspor cadangan dulu jika masih diperlukan.', ok: 'Hapus semua', danger: true, type: 'HAPUS' },
      async () => { if (await act(() => { const keep = book.settings; book = createBook(); book.settings = { ...keep }; view = 'home'; closePage(); toast('Semua data dihapus'); })) pruneFiles(true); });
  }
  else if (d.del) askDel(d.del);
  else if (d.pay) payChip(d.pay);
  else if (d.setpaid !== undefined) act(() => { setPaid(book, d.id, d.setpaid === '1', today()); openDetail(d.id); toast(d.setpaid === '1' ? 'Ditandai sudah bayar' : 'Ditandai belum bayar'); });
  else if (d.copy !== undefined) copyText(d.copy);
  else if (d.savect) { const tx = book.transactions.find(x => x.id === d.savect); if (tx) openCt(null, { name: tx.product === tx.category ? '' : tx.product, number: tx.target, label: tx.category }); }
  else if (d.ctpick) openPicker('contact');
  else if (d.newct) nTab === 'pr' ? openPr() : openCt();
  else if (d.ctedit) openCt(d.ctedit);
  else if (d.ctnew) newFromContact(d.ctnew);
  else if (d.ctdel) askConfirm({ title: 'Hapus catatan?', text: 'Catatan ini dihapus. Transaksi yang sudah tercatat tidak terpengaruh.', ok: 'Hapus', danger: true },
    () => act(() => { removeContact(book, d.ctdel); closeSheet(); toast('Catatan dihapus'); }));
  else if (d.acc) openAcc(d.acc);
  else if (d.addsaldo) { openForm('saldo'); draft.method = d.addsaldo; renderForm(); }
  else if (d.accdel) openAccDel(d.accdel);
  else if (d.accdo) { const mv = $('#sheet [name=moveTo]')?.value; act(() => { const r = deleteAccount(book, d.accdo, { moveTo: mv, date: today() }); closeSheet(); toast(r === 'dihapus' ? 'Akun dihapus' : 'Akun dihapus, riwayat tetap tersimpan'); }); }
  else if (d.accrestore) act(() => { restoreAccount(book, d.accrestore); toast('Akun diaktifkan lagi'); });
  else if (d.bkexp) exportBackup();
  else if (d.bkimp) $('#imp').click();
  else if (d.newsaldo) openForm('saldo');
  else if (d.hacc) { histAcc = d.hacc; renderPage(true); }
  else if (d.hent) openHist(d.hent);
  else if (d.hcancel) askCancelBal(d.hcancel);
  else if (d.hist) { closeSheet(); openPage('saldohist', { acc: d.hist }); }
  else if (d.demo) { book = demoBook(); demo = true; storage = false; view = 'home'; render(); }
  else if (d.demoexit) location.reload();
  else if (d.save) saveDraft();
  else if (d.x) closeSheet();
  else if (d.new) openForm();
  else if (d.mo) { selDay = null; mon.m += Number(d.mo); if (mon.m < 0) { mon.m = 11; mon.y--; } if (mon.m > 11) { mon.m = 0; mon.y++; } render(); }
  else if (d.v) goView(d.v);
  else if (d.pdd) togglePdd(t);
  else if (d.period) { period = d.period; rememberPeriod(); render(); }
  else if (d.selx) exitSel();
  else if (d.selall) selAll();
  else if (d.seldel) askDelSel();
  else if (d.pcopen) { const root = t.closest('.pdd'); calStart(); root.classList.remove('up'); root.classList.add('cal'); calRender(root); calEnsureRoom(root); }
  else if (d.pcback) t.closest('.pdd').classList.remove('cal');
  else if (d.pcmode) { cal.mode = d.pcmode; if (cal.mode === 'single') cal.b = cal.a; cal.step = 0; calRender(t.closest('.pdd')); }
  else if (d.pcnav) { cal.m += +d.pcnav; if (cal.m < 0) { cal.m = 11; cal.y--; } if (cal.m > 11) { cal.m = 0; cal.y++; } calRender(t.closest('.pdd')); }
  else if (d.pcday) {
    const k = d.pcday;
    if (cal.mode === 'single') { cal.a = cal.b = k; cal.step = 0; }
    else if (cal.step === 0) { cal.a = cal.b = k; cal.step = 1; }
    else { if (k >= cal.a) cal.b = k; else { cal.b = cal.a; cal.a = k; } cal.step = 0; }
    calRender(t.closest('.pdd'));
  }
  else if (d.pcq) {
    const t0 = today(), lm = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
    if (d.pcq === 'yday') { cal.mode = 'single'; cal.a = cal.b = addDays(t0, -1); }
    else if (d.pcq === 'd30') { cal.mode = 'range'; cal.a = addDays(t0, -29); cal.b = t0; }
    else { cal.mode = 'range'; cal.a = ymd(lm); cal.b = ymd(new Date(lm.getFullYear(), lm.getMonth() + 1, 0)); }
    cal.step = 0; cal.y = +cal.b.slice(0, 4); cal.m = +cal.b.slice(5, 7) - 1; calRender(t.closest('.pdd'));
  }
  else if (d.pcok) { period = 'custom'; customRange = { a: cal.a, b: cal.b }; rememberPeriod(); closePdd(); render(); }
  else if (d.tx) act(() => { setStatus(book, d.tx, d.st, today()); closeSheet(); });
});

document.addEventListener('input', e => {
  if (draft && ['name', 'target', 'memo', 'date', 'time'].includes(e.target.name)) draft[e.target.name] = e.target.value;
  if (e.target.id === 'txq') { txq = e.target.value; $('#tvb').innerHTML = txBody(); }
  if (e.target.id === 'cfin') $('#confirm [data-cf=ok]').disabled = e.target.value.trim().toUpperCase() !== cfNeed;
  if (e.target.matches?.('input[inputmode=numeric]')) {     // titik ribuan otomatis saat mengetik, posisi kursor dijaga
    const el = e.target, n = el.value.slice(0, el.selectionStart).replace(/\D/g, '').length, f = nf(digits(el.value));
    if (f !== el.value) { el.value = f; let k = 0, i = 0; for (; i < f.length && k < n; i++) if (/\d/.test(f[i])) k++; el.setSelectionRange(i, i); }
  }
  if (draft && e.target.dataset.itf) {
    const it = draft.items[+e.target.dataset.i]; if (!it) return;
    it[e.target.dataset.itf] = digits(e.target.value);
    const el = $(`#its${e.target.dataset.i}`); if (el) el.textContent = rp(it.q * it.p);
    const sm = $(`#itsm${e.target.dataset.i}`); if (sm) sm.textContent = itSub(it);
    refreshTot();
  }
  if (e.target.name === 'itn' && $('#itc')) refreshCat();
  if (e.target.id === 'nq') { nq = e.target.value; $('#nbody').innerHTML = notesBody(); }
});
document.addEventListener('change', e => {
  if (e.target.id === 'imp') { importBackup(e.target.files[0]); e.target.value = ''; }
  if (e.target.id === 'fin') { const l = [...e.target.files]; e.target.value = ''; handleFiles(l); }
  if (e.target.dataset?.ock && ocrSt) {
    if (e.target.checked) ocrSt.sel.add(e.target.dataset.ock); else ocrSt.sel.delete(e.target.dataset.ock);
    const b = $('#ocr [data-ocrapply]'); if (b) b.disabled = !ocrSt.sel.size;
  }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closePdd();
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches?.('.item[data-open]')) { e.preventDefault(); openDetail(e.target.dataset.open); }
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches?.('[data-metric][role=button]')) { e.preventDefault(); openPage('metric', { key: e.target.dataset.metric }); }
});
// ---- Tahan transaksi: pilih + geser untuk atur urutan. Sengaja TANPA getaran. ----
// Tahan = masuk mode pilih (ketuk transaksi lain untuk menambah / mengurangi). Tahan lalu geser = pindahkan di hari yang sama.
// Hapus lewat bar bawah, selalu dengan konfirmasi. ID dan jurnal tidak pernah berubah oleh pengurutan; hanya urutan tampil.
let lp = null, lpUntil = 0, drag = null;
const sel = new Set(), LP_MS = 450;
const lpCancel = () => { if (lp) { clearTimeout(lp.timer); lp = null; } };
const itemEl = (id) => document.querySelector(`.item[data-open="${id}"]`);
const selTxs = () => [...sel].map(id => book.transactions.find(t => t.id === id)).filter(t => t && !t.deleted);

function selBar() {
  const list = selTxs(); if (!list.length) { exitSel(); return; }
  let b = $('#ordbar'); if (b?.dataset.gone) { b.remove(); b = null; }
  if (!b) { b = document.createElement('div'); b.id = 'ordbar'; document.body.appendChild(b); requestAnimationFrame(() => b.classList.add('show')); }
  const sum = list.reduce((s, t) => s + t.price, 0), n = list.length, tot = document.querySelectorAll('.item[data-open]').length, all = n >= tot;
  b.innerHTML = `<button type="button" class="ob-x" data-selx="1" aria-label="Batal memilih">✕</button>
    <div class="ob-t"><b>${n} dipilih</b><small>${n === 1 ? 'Ketuk lainnya · seret ⠿ untuk urutan' : `${rp(sum)}${tot > n ? ` · dari ${tot}` : ''}`}</small></div>
    <button type="button" class="ob-txt" data-selall="1">${all ? 'Kosongkan' : 'Semua'}</button>
    <button type="button" class="ob-del" data-seldel="1" aria-label="Hapus ${n} transaksi yang dipilih">${ico('trash')}<span>Hapus</span><em>${n}</em></button>`;
}
function markSel() { document.querySelectorAll('.item.sel').forEach(e => e.classList.remove('sel')); for (const id of sel) itemEl(id)?.classList.add('sel'); }
function startSel(id) { sel.add(id); document.body.classList.add('selecting'); markSel(); selBar(); }
function exitSel() {
  sel.clear(); document.body.classList.remove('selecting'); markSel();
  const b = $('#ordbar'); if (b) { b.classList.remove('show'); b.dataset.gone = '1'; setTimeout(() => { if (b.dataset.gone) b.remove(); }, 220); }
}
function toggleSel(id) { if (sel.has(id)) sel.delete(id); else sel.add(id); if (!sel.size) exitSel(); else { markSel(); selBar(); } }
function syncSel() {   // setelah tampilan digambar ulang: transaksi yang tidak terlihat lagi tidak boleh ikut terhapus
  if (!sel.size) return;
  for (const id of [...sel]) if (!itemEl(id) || !book.transactions.some(t => t.id === id && !t.deleted)) sel.delete(id);
  if (!sel.size) exitSel(); else { markSel(); selBar(); }
}
function selAll() {
  const els = [...document.querySelectorAll('.item[data-open]')];
  if (els.length && els.every(e => sel.has(e.dataset.open))) { exitSel(); return; }   // semua sudah terpilih → kosongkan
  els.forEach(e => sel.add(e.dataset.open)); markSel(); selBar();
}

function askDelSel() {
  const list = selTxs(); if (!list.length) return;
  const n = list.length, sum = list.reduce((s, t) => s + t.price, 0), nf = list.reduce((s, t) => s + filesOf(t).length, 0);
  askConfirm({ title: n === 1 ? 'Hapus transaksi?' : `Hapus ${n} transaksi?`,
    text: `Total ${rp(sum)}. Saldo dan laporan dikembalikan seperti sebelum dicatat.${nf ? ' Gambar lampiran ikut dihapus.' : ''}`,
    list: list.slice(0, 4).map(t => [t.product, rp(t.price)]), more: n - 4,
    ok: n === 1 ? 'Hapus' : `Hapus ${n}`, danger: true }, async () => {
    const ids = list.map(t => t.id), fids = list.flatMap(t => filesOf(t).map(f => f.id));
    const els = ids.flatMap(id => [...document.querySelectorAll(`.item[data-open="${id}"]`)]);
    els.forEach(e => { e.style.height = `${e.offsetHeight}px`; void e.offsetHeight; e.classList.add('vanish'); e.style.height = '0px'; });   // baris menciut dulu, baru dihapus
    if (els.length && !reduceMotion()) await new Promise(r => setTimeout(r, 240));
    const ok = await act(() => { deleteTransactions(book, ids); list.forEach(t => { t.files = []; }); exitSel(); toast(`${n} transaksi dihapus`); });
    if (ok) { if (fids.length) { delFiles(fids).catch(() => {}); dropUrls(fids); } }
    else els.forEach(e => { e.classList.remove('vanish'); e.style.height = ''; });
  });
}

// ---- Geser untuk atur urutan (hanya di hari yang sama) ----
function beginDrag() {
  const d = drag, t = book.transactions.find(v => v.id === d.id); if (!t) return false;
  const sibs = [...d.el.parentElement.querySelectorAll('.item[data-open]')].filter(s => book.transactions.find(v => v.id === s.dataset.open)?.date === t.date);
  if (sibs.length < 2) return false;
  const sy = scrollY, r = sibs.map(s => { const b = s.getBoundingClientRect(); return { top: b.top + sy, h: b.height }; }), i0 = sibs.indexOf(d.el);
  Object.assign(d, { on: true, sibs, r, i0, cur: i0, off: d.y + sy - r[i0].top, gap: Math.max(0, r[1].top - r[0].top - r[0].h), lo: r[0].top, hi: r[r.length - 1].top + r[r.length - 1].h - r[i0].h });
  document.body.classList.add('dragging'); d.el.classList.add('dragging');
  sibs.forEach(s => { if (s !== d.el) s.style.transition = 'transform .16s ease'; });
  d.raf = requestAnimationFrame(dragLoop);
  return true;
}
function dragStep() {
  const d = drag; if (!d?.on) return;
  const own = d.r[d.i0], want = Math.min(d.hi, Math.max(d.lo, d.py + scrollY - d.off));   // tetap di dalam kelompok hari yang sama
  d.el.style.transform = `translateY(${want - own.top}px)`;
  const c = want + own.h / 2; let tgt = 0;
  d.r.forEach((q, j) => { if (j !== d.i0 && q.top + q.h / 2 < c) tgt++; });
  if (tgt === d.cur) return;
  d.cur = tgt;
  const sh = own.h + d.gap;
  d.sibs.forEach((s, j) => {
    if (j === d.i0) return;
    const y = d.i0 < tgt && j > d.i0 && j <= tgt ? -sh : d.i0 > tgt && j >= tgt && j < d.i0 ? sh : 0;
    s.style.transform = y ? `translateY(${y}px)` : '';
  });
}
function dragLoop() {
  const d = drag; if (!d?.on) return;
  const y = d.py, H = innerHeight, v = y < 90 ? -Math.ceil((90 - y) / 7) : y > H - 110 ? Math.ceil((y - (H - 110)) / 7) : 0;
  if (v) { scrollBy(0, v); dragStep(); }
  d.raf = requestAnimationFrame(dragLoop);
}
let settling = false;
async function endDrag(commit) {
  const d = drag; drag = null; if (!d?.on) return;
  cancelAnimationFrame(d.raf); lpUntil = performance.now() + 500;
  document.body.classList.remove('dragging');
  const reset = () => d.sibs.forEach(s => { s.style.transform = ''; s.style.transition = ''; s.classList.remove('dragging', 'dropping'); });
  const glide = (y) => { d.el.style.transition = 'transform .2s var(--ease), scale .2s var(--ease), box-shadow .2s var(--ease)'; d.el.style.transform = y ? `translateY(${y}px)` : ''; d.el.classList.add('dropping'); };
  settling = true;
  try {
    if (commit && d.cur !== d.i0) {
      const order = d.r.map((_, k) => k); order.splice(d.i0, 1); order.splice(d.cur, 0, d.i0);   // meluncur ke posisi barunya dulu, baru disimpan
      let acc = d.r[0].top, fin = 0; order.forEach(k => { if (k === d.i0) fin = acc; acc += d.r[k].h + d.gap; });
      glide(fin - d.r[d.i0].top); await new Promise(r => setTimeout(r, reduceMotion() ? 0 : 210));
      const ids = d.sibs.map(s => s.dataset.open); ids.splice(d.i0, 1); ids.splice(d.cur, 0, d.id);
      const ok = await act(() => { placeTransaction(book, d.id, ids); });
      if (ok) { $('#main').classList.add('still'); if (!$('#page').hidden) $('#page').classList.add('still'); reset(); return; }   // 'still' = tanpa animasi masuk ulang → tidak berkedip
    }
    glide(0); await new Promise(r => setTimeout(r, 200)); reset();
  } finally { settling = false; }
}

document.addEventListener('pointerdown', e => {
  lpCancel();
  if (!book || drag || settling || (e.pointerType === 'mouse' && e.button !== 0)) return;
  const el = e.target.closest?.('.item[data-open]');
  if (!el || e.target.closest('a, input, textarea, select')) return;
  const x = e.clientX, y = e.clientY;
  if (sel.size && e.target.closest('.grip')) {          // pegangan ⠿ di mode pilih: seret langsung, tanpa tahan
    lpUntil = performance.now() + 800; sw = null;
    drag = { id: el.dataset.open, el, x, y, px: x, py: y, on: false, grip: true };
    return;
  }
  lp = { x, y, timer: setTimeout(() => {
    lp = null; sw = null; lpUntil = performance.now() + 800;
    const id = el.dataset.open;
    if (!sel.size) startSel(id); else if (!sel.has(id)) { sel.add(id); markSel(); selBar(); }
    drag = { id, el, x, y, px: x, py: y, on: false };
    getSelection()?.removeAllRanges();
  }, LP_MS) };
}, true);
document.addEventListener('pointermove', e => {
  if (lp && Math.hypot(e.clientX - lp.x, e.clientY - lp.y) > 9) lpCancel();
  if (!drag) return;
  drag.px = e.clientX; drag.py = e.clientY;
  if (!drag.on) { if (Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 7) return; if (!beginDrag()) { if (drag.grip) toast('Urutan hanya bisa diatur bila ada 2+ transaksi di hari yang sama'); drag = null; return; } }
  dragStep();
}, true);
for (const ev of ['pointerup', 'pointercancel']) document.addEventListener(ev, () => { lpCancel(); if (drag) endDrag(ev === 'pointerup'); }, true);
document.addEventListener('dragstart', lpCancel, true);
document.addEventListener('touchmove', e => { if (drag) e.preventDefault(); }, { passive: false });   // tahan lalu geser: jangan menggulir halaman
document.addEventListener('scroll', lpCancel, true);
document.addEventListener('click', e => {
  const it = e.target.closest?.('.item[data-open]');
  if ((performance.now() < lpUntil || e.target.closest?.('.grip')) && e.target.closest?.('.item')) { e.stopPropagation(); e.preventDefault(); return; }
  if (it && sel.size) { e.stopPropagation(); e.preventDefault(); toggleSel(it.dataset.open); }
}, true);
document.addEventListener('contextmenu', e => {                       // matikan menu/getaran bawaan; klik kanan di desktop = pilih
  if (e.target.closest?.('input, textarea')) return;
  e.preventDefault();
  const el = e.target.closest?.('.item[data-open]');
  if (el && book && !sel.size) { lpUntil = performance.now() + 800; startSel(el.dataset.open); }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (drag?.on) endDrag(false); else if (sel.size) exitSel(); } });

// Teks tampilan (tombol, judul, angka) tidak bisa diseleksi supaya menu Select tidak muncul tak sengaja; kolom isian tetap bisa.
document.addEventListener('selectstart', e => {
  const n = e.target?.nodeType === 1 ? e.target : e.target?.parentElement;
  if (!n?.closest?.('input, textarea')) e.preventDefault();
});
document.addEventListener('focusin', e => {
  if (draft && e.target.matches('#sheet input, #sheet textarea')) { draft.pad = false; $('#pad').hidden = true; }
});
document.addEventListener('submit', e => {
  e.preventDefault(); if (!book) return;
  const f = Object.fromEntries(new FormData(e.target));
  if (e.target.id === 'pf') {
    const id = e.target.dataset.id; f.price = digits(f.price); f.cost = digits(f.cost);
    act(() => { if (id) updateProduct(book, id, f); else addProduct(book, f); closeSheet(); toast('Produk disimpan'); });
    return;
  }
  if (e.target.id === 'cf') {
    const id = e.target.dataset.id;
    act(() => { if (id) updateContact(book, id, f); else addContact(book, f); closeSheet(); toast('Catatan disimpan'); });
    return;
  }
  act(() => addAccount(book, f.name));
});

// ---- Tombol kembali (segitiga di HP / gestur kembali / tombol Back browser) ----
// Setiap lapisan yang terbuka (viewer foto, kalkulator, dialog, pilihan, lembar form / detail, mode pilih, halaman,
// pencarian, menu selain Dashboard) menyimpan satu entri riwayat. Kembali menutup lapisan paling atas;
// bila tidak ada yang terbuka, kembali bekerja seperti biasa (keluar dari aplikasi).
const visible = (q) => { const e = $(q); return !!e && !e.hidden && !e.classList.contains('out'); };
const BACK_LAYERS = [   // urutan: paling atas dulu
  [() => !!viewerSt, () => closeViewer()],
  [() => visible('#calc'), () => closeCalc()],
  [() => visible('#confirm'), () => closeConfirm()],
  [() => visible('#choose'), () => closeChoose()],
  [() => visible('#ocr'), () => closeOcr()],
  [() => visible('#pick'), () => closePicker()],
  [() => !!document.querySelector('.pdd.open'), () => closePdd()],
  [() => !!(draft && draft.pad && !$('#pad')?.hidden), () => { draft.pad = false; $('#pad').hidden = true; }],
  [() => visible('#sheet'), () => closeSheet()],
  [() => sel.size > 0, () => exitSel()],
  [() => !!pageName && !$('#page').hidden && !$('#page').classList.contains('out'), () => pageBack()],
  [() => txSearch && view === 'tx', () => document.querySelector('[data-txsx]')?.click()],
  [() => view !== 'home', () => goView('home')],
];
const backDepth = () => BACK_LAYERS.reduce((n, [on]) => n + (on() ? 1 : 0), 0) + (pageName && pgStack.length ? pgStack.length : 0);
let histCount = 0, histPending = false;
function syncHistory() {
  if (!book || histPending) return;
  const d = backDepth();
  while (histCount < d) { try { history.pushState({ kb: histCount + 1 }, ''); } catch { return; } histCount++; }
  if (histCount > d) { const n = histCount - d; histCount = d; histPending = true; history.go(-n); setTimeout(() => { histPending = false; }, 400); }
}
window.addEventListener('popstate', () => {
  if (histPending) { histPending = false; return; }
  if (histCount > 0) histCount--;
  const top = BACK_LAYERS.find(([on]) => on());
  if (top) top[1]();
  setTimeout(syncHistory, 30);
});
setInterval(syncHistory, 120);

(async () => {
  $('#date').textContent = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });
  try {
    let s = null;
    try { s = await loadSnapshot(); } catch { storage = false; toast('Penyimpanan perangkat tidak tersedia. Data hanya sementara.'); }
    book = s ? restore(s) : createBook();
    applyStartPeriod();
    navigator.storage?.persist?.();
    render();
    if (s) pruneFiles();
  } catch (e) {
    $('#main').innerHTML = `<p class="empty">Data gagal dimuat (${esc(e.message)}). Aplikasi dikunci agar data lama tidak tertimpa.</p>`;
  }
})();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
