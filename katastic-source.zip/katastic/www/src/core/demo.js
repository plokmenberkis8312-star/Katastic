// Data contoh untuk melihat tampilan. Hanya di memori, tidak pernah disimpan ke penyimpanan perangkat.
import { createBook, openAccount, addTransaction } from './ledger.js';
import { addContact } from './notes.js';

export function demoBook() {
  const b = createBook();
  const dayStr = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return d.toLocaleDateString('sv-SE'); };
  [['1101', 850000], ['1102', 2500000], ['1201', 1800000], ['1202', 600000], ['1203', 400000]]
    .forEach(([account, amount]) => openAccount(b, { date: dayStr(9), account, amount }));
  let k = 0;
  const hm = () => `${String(8 + (k++ % 11)).padStart(2, '0')}:${String((k * 17) % 60).padStart(2, '0')}`;
  const sale = (n, product, category, cost, price, fee = 0, paid = true, target = '') => addTransaction(b, {
    date: dayStr(n), time: hm(), product, category, cost, price, fee, paid, target, status: 'berhasil', method: '1101', source: category === 'Token Listrik' ? '1202' : '1201' });
  sale(0, 'Pulsa 10rb Rina', 'Pulsa', 10000, 12000, 500, true, '0812-3456-7890');
  sale(0, 'Token 50rb Pak Budi', 'Token Listrik', 50500, 53000, 0, true, '5324 1100 998');
  sale(0, 'Kuota 3GB Dewi', 'Paket Data', 9000, 10000, 0, false, '0857-1122-3344');
  sale(0, 'Pulsa 50rb Ayu', 'Pulsa', 49000, 52000, 500);
  sale(1, 'Pulsa 25rb', 'Pulsa', 24500, 27000);
  sale(1, 'Top-up ML 86 DM', 'Top-up Game', 20000, 23000);
  sale(1, 'Token 200rb', 'Token Listrik', 200500, 206000);
  sale(2, 'Saldo DANA 100rb', 'E-Wallet', 100000, 102500);
  sale(2, 'Pulsa 20rb', 'Pulsa', 19500, 21500);
  sale(3, 'Token 100rb', 'Token Listrik', 100500, 104000);
  sale(4, 'Pulsa 5rb', 'Pulsa', 5000, 6500);
  sale(5, 'Voucher Google Play', 'Voucher Game', 48000, 52000);
  sale(6, 'Paket Data 5GB', 'Paket Data', 22000, 25000);
  addContact(b, { name: 'Bu Rina', number: '0812-3456-7890', label: 'Pulsa', note: 'Telkomsel, isi tiap awal bulan' });
  addContact(b, { name: 'Pak Budi', number: '5324 1100 998', label: 'Token Listrik', note: 'ID pelanggan PLN rumah' });
  addContact(b, { name: 'Dewi', number: '0857-1122-3344', label: 'Paket Data', note: 'Bayar tiap tanggal 5' });
  addTransaction(b, { kind: 'expense', date: dayStr(2), time: hm(), price: 15000, category: 'Listrik', product: 'Listrik toko', method: '1101' });
  addTransaction(b, { kind: 'expense', date: dayStr(5), time: hm(), price: 5000, category: 'Internet', method: '1102' });
  addTransaction(b, { kind: 'transfer', date: dayStr(3), time: hm(), price: 300000, category: 'Transfer', product: 'Isi deposit', source: '1102', method: '1201' });
  return b;
}
