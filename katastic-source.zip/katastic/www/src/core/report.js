// Rincian laporan dari transaksi (fungsi murni, tidak mengubah buku).
// Angka utama dashboard tetap dari profitLoss (jurnal). Rincian di sini dihitung dari transaksi; jika ada selisih
// (mis. refund / pembatalan yang terjadi di periode ini untuk transaksi periode lain), selisihnya dikembalikan
// sebagai "penyesuaian" supaya angka rincian dan angka utama selalu bisa dicocokkan.
import { profitLoss, recognizedDate, liveTransactions } from './ledger.js';
import { formatRupiah as rp } from './money.js';

// Transaksi dihitung pada tanggal pengakuannya (ikut pengaturan "pendapatan dihitung saat").
export const recognizedIn = (book, t, a, b) => { const d = recognizedDate(book, t); return d !== null && d >= a && d <= b; };

// Sumbangan satu transaksi berhasil ke laporan. Biaya tambahan penjualan ikut sebagai pengeluaran.
export function txParts(t) {
  if (t.kind === 'transfer') return { rev: 0, cogs: 0, exp: t.fee, gross: 0, net: -t.fee };   // hanya pajak transfer yang jadi biaya
  return t.kind === 'income'
    ? { rev: t.price, cogs: t.cost, exp: t.fee, gross: t.price - t.cost, net: t.price - t.cost - t.fee }
    : { rev: 0, cogs: 0, exp: t.price, gross: 0, net: -t.price };
}

// Transaksi berhasil (bukan transfer) yang dihitung pada periode ini.
export function recognizedRows(book, a, b) {
  return liveTransactions(book).filter(t => t.status === 'berhasil' && (t.kind !== 'transfer' || t.fee > 0) && recognizedIn(book, t, a, b));
}

export function sumRows(rows) {
  const s = { n: rows.length, rev: 0, cogs: 0, exp: 0, gross: 0, net: 0 };
  for (const t of rows) { const p = txParts(t); s.rev += p.rev; s.cogs += p.cogs; s.exp += p.exp; s.gross += p.gross; s.net += p.net; }
  return s;
}

// Angka jurnal (sama dengan dashboard) + jumlah dari transaksi + selisihnya.
export function reconcile(book, a, b, rows = recognizedRows(book, a, b)) {
  const pl = profitLoss(book, a, b), sum = sumRows(rows);
  // Dasar "lunas": modal dan biaya penjualan dihitung pada hari transaksi, sedangkan baris rincian mengikuti hari pengakuan pendapatan.
  // Selisih tanggal itu (mis. piutang yang belum lunas) dipisahkan sebagai "pending", bukan dianggap refund / pembatalan.
  const pend = { cogs: 0, exp: 0 };
  if (book.settings?.basis !== 'transaksi') {
    const inR = (d) => d !== null && d >= a && d <= b;
    for (const t of liveTransactions(book)) {
      if (t.kind !== 'income' || t.status !== 'berhasil' || !(t.cost > 0 || t.fee > 0)) continue;
      const cost = inR(t.date), rec = inR(recognizedDate(book, t));
      if (cost && !rec) { pend.cogs += t.cost; pend.exp += t.fee; } else if (!cost && rec) { pend.cogs -= t.cost; pend.exp -= t.fee; }
    }
  }
  pend.gross = -pend.cogs; pend.net = -pend.cogs - pend.exp;
  return { pl, sum, pend, adj: { rev: pl.revenue - sum.rev, cogs: pl.cogs - sum.cogs - pend.cogs, exp: pl.expense - sum.exp - pend.exp, gross: pl.gross - sum.gross - pend.gross, net: pl.net - sum.net - pend.net } };
}

// Kelompokkan: n = jumlah transaksi, sum = jumlah nilai (valFn), base = jumlah harga jual.
export function groupTx(rows, keyFn, valFn = (t) => t.price) {
  const m = new Map();
  for (const t of rows) {
    const k = keyFn(t), o = m.get(k) ?? { key: k, n: 0, sum: 0, base: 0 };
    o.n++; o.sum += valFn(t); o.base += t.price; m.set(k, o);
  }
  return [...m.values()].sort((x, y) => y.sum - x.sum || y.n - x.n || String(x.key).localeCompare(String(y.key), 'id'));
}

// Daftar kategori yang punya transaksi pada periode ini (kind: income | expense).
export function categoryList(book, kind, a, b) {
  const rows = recognizedRows(book, a, b).filter(t => t.kind === kind);
  return groupTx(rows, t => t.category).map(g => ({
    name: g.key, n: g.n, sum: g.sum, net: kind === 'income' ? sumRows(rows.filter(t => t.category === g.key)).net : -g.sum,
  }));
}

const cmpNewest = (x, y) => y.date.localeCompare(x.date) || (y.time ?? '').localeCompare(x.time ?? '') || y.id.localeCompare(x.id);

// Isi satu kategori: hitungan, rata-rata, rincian per nominal, piutang, dan status lain.
export function categoryDetail(book, kind, name, a, b) {
  const rows = recognizedRows(book, a, b).filter(t => t.kind === kind && t.category === name).sort(cmpNewest);
  const s = sumRows(rows), prices = rows.map(t => t.price);
  const sum = prices.reduce((x, y) => x + y, 0);
  const mine = liveTransactions(book).filter(t => t.kind === kind && t.category === name);
  const unpaid = mine.filter(t => t.kind === 'income' && t.status === 'berhasil' && t.paid === false);
  const other = { pending: 0, gagal: 0, dibatalkan: 0, refund: 0 };
  for (const t of mine) if (t.date >= a && t.date <= b && t.status in other) other[t.status]++;
  return {
    rows, n: rows.length, sum, avg: rows.length ? Math.round(sum / rows.length) : 0,
    max: prices.reduce((m, v) => Math.max(m, v), 0), min: prices.length ? prices.reduce((m, v) => Math.min(m, v), Infinity) : 0,
    cogs: s.cogs, fee: kind === 'income' ? s.exp : 0, net: s.net,
    margin: kind === 'income' && sum > 0 ? s.net / sum * 100 : null,
    prices: groupTx(rows, t => t.price).sort((x, y) => y.n - x.n || y.key - x.key),
    unpaid: { n: unpaid.length, sum: unpaid.reduce((x, t) => x + t.price, 0) },
    other,
    history: mine.filter(t => t.date >= a && t.date <= b).sort(cmpNewest),   // semua status, untuk daftar riwayat
  };
}

// Bagian rincian untuk kartu dashboard yang bisa diketuk. omzet | gross | modal | biaya | net
export function metricSections(key, rows) {
  const inc = rows.filter(t => t.kind === 'income'), exp = rows.filter(t => t.kind === 'expense'), tf = rows.filter(t => t.kind === 'transfer');
  const tfSec = (sign) => ({ id: 'tfee', title: 'Pajak transfer', items: groupTx(tf, t => t.category, t => sign * t.fee) });
  const cat = (rs, valFn, kind) => groupTx(rs, t => t.category, valFn).map(g => ({ ...g, cat: { kind, name: g.key } }));
  if (key === 'omzet') return [
    { id: 'cat', title: 'Omzet per kategori', items: cat(inc, t => t.price, 'income'), share: true },
    { id: 'acc', title: 'Masuk ke akun', items: groupTx(inc, t => t.method), share: true, acc: true },
  ];
  if (key === 'gross') return [
    { id: 'cat', title: 'Untung kotor per kategori', items: cat(inc, t => t.price - t.cost, 'income'), share: true, margin: true },
  ];
  if (key === 'modal') {
    const withCost = inc.filter(t => t.cost > 0);
    return [
      { id: 'cat', title: 'Modal per kategori', items: cat(withCost, t => t.cost, 'income'), share: true },
      { id: 'src', title: 'Sumber modal', items: groupTx(withCost, t => t.source, t => t.cost), share: true, acc: true },
    ];
  }
  if (key === 'biaya') return [
    { id: 'ecat', title: 'Pengeluaran per kategori', items: cat(exp, t => t.price, 'expense'), share: true },
    { id: 'fee', title: 'Biaya tambahan penjualan', items: cat(inc.filter(t => t.fee > 0), t => t.fee, 'income'), share: true },
    ...(tf.length ? [{ ...tfSec(1), share: true }] : []),
    { id: 'eacc', title: 'Dibayar dari akun', items: groupTx(exp, t => t.method), share: true, acc: true },
  ];
  if (key === 'net') return [
    { id: 'ncat', title: 'Untung bersih per kategori penjualan', items: cat(inc, t => t.price - t.cost - t.fee, 'income') },
    { id: 'ecat', title: 'Pengeluaran per kategori', items: cat(exp, t => -t.price, 'expense') },
    ...(tf.length ? [tfSec(-1)] : []),
  ];
  return [];
}

// Hitungan status transaksi (tanggal transaksi dalam periode), sama dengan angka di dashboard.
export function statusCounts(book, a, b) {
  const c = { berhasil: 0, pending: 0, gagal: 0, dibatalkan: 0, refund: 0 };
  for (const t of liveTransactions(book)) if (t.date >= a && t.date <= b && t.status in c) c[t.status]++;
  return c;
}

// ---------- Target bulanan ----------
// Capaian bulan berjalan (1 s/d hari ini) dibanding target; hanya tampilan, tidak mengubah buku.
// kind 'net' = untung bersih, 'revenue' = omzet. Proyeksi = laju rata-rata per hari x jumlah hari bulan ini.
export function goalProgress(book, todayStr) {
  const target = Number(book.settings?.goal) || 0;
  if (target <= 0) return null;
  const kind = book.settings?.goalKind === 'revenue' ? 'revenue' : 'net';
  const [y, m, d] = todayStr.split('-').map(Number);
  const days = new Date(y, m, 0).getDate();
  const p = profitLoss(book, `${todayStr.slice(0, 8)}01`, todayStr);
  const done = kind === 'net' ? p.net : p.revenue;
  const left = Math.max(0, target - done), daysLeft = days - d;
  const projected = Math.max(0, Math.round(done / d * days));
  return {
    target, kind, done, left, daysLeft, day: d, days,
    pct: Math.max(0, Math.min(100, Math.round(done / target * 100))),
    perDay: left === 0 ? 0 : Math.ceil(left / Math.max(1, daysLeft)),
    projected,
    status: done >= target ? 'tercapai' : projected >= target ? 'jalur' : 'kejar',
  };
}

// ---------- Jam ramai ----------
// Jumlah penjualan berhasil per jam (0-23) pada rentang tanggal transaksi. Transaksi tanpa jam dilewati.
export function hourHistogram(book, a, b) {
  const hours = Array.from({ length: 24 }, () => ({ n: 0, rev: 0 }));
  let total = 0;
  for (const t of liveTransactions(book)) {
    if (t.kind !== 'income' || t.status !== 'berhasil' || t.date < a || t.date > b || !/^\d\d:\d\d$/.test(t.time ?? '')) continue;
    const h = hours[Number(t.time.slice(0, 2))]; h.n += 1; h.rev += t.price; total += 1;
  }
  let peak = -1;
  hours.forEach((h, i) => { if (h.n > 0 && (peak < 0 || h.n > hours[peak].n)) peak = i; });
  return { hours, total, peak };
}

// ---------- Rekap untuk dibagikan (WhatsApp / salin) ----------
const MON_ID = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const dLong = (s) => `${Number(s.slice(8))} ${MON_ID[Number(s.slice(5, 7)) - 1]} ${s.slice(0, 4)}`;
export function recapText(book, a, b, { label = '', shop = '', owed = null } = {}) {
  const p = profitLoss(book, a, b), n = liveTransactions(book).filter(t => t.status === 'berhasil' && t.date >= a && t.date <= b).length;
  const top = categoryList(book, 'income', a, b).slice(0, 3);
  const L = [`*Rekap ${label}*${shop ? ` · ${shop}` : ''}`, a === b ? dLong(a) : a === '0000-01-01' ? 'Seluruh riwayat' : `${dLong(a)} – ${dLong(b)}`, '',
    `Omzet: ${rp(p.revenue)}`, `Modal: ${rp(p.cogs)}`, `Pengeluaran: ${rp(p.expense)}`, `*Untung bersih: ${rp(p.net)}*`, `Transaksi berhasil: ${n}`];
  if (top.length) L.push('', 'Kategori terlaris:', ...top.map((c, i) => `${i + 1}. ${c.name} — ${rp(c.sum)} (${c.n}x)`));
  if (owed && owed.n > 0) L.push('', `Piutang belum bayar: ${rp(owed.sum)} (${owed.n} transaksi)`);
  L.push('', '_Dibuat dengan Katastic_');
  return L.join('\n');
}
