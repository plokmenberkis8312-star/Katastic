// Geometri diagram donat (murni, tanpa DOM) supaya mudah diuji.
export const TAU = Math.PI * 2;

// Sudut tiap irisan menurut nilainya. Irisan yang terlalu kecil (mis. 50 rb dari 500 jt) tetap diberi sudut minimum agar
// warnanya terlihat; selisihnya diambil dari irisan lain secara proporsional (diulang sampai tidak ada yang di bawah minimum).
export function pieAngles(values, min = 0.07) {
  const n = values.length, tot = values.reduce((a, v) => a + v, 0);
  if (!n || !(tot > 0)) return [];
  if (n === 1) return [{ a0: 0, a1: TAU, share: 1 }];
  const raw = values.map(v => v / tot * TAU), m = Math.min(min, TAU / n), fixed = new Set();
  let k = 1;
  for (;;) {
    const room = TAU - fixed.size * m, base = raw.reduce((a, r, i) => fixed.has(i) ? a : a + r, 0);
    k = base > 0 ? room / base : 0;
    const bad = raw.map((_, i) => i).filter(i => !fixed.has(i) && raw[i] * k < m);
    if (!bad.length) break;
    bad.forEach(i => fixed.add(i));
  }
  let acc = 0;
  return raw.map((r, i) => { const a0 = acc; acc += fixed.has(i) ? m : r * k; return { a0, a1: i === n - 1 ? TAU : acc, share: values[i] / tot }; });
}

// Jarak antar irisan dibuat dengan menyempitkan sudut (bukan garis tepi), jadi irisan setipis apa pun tidak tertutup warna latar.
export const sliceInset = (a, gap = 0.024) => Math.min(gap / 2, a / 4);

// Jalur irisan cincin; sudut 0 di atas, searah jarum jam.
export function slicePath(cx, cy, ro, ri, a0, a1) {
  const f = (v) => v.toFixed(1), pt = (t, r) => [cx + r * Math.sin(t), cy - r * Math.cos(t)];
  const [x0, y0] = pt(a0, ro), [x1, y1] = pt(a1, ro), [u1, v1] = pt(a1, ri), [u0, v0] = pt(a0, ri), lg = a1 - a0 > Math.PI ? 1 : 0;
  return `M${f(x0)} ${f(y0)}A${ro} ${ro} 0 ${lg} 1 ${f(x1)} ${f(y1)}L${f(u1)} ${f(v1)}A${ri} ${ri} 0 ${lg} 0 ${f(u0)} ${f(v0)}Z`;
}

// Teks persen: satu desimal, "<0,1" untuk yang sangat kecil (bukan "0").
export function fmtShare(p) {
  if (!(p > 0)) return '0';
  return p < 0.1 ? '<0,1' : String(Math.round(p * 10) / 10).replace('.', ',');
}
