// Semua nominal = bilangan bulat rupiah. Float ditolak.
export function assertRupiah(n, label = 'nominal') {
  if (!Number.isSafeInteger(n)) throw new Error(`${label} harus bilangan bulat rupiah`);
  return n;
}

export function parseRupiah(input) {
  const s = String(input).trim();
  if (/[.,]\d{1,2}$/.test(s)) throw new Error('Desimal tidak didukung');
  const digits = s.replace(/[^\d-]/g, '');
  if (!/^-?\d+$/.test(digits)) throw new Error('Nominal tidak valid');
  return assertRupiah(Number(digits));
}

export function formatRupiah(n) {
  assertRupiah(n);
  const body = String(Math.abs(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${n < 0 ? '-' : ''}Rp${body}`;
}

// Singkatan nominal untuk grafik dan label sempit: 1,5rb · 2,5jt · 50m (miliar) · 1,2t (triliun).
// Dua desimal untuk jt ke atas, satu desimal untuk rb; angka nol di belakang koma dibuang.
const ABBR = [[1e12, 't', 2], [1e9, 'm', 2], [1e6, 'jt', 2], [1e3, 'rb', 1]];
export function abbrRupiah(v) {
  const n = Math.abs(Number(v) || 0), sg = v < 0 ? '-' : '';
  const fmt = (x) => String(x).replace('.', ',');
  for (let i = 0; i < ABBR.length; i++) {
    const [u, l, d] = ABBR[i];
    if (n < u) continue;
    const x = +(n / u).toFixed(d);
    if (x >= 1000 && i > 0) return `${sg}${fmt(+(n / ABBR[i - 1][0]).toFixed(ABBR[i - 1][2]))}${ABBR[i - 1][1]}`;   // 999,9rb → 1jt
    return `${sg}${fmt(x)}${l}`;
  }
  return sg + String(Math.round(n));
}
