import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, openAccount, addTransaction, deleteTransaction, deleteTransactions, placeTransaction, balance, isBalanced, liveTransactions, txOrder } from '../www/src/core/ledger.js';

const mk = () => { const b = createBook(); openAccount(b, { date: '2026-11-01', account: '1101', amount: 1000000 }); openAccount(b, { date: '2026-11-01', account: '1201', amount: 500000 }); return b; };
const sale = (b, price, date = '2026-11-20', o = {}) => addTransaction(b, { date, price, cost: price - 1000, category: 'Pulsa', status: 'berhasil', ...o });
const order = (b, date = '2026-11-20') => liveTransactions(b).filter(t => t.date === date).sort(txOrder).map(t => t.id);

test('hapus banyak: semua dibalik, saldo kembali, jurnal tetap seimbang', () => {
  const b = mk(), k0 = balance(b, '1101'), d0 = balance(b, '1201');
  const a = sale(b, 12000), c = sale(b, 50000), d = sale(b, 25000);
  deleteTransactions(b, [a.id, c.id]);
  assert.deepEqual(liveTransactions(b).map(t => t.id), [d.id]);
  deleteTransactions(b, [d.id]);
  assert.equal(balance(b, '1101'), k0); assert.equal(balance(b, '1201'), d0); assert.ok(isBalanced(b));
  assert.ok(a.deleted && c.deleted && d.deleted);
});
test('hapus banyak itu atomik: gagal satu, tidak ada yang berubah', () => {
  const b = mk(), a = sale(b, 12000), x = sale(b, 9000);
  deleteTransaction(b, x.id);
  const n = b.entries.length, k = balance(b, '1101');
  assert.throws(() => deleteTransactions(b, [a.id, x.id]), /tidak ditemukan/);
  assert.equal(a.deleted, undefined); assert.equal(b.entries.length, n); assert.equal(balance(b, '1101'), k);
  assert.throws(() => deleteTransactions(b, []), /Tidak ada/);
});
test('hapus banyak: saldo akun tidak boleh jadi minus karena penghapusan', () => {
  const b = mk(), a = addTransaction(b, { kind: 'expense', date: '2026-11-20', price: 200000, category: 'Operasional', method: '1101', status: 'berhasil' });
  const t = addTransaction(b, { kind: 'transfer', date: '2026-11-20', price: 300000, category: 'Transfer', source: '1101', method: '1102', status: 'berhasil' });
  const before = balance(b, '1102');
  deleteTransaction(b, a.id);                                    // aman: saldo bertambah
  const s = sale(b, 700000, '2026-11-20', { cost: 0 });          // tambah kas
  assert.equal(balance(b, '1102'), before);
  deleteTransactions(b, [t.id, s.id]); assert.ok(isBalanced(b));
});
test('geser urutan: menaruh transaksi di posisi baru dan bertahan', () => {
  const b = mk(); [1000, 2000, 3000].forEach(p => sale(b, p));
  const first = order(b), last = first[2];
  assert.equal(placeTransaction(b, last, [last, ...first.filter(x => x !== last)]), true);
  assert.equal(order(b)[0], last); assert.equal(order(b).length, 3);
  assert.equal(placeTransaction(b, order(b)[0], order(b)), false);   // sama seperti sekarang
});
test('geser urutan: hanya sebagian yang terlihat, yang tersembunyi tetap di tempatnya; input salah ditolak', () => {
  const b = mk(), [a, c, d, e] = [1, 2, 3, 4].map(n => sale(b, n * 1000)), o = order(b), vis = [o[0], o[2], o[3]];
  placeTransaction(b, o[3], [o[3], o[0], o[2]]);
  const after = order(b); assert.equal(after[1], o[1]); assert.deepEqual([after[0], after[2], after[3]], [o[3], o[0], o[2]]);
  assert.throws(() => placeTransaction(b, a.id, [c.id]), /tidak valid/);
  assert.throws(() => placeTransaction(b, a.id, [a.id, a.id]), /tidak valid/);
  const other = sale(b, 5000, '2026-11-21'); assert.throws(() => placeTransaction(b, a.id, [a.id, other.id]), /tidak valid/);
});
test('urutan tidak mengubah ID, saldo, atau jurnal', () => {
  const b = mk(), [a, c] = [sale(b, 1000), sale(b, 2000)], n = b.entries.length, k = balance(b, '1101');
  placeTransaction(b, c.id, [c.id, a.id]);
  assert.equal(b.entries.length, n); assert.equal(balance(b, '1101'), k); assert.equal(a.id, 'TX-000001');
});
