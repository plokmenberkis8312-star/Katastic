import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, openAccount, addTransaction, editTransaction, deleteTransaction, balance, isBalanced, profitLoss } from '../www/src/core/ledger.js';
import { reconcile, recognizedRows, metricSections } from '../www/src/core/report.js';
import { strukText } from '../www/src/core/notes.js';

const mk = () => { const b = createBook(); openAccount(b, { date: '2026-11-01', account: '1101', amount: 1000000 }); return b; };
const tr = (b, o = {}) => addTransaction(b, { kind: 'transfer', date: '2026-11-20', price: 300000, fee: 2500, category: 'Transfer', source: '1101', method: '1102', ...o });

test('pajak transfer: tujuan menerima nominal, asal berkurang nominal + pajak, pajak jadi biaya', () => {
  const b = mk(); tr(b);
  assert.equal(balance(b, '1102'), 300000); assert.equal(balance(b, '1101'), 1000000 - 302500);
  assert.ok(isBalanced(b)); assert.equal(profitLoss(b, '2026-11-01', '2026-11-30').expense, 2500);
});
test('transfer tanpa pajak tetap bukan biaya dan tidak masuk rincian laporan', () => {
  const b = mk(); tr(b, { fee: 0 });
  assert.equal(profitLoss(b, '2026-11-01', '2026-11-30').expense, 0); assert.equal(recognizedRows(b, '2026-11-01', '2026-11-30').length, 0);
});
test('rincian laporan cocok dengan jurnal (tanpa selisih) dan menampilkan pajak transfer', () => {
  const b = mk(); tr(b);
  const rows = recognizedRows(b, '2026-11-01', '2026-11-30'), rec = reconcile(b, '2026-11-01', '2026-11-30', rows);
  assert.equal(rec.adj.exp, 0); assert.equal(rec.adj.net, 0); assert.equal(rec.sum.net, -2500);
  assert.equal(metricSections('biaya', rows).find(s => s.id === 'tfee').items[0].sum, 2500);
});
test('saldo asal harus cukup untuk nominal + pajak; edit dan hapus membalik jurnal', () => {
  const b = mk();
  assert.throws(() => tr(b, { price: 999000, fee: 2000 }), /tidak cukup/);
  assert.equal(b.transactions.length, 0);
  const t = tr(b); editTransaction(b, t.id, { fee: 5000 });
  assert.equal(balance(b, '1101'), 1000000 - 305000); assert.equal(profitLoss(b, '2026-11-01', '2026-11-30').expense, 5000);
  deleteTransaction(b, t.id);
  assert.equal(balance(b, '1101'), 1000000); assert.equal(profitLoss(b, '2026-11-01', '2026-11-30').expense, 0); assert.ok(isBalanced(b));
});
test('struk: lebar 32 kolom, ada nomor TRX, total transfer = nominal + pajak', () => {
  const b = mk(), t = tr(b), s = strukText(t, 'Konter Berkah');
  assert.ok(s.split('\n').every(l => l.length <= 32)); assert.match(s, /TRX-000001/); assert.match(s, /TOTAL\s+Rp302\.500/); assert.match(s, /Pajak\s+Rp2\.500/);
  const i = addTransaction(mk(), { date: '2026-11-20', price: 12000, product: 'Pulsa Telkomsel 10.000 untuk Bu Rina di rumah', category: 'Pulsa', status: 'berhasil', paid: false });
  const si = strukText(i); assert.ok(si.split('\n').every(l => l.length <= 32)); assert.match(si, /Belum bayar/);
});
