import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseReceiptText } from '../www/src/core/receipt.js';
import { createBook, addTransaction, editTransaction, restore, snapshot, deleteTransaction, balance, isBalanced, openAccount } from '../www/src/core/ledger.js';
import { setFiles, fileIdsInUse, fileText, filesOf, MAX_FILES, newFileId } from '../www/src/core/attach.js';

const INC = ['Pulsa', 'Paket Data', 'Top-up Game', 'Voucher Game', 'E-Wallet', 'Token Listrik', 'PPOB', 'Lainnya'];
const fx = (n) => readFileSync(new URL(`./fixtures/${n}.txt`, import.meta.url), 'utf8');   // keluaran Tesseract sungguhan
const run = (text, o = {}) => Object.fromEntries(Object.entries(parseReceiptText(text, { today: '2026-11-22', kind: 'income', categories: INC, ...o })).map(([k, v]) => [k, v.value]));

test('struk pulsa (OCR nyata): total bukan harga/admin, nomor HP dinormalkan', () => {
  assert.deepEqual(run(fx('pulsa')), { price: 12000, date: '2026-11-21', time: '14:35', target: '081234567890', category: 'Pulsa', name: 'Pulsa Telkomsel 10.000', note: 'Ref TRX8827719203' });
});
test('struk token PLN (OCR nyata): saldo tidak dipilih, ID meter tanpa spasi, nama diubah ke huruf kapital awal', () => {
  const r = run(fx('token'));
  assert.equal(r.price, 53000); assert.equal(r.target, '53241100998'); assert.equal(r.category, 'Token Listrik');
  assert.equal(r.name, 'Token PLN 50.000 Budi Santoso'); assert.equal(r.date, '2026-11-21'); assert.equal(r.time, '09:12');
});
test('bukti transfer (OCR nyata): nominal di baris setelah label, tanpa nomor/kategori untuk transfer', () => {
  const r = run(fx('transfer'), { kind: 'transfer', categories: [] });
  assert.equal(r.price, 250000); assert.equal(r.date, '2026-11-20'); assert.equal(r.time, '18:05');
  assert.equal(r.target, undefined); assert.equal(r.category, undefined); assert.equal(r.name, 'Top up DANA Dewi Lestari');
});
test('salah baca huruf O / l pada nominal setelah Rp', () => {
  assert.equal(run('Total Rp 5O.OOO').price, 50000);
  assert.equal(run('Total Bayar Rp l5.000,00').price, 15000);
});
test('tanggal: nama bulan Indonesia, 2 digit tahun, ISO; tanggal mustahil / masa depan ditolak', () => {
  assert.equal(run('5 Mei 2026').date, '2026-05-05');
  assert.equal(run('05-11-26').date, '2026-11-05');
  assert.equal(run('2026-03-09').date, '2026-03-09');
  assert.equal(run('31/02/2026').date, undefined);
  assert.equal(run('30/12/2026').date, undefined);
  assert.equal(run('21/11/2026\n01/01/2026').date, '2026-11-21');
});
test('jam: format titik hanya diterima bila diikuti WIB/WITA/WIT', () => {
  assert.equal(run('14.35 WIB').time, '14:35');
  assert.equal(run('Rp 12.50').time, undefined);
  assert.equal(run('9:05').time, '09:05');
});
test('nomor: +62 dan 62 jadi 08…, nomor referensi tidak dikira nomor HP', () => {
  assert.equal(run('No. HP +62 812-3456-7890').target, '081234567890');
  assert.equal(run('Ref: 081234567890').target, undefined);
  assert.equal(run('ID Game 123456789 (2231)').target, '123456789 (2231)');
});
test('tanpa nominal yang jelas tidak menebak; tahun dan nomor panjang bukan nominal', () => {
  assert.equal(run('Terima kasih\n2026\n081234567890').price, undefined);
  assert.equal(run('').price, undefined);
  assert.deepEqual(parseReceiptText(null, { today: '2026-11-22' }), {});
});
test('kategori hanya disarankan bila ada di daftar kategori pengguna', () => {
  assert.equal(run('Pulsa 10rb', { categories: ['Lainnya'] }).category, undefined);
  assert.equal(run('top up dana 50.000').category, 'E-Wallet');
  assert.equal(run('Voucher Google Play 50.000').category, 'Voucher Game');
  assert.equal(run('Bayar listrik toko Rp 150.000', { kind: 'expense', categories: ['Operasional', 'Listrik'] }).category, 'Listrik');
});

// ---- Lampiran: metadata di buku, bukan bagian jurnal ----
const meta = (id, text = '') => ({ id, name: 'struk.jpg', w: 800, h: 1200, size: 90000, text });
function bookWithTx() {
  const b = createBook(); openAccount(b, { date: '2026-11-01', account: '1101', amount: 1000000 }); openAccount(b, { date: '2026-11-01', account: '1201', amount: 500000 });
  return { b, tx: addTransaction(b, { date: '2026-11-21', price: 12000, cost: 10000, category: 'Pulsa', status: 'berhasil' }) };
}
test('lampiran tidak mengubah jurnal, saldo, maupun keseimbangan', () => {
  const { b, tx } = bookWithTx(), n = b.entries.length, saldo = balance(b, '1101');
  setFiles(b, tx.id, [meta('F1', 'Total Rp 12.000')]);
  assert.equal(b.entries.length, n); assert.equal(balance(b, '1101'), saldo); assert.ok(isBalanced(b));
  assert.equal(fileText(tx), 'Total Rp 12.000');
});
test('edit transaksi mempertahankan lampiran; backup + restore membawa metadata', () => {
  const { b, tx } = bookWithTx(); setFiles(b, tx.id, [meta('F1'), meta('F2')]);
  editTransaction(b, tx.id, { price: 13000 });
  assert.deepEqual(filesOf(b.transactions[0]).map(f => f.id), ['F1', 'F2']);
  const back = restore(snapshot(b)); assert.deepEqual([...fileIdsInUse(back)], ['F1', 'F2']);
  assert.deepEqual([...fileIdsInUse(restore(JSON.parse(snapshot(b))))], ['F1', 'F2']);   // restore menerima objek juga
});
test('batas jumlah, id ganda, dan transaksi terhapus ditolak', () => {
  const { b, tx } = bookWithTx();
  assert.throws(() => setFiles(b, tx.id, Array.from({ length: MAX_FILES + 1 }, () => meta(newFileId()))), /Maksimal/);
  assert.throws(() => setFiles(b, tx.id, [meta('A'), meta('A')]), /ganda/);
  assert.throws(() => setFiles(b, 'TX-999999', []), /tidak ditemukan/);
  deleteTransaction(b, tx.id);
  assert.throws(() => setFiles(b, tx.id, [meta('A')]), /tidak ditemukan/);
  assert.equal(filesOf({}).length, 0);   // backup lama tanpa tx.files
});
test('id gambar unik', () => { assert.notEqual(newFileId(), newFileId()); });
