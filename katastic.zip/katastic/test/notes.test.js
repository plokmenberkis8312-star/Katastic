import test from 'node:test';
import assert from 'node:assert/strict';
import { createBook, snapshot, restore } from '../www/src/core/ledger.js';
import { receiptText, reminderText, waNumber, addContact, updateContact, removeContact, searchContacts, findContactByNumber } from '../www/src/core/notes.js';

test('catatan: tambah, validasi, nomor ganda ditolak, cari, ubah, hapus, ikut backup', () => {
  const b = createBook();
  const a = addContact(b, { name: ' Bu  Rina ', number: '0812-3456-7890', label: 'Pulsa', note: 'Telkomsel' });
  assert.equal(a.name, 'Bu Rina');
  assert.throws(() => addContact(b, { name: 'Lain', number: '0812 3456 7890' }), /sudah tersimpan atas nama Bu Rina/);
  assert.throws(() => addContact(b, { name: '', number: '' }), /minimal/);
  assert.throws(() => addContact(b, { name: 'x'.repeat(41) }), /maksimal 40/);
  const p = addContact(b, { name: 'Pak Budi', number: '5324 1100 998', label: 'PLN' });
  assert.notEqual(a.id, p.id);
  assert.deepEqual(searchContacts(b, '').map(x => x.name), ['Bu Rina', 'Pak Budi']);
  assert.deepEqual(searchContacts(b, '08123456').map(x => x.name), ['Bu Rina']);
  assert.deepEqual(searchContacts(b, 'pln').map(x => x.name), ['Pak Budi']);
  assert.equal(findContactByNumber(b, '53241100998').name, 'Pak Budi');
  assert.equal(findContactByNumber(b, ''), null);
  updateContact(b, a.id, { note: 'Ganti ke XL' });
  assert.equal(a.note, 'Ganti ke XL');
  assert.throws(() => updateContact(b, a.id, { number: '5324-1100-998' }), /sudah tersimpan/);
  const r = restore(snapshot(b));
  assert.equal(r.contacts.length, 2);
  removeContact(r, p.id);
  assert.equal(r.contacts.length, 1);
  assert.throws(() => removeContact(r, p.id), /tidak ditemukan/);
  assert.equal(addContact(r, { name: 'Baru' }).id !== a.id, true);
});

test('teks salin: struk transaksi, pengingat tagihan, nomor WhatsApp', () => {
  const t = { product: 'Pulsa 50rb Ayu', price: 52000, category: 'Pulsa', date: '2026-11-20', time: '11:08', target: '0857-1122-3344', note: 'Telkomsel', kind: 'income', status: 'berhasil', paid: false };
  const txt = receiptText(t).split('\n');
  assert.equal(txt[0], 'Pulsa 50rb Ayu');
  assert.match(txt[1], /Rp\s?52\.000 · Pulsa/);
  assert.ok(txt.includes('No./ID: 0857-1122-3344') && txt.includes('Status: Belum bayar') && txt.includes('Catatan: Telkomsel'));
  assert.ok(receiptText({ ...t, paid: true }).includes('Status: Lunas'));
  const one = reminderText([t]);
  assert.match(one, /Pulsa 50rb Ayu/); assert.doesNotMatch(one, /Total:/);
  const many = reminderText([t, { ...t, product: 'Token', price: 10000 }], 'Konter Maju');
  assert.match(many, /Total: Rp\s?62\.000/); assert.match(many, /- Konter Maju$/);
  assert.equal(waNumber('0857-1122-3344'), '6285711223344');
  assert.equal(waNumber('+62 812 3456 7890'), '6281234567890');
  assert.equal(waNumber('5324 1100 998'), null);            // ID PLN bukan nomor HP
  assert.equal(waNumber('ID-778899'), null);
  assert.equal(waNumber(''), null);
});
