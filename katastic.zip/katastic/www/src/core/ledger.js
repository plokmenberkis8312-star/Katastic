import { assertRupiah } from './money.js';
import { CHART } from './accounts.js';

const DEBIT_NORMAL = new Set(['asset', 'cogs', 'expense']);

export const START_PERIODS = ['day', 'week', 'month', 'year', 'all', 'last', 'custom'];
export const defaultSettings = () => ({ basis: 'lunas', shop: '', goal: 0, goalKind: 'net', startPeriod: 'day', startCustom: null });
export function createBook() {
  const accounts = {};
  for (const [code, name, type] of CHART) accounts[code] = { code, name, type };
  return { accounts, entries: [], reversedBy: {}, audit: [], transactions: [], contacts: [], categories: defaultCategories(), settings: defaultSettings(), seq: 0 };
}

const log = (book, action, detail) =>
  book.audit.push({ at: new Date().toISOString(), action, detail });

export function balance(book, code) {
  const acc = book.accounts[code];
  if (!acc) throw new Error(`Akun ${code} tidak ada`);
  let d = 0, c = 0;
  for (const e of book.entries)
    for (const l of e.lines) if (l.account === code) { d += l.debit; c += l.credit; }
  return DEBIT_NORMAL.has(acc.type) ? d - c : c - d;
}

export function isBalanced(book) {
  let d = 0, c = 0;
  for (const e of book.entries) for (const l of e.lines) { d += l.debit; c += l.credit; }
  return d === c;
}

// Satu-satunya pintu menulis ke buku besar. Entri tidak pernah diubah/dihapus.
export function postEntry(book, { date, memo = '', ref = null, lines, allowNegative = false, reversalOf = null }) {
  if (!/^\d{4}-\d{2}-\d{2}/.test(date ?? '')) throw new Error('Tanggal tidak valid');
  if (!Array.isArray(lines) || lines.length < 2) throw new Error('Jurnal minimal 2 baris');
  if (ref && book.entries.some(e => e.ref === ref && !e.reversalOf && !book.reversedBy[e.id]))
    throw new Error(`Transaksi duplikat: ${ref}`);

  let td = 0, tc = 0;
  const clean = lines.map(({ account, debit = 0, credit = 0 }) => {
    if (!book.accounts[account]) throw new Error(`Akun ${account} tidak ada`);
    assertRupiah(debit, 'debit');
    assertRupiah(credit, 'kredit');
    if (debit < 0 || credit < 0 || (debit > 0) === (credit > 0))
      throw new Error('Tiap baris harus punya tepat satu sisi bernilai > 0');
    td += debit; tc += credit;
    return Object.freeze({ account, debit, credit });
  });
  if (td !== tc) throw new Error(`Jurnal tidak seimbang: debit ${td} != kredit ${tc}`);

  if (!allowNegative) {
    for (const code of new Set(clean.map(l => l.account))) {
      const acc = book.accounts[code];
      if (acc.type !== 'asset') continue;
      const delta = clean.filter(l => l.account === code).reduce((s, l) => s + l.debit - l.credit, 0);
      if (balance(book, code) + delta < 0) throw new Error(`Saldo ${acc.name} tidak cukup`);
    }
  }

  const entry = Object.freeze({
    id: `JE-${String(++book.seq).padStart(6, '0')}`,
    date, memo, ref, reversalOf, lines: Object.freeze(clean),
  });
  book.entries.push(entry);
  log(book, 'POST', { id: entry.id, ref, memo });
  return entry;
}

export function reverseEntry(book, id, { date, reason, allowNegative = false }) {
  const orig = book.entries.find(e => e.id === id);
  if (!orig) throw new Error(`Jurnal ${id} tidak ditemukan`);
  if (orig.reversalOf) throw new Error('Jurnal pembalik tidak dapat dibalik lagi');
  if (book.reversedBy[id]) throw new Error(`Jurnal ${id} sudah dibalik`);
  if (!reason) throw new Error('Alasan pembalikan wajib diisi');
  const rev = postEntry(book, {
    date, allowNegative, reversalOf: id, memo: `Pembalikan ${id}: ${reason}`,
    lines: orig.lines.map(l => ({ account: l.account, debit: l.credit, credit: l.debit })),
  });
  book.reversedBy[id] = rev.id;
  log(book, 'REVERSE', { id, by: rev.id, reason });
  return rev;
}

export function openAccount(book, { date, account, amount }) {
  return postEntry(book, {
    date, memo: `Saldo awal ${book.accounts[account]?.name ?? account}`,
    lines: [{ account, debit: amount }, { account: '3101', credit: amount }],
  });
}

// Penjualan berhasil. Untung bersih = price - cost - fee.
export function recordSale(book, { date, ref, product, cost, price, fee = 0, payTo = '1101', source = '1201', allowLoss = false, allowNegative = false }) {
  assertRupiah(cost, 'harga modal'); assertRupiah(price, 'harga jual'); assertRupiah(fee, 'biaya tambahan');
  if (cost <= 0 || price <= 0 || fee < 0) throw new Error('Nominal harus positif');
  if (price < cost + fee && !allowLoss) throw new Error('Harga jual di bawah modal + biaya');
  const lines = [
    { account: payTo, debit: price },
    { account: '4101', credit: price },
    { account: '5101', debit: cost },
    ...(fee ? [{ account: '6101', debit: fee }] : []),
    { account: source, credit: cost + fee },
  ];
  return postEntry(book, { date, ref, memo: `Penjualan ${product}`, lines, allowNegative });
}

// Transfer internal: bukan omzet, bukan untung.
// fee = pajak / biaya transfer: keluar dari akun asal di luar nominal yang sampai ke tujuan, dicatat sebagai biaya (6101).
export function transfer(book, { date, from, to, amount, fee = 0, ref = null, allowNegative = false }) {
  if (from === to) throw new Error('Akun asal dan tujuan harus berbeda');
  return postEntry(book, {
    date, ref, allowNegative, memo: `Transfer ${from} ke ${to}`,
    lines: fee > 0 ? [{ account: to, debit: amount }, { account: '6101', debit: fee }, { account: from, credit: amount + fee }]
      : [{ account: to, debit: amount }, { account: from, credit: amount }],
  });
}

// Dasar pendapatan (book.settings.basis):
//  'lunas' (bawaan)  : penjualan yang BELUM dibayar tidak dihitung; baru masuk laporan pada tanggal pelunasan.
//  'transaksi'       : dihitung pada tanggal transaksi walau belum dibayar.
// Jurnal tidak diubah; hanya tanggal pengakuan di laporan yang digeser. Jurnal pembalik ikut digeser
// supaya hapus/edit/refund tidak membuat laporan timpang.
const recogCache = new WeakMap();
function recognition(book) {
  const hit = recogCache.get(book);
  if (hit && hit.n === book.entries.length) return hit.when;
  const byId = new Map(book.entries.map(e => [e.id, e])), when = {}, open = {};
  for (const e of book.entries) {
    if (e.reversalOf) { const o = byId.get(e.reversalOf); if (o && open[o.ref] === o.id) delete open[o.ref]; continue; }
    if (e.ref?.endsWith('-LUNAS')) { const u = open[e.ref.slice(0, -6)]; if (u && when[u] === null) when[u] = e.date.slice(0, 10); }
    else if (e.lines.some(l => l.account === '1301' && l.debit > 0)) { when[e.id] = null; open[e.ref] = e.id; }
  }
  recogCache.set(book, { n: book.entries.length, when });
  return when;
}

// Tanggal sebuah transaksi mulai dihitung sebagai pendapatan; null = belum dihitung (belum bayar).
export function recognizedDate(book, tx) {
  if (book.settings?.basis === 'transaksi' || tx.kind !== 'income') return tx.date;
  if (tx.paid === false) return null;
  const s = tx.settleId && book.entries.find(e => e.id === tx.settleId);
  return s ? s.date.slice(0, 10) : tx.date;
}

export function profitLoss(book, from, to) {
  const s = { revenue: 0, cogs: 0, expense: 0 };
  const when = book.settings?.basis === 'transaksi' ? null : recognition(book);
  for (const e of book.entries) {
    let day = e.date.slice(0, 10);
    const root = e.reversalOf ?? e.id;
    if (when && root in when) {
      const w = when[root];
      if (w === null) continue;
      day = e.reversalOf && day > w ? day : w;
    }
    if (day < from || day > to) continue;
    for (const l of e.lines) {
      const t = book.accounts[l.account].type;
      if (t === 'revenue') s.revenue += l.credit - l.debit;
      else if (t in s) s[t] += l.debit - l.credit;
    }
  }
  const gross = s.revenue - s.cogs;
  return { ...s, gross, net: gross - s.expense };
}

const isDate = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(`${v}T00:00:00Z`)) && new Date(`${v}T00:00:00Z`).toISOString().slice(0, 10) === v;
export function setSettings(book, patch) {
  book.settings = { ...defaultSettings(), ...book.settings };
  if ('basis' in patch) {
    if (!['lunas', 'transaksi'].includes(patch.basis)) throw new Error('Pilihan tidak dikenal');
    book.settings.basis = patch.basis;
  }
  if ('shop' in patch) {
    const v = String(patch.shop ?? '').trim().replace(/\s+/g, ' ');
    if (v.length > 30) throw new Error('Nama usaha maksimal 30 karakter');
    book.settings.shop = v;
  }
  if ('goal' in patch) {                                   // target bulanan (rupiah bulat, 0 = tanpa target)
    const g = Number(patch.goal ?? 0);
    if (!Number.isInteger(g) || g < 0 || g > 1e12) throw new Error('Target tidak valid');
    book.settings.goal = g;
  }
  if ('startPeriod' in patch || 'startCustom' in patch) {  // periode awal saat aplikasi dibuka; divalidasi dulu, baru disimpan (tidak setengah tersimpan)
    const sp = 'startPeriod' in patch ? patch.startPeriod : book.settings.startPeriod;
    if (!START_PERIODS.includes(sp)) throw new Error('Pilihan tidak dikenal');
    let sc = book.settings.startCustom ?? null;
    if ('startCustom' in patch) {                          // satu tanggal (b kosong / sama dengan a) atau rentang a..b
      const c = patch.startCustom;
      if (c === null) sc = null;
      else {
        const a = c?.a, b = c?.b || c?.a;
        if (!isDate(a) || !isDate(b)) throw new Error('Tanggal tidak valid');
        if (b < a) throw new Error('Tanggal akhir tidak boleh sebelum tanggal awal');
        sc = { a, b };
      }
    }
    if (sp === 'custom' && !sc) throw new Error('Pilih tanggal untuk periode tetap');
    book.settings.startPeriod = sp; book.settings.startCustom = sc;
  }
  if ('goalKind' in patch) {
    if (!['net', 'revenue'].includes(patch.goalKind)) throw new Error('Pilihan tidak dikenal');
    book.settings.goalKind = patch.goalKind;
  }
  return book.settings;
}

export const snapshot = (book) => JSON.stringify(book);
export function restore(json) {
  const book = typeof json === 'string' ? JSON.parse(json) : json;
  if (!book?.accounts || !Array.isArray(book.entries)) throw new Error('Bukan file cadangan Katastic');
  book.transactions ??= [];
  book.contacts ??= [];
  book.settings = { ...defaultSettings(), ...book.settings };
  book.categories ??= defaultCategories();
  if (!isBalanced(book)) throw new Error('Backup rusak: jurnal tidak seimbang');
  return book;
}

// ---- Transaksi bertatus. kind: income | expense | transfer. Hanya 'berhasil' masuk jurnal. ----
export const CATEGORY_LIST = ['Pulsa', 'Paket Data', 'Top-up Game', 'Voucher Game', 'E-Wallet', 'Token Listrik', 'PPOB', 'Lainnya'];
export const EXPENSE_CATS = ['Operasional', 'Sewa', 'Listrik', 'Internet', 'Gaji', 'Transport', 'Lainnya'];
const NEXT = { pending: ['berhasil', 'gagal', 'dibatalkan'] };

function posting(book, tx, date) {
  const base = { date, ref: tx.id }, pay = tx.paid === false ? '1301' : tx.method;
  if (tx.kind === 'expense')
    return postEntry(book, { ...base, memo: `Pengeluaran ${tx.product}`, lines: [{ account: '6101', debit: tx.price }, { account: tx.method, credit: tx.price }] });
  if (tx.kind === 'transfer') return transfer(book, { ...base, from: tx.source, to: tx.method, amount: tx.price, fee: tx.fee });
  if (tx.cost > 0) return recordSale(book, { ...base, product: tx.product, cost: tx.cost, price: tx.price, fee: tx.fee, payTo: pay, source: tx.source });
  return postEntry(book, { ...base, memo: `Pendapatan ${tx.product}`, lines: [{ account: pay, debit: tx.price }, { account: '4101', credit: tx.price }] });
}

function normalize(t) {
  const kind = t.kind ?? 'income';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t.date ?? '')) throw new Error('Tanggal tidak valid');
  if (t.time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(t.time)) throw new Error('Jam tidak valid');
  if (!['income', 'expense', 'transfer'].includes(kind)) throw new Error('Jenis transaksi tidak valid');
  const cost = kind === 'income' ? t.cost ?? 0 : 0, fee = kind === 'income' || kind === 'transfer' ? t.fee ?? 0 : 0;   // transfer: fee = pajak / biaya transfer
  for (const [k, v] of [['nominal', t.price], ['harga modal', cost], ['biaya', fee]]) assertRupiah(v, k);
  if (t.price <= 0 || cost < 0 || fee < 0) throw new Error('Nominal harus lebih dari 0');
  if (kind === 'income' && cost === 0 && fee > 0) throw new Error('Biaya tambahan butuh harga modal');
  const target = String(t.target ?? '').trim(), note = String(t.note ?? '').trim();
  if (target.length > 40) throw new Error('No. / ID pelanggan maksimal 40 karakter');
  if (note.length > 200) throw new Error('Catatan maksimal 200 karakter');
  return {
    target, note,
    date: t.date, time: t.time ?? '', kind, product: (t.product ?? '').trim() || t.category || 'Transaksi', category: t.category ?? 'Lainnya',
    cost, price: t.price, fee, paid: kind === 'income' ? t.paid !== false : true, method: t.method ?? '1101', source: t.source ?? '1201',
  };
}

export function addTransaction(book, t) {
  const kind = t.kind ?? 'income', status = t.status ?? (kind === 'income' ? 'pending' : 'berhasil');
  const f = normalize(t);
  if (!['pending', 'berhasil', 'gagal'].includes(status) || (f.kind !== 'income' && status !== 'berhasil')) throw new Error('Status awal tidak valid');
  const tx = { id: `TX-${String(book.transactions.length + 1).padStart(6, '0')}`, ...f, status: 'pending', entryId: null };
  book.transactions.push(tx);
  try { if (status !== 'pending') setStatus(book, tx.id, status, t.date); }
  catch (e) { book.transactions.pop(); throw e; }
  log(book, 'TX_ADD', { id: tx.id });
  return tx;
}

// Koreksi: jurnal lama dibalik (pada tanggal aslinya, supaya laporan harian tetap benar), lalu diposting ulang dengan data baru.
export function editTransaction(book, id, patch) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx) throw new Error('Transaksi tidak ditemukan');
  if (tx.deleted) throw new Error('Transaksi sudah dihapus');
  if (!['pending', 'berhasil'].includes(tx.status)) throw new Error('Transaksi ini sudah ditutup dan tidak bisa diedit');
  if (tx.entryId) assertAccountsActive(book, tx);
  const next = { ...tx, ...normalize({ ...tx, ...patch }) };
  const assets = Object.values(book.accounts).filter(a => a.type === 'asset');
  const neg0 = new Set(assets.filter(a => balance(book, a.code) < 0).map(a => a.code));
  atomic(book, () => {
    if (tx.entryId) {
      for (const eid of [tx.settleId, tx.entryId].filter(Boolean)) {
        const e = book.entries.find(x => x.id === eid);
        reverseEntry(book, eid, { date: e.date, reason: `Koreksi ${tx.id}`, allowNegative: true });
      }
      next.entryId = null; next.settleId = null;
    }
    if (next.status === 'berhasil') next.entryId = posting(book, next, next.date).id;
    for (const a of assets) if (balance(book, a.code) < 0 && !neg0.has(a.code)) throw new Error(`Saldo ${a.name} tidak cukup`);
  });
  const dateChanged = next.date !== tx.date;
  Object.assign(tx, next);
  if (dateChanged) delete tx.ord;                           // pindah hari → urutan manual hari lama tidak berlaku
  log(book, 'TX_EDIT', { id });
  return tx;
}

export function setStatus(book, id, status, date) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  const allowed = tx.status === 'berhasil' ? (tx.kind === 'income' ? ['refund'] : ['dibatalkan']) : NEXT[tx.status];
  if (!allowed?.includes(status)) throw new Error(`Status ${tx.status} tidak bisa menjadi ${status}`);
  if (status === 'berhasil') tx.entryId = posting(book, tx, date).id;
  else if (tx.entryId) atomic(book, () => {
    assertAccountsActive(book, tx);
    const reason = `${status} ${tx.id}`;
    if (tx.settleId) reverseEntry(book, tx.settleId, { date, reason });
    reverseEntry(book, tx.entryId, { date, reason });
  });
  tx.status = status;
  log(book, 'TX_STATUS', { id, status });
  return tx;
}

// ---- Kategori kustom (tersimpan di buku, ikut backup). Transaksi lama tetap menyimpan nama kategorinya. ----
function defaultCategories() { return { income: [...CATEGORY_LIST], expense: [...EXPENSE_CATS] }; }

export function addCategory(book, kind, name) {
  const list = book.categories[kind], n = String(name ?? '').trim().replace(/\s+/g, ' ');
  if (!list) throw new Error('Jenis kategori tidak valid');
  if (!n) throw new Error('Nama kategori wajib diisi');
  if (n.length > 20) throw new Error('Nama kategori maksimal 20 huruf');
  if (list.some(c => c.toLowerCase() === n.toLowerCase())) throw new Error('Kategori sudah ada');
  list.push(n);
  log(book, 'CAT_ADD', { kind, name: n });
  return n;
}

export function removeCategory(book, kind, name) {
  const list = book.categories[kind], i = list ? list.indexOf(name) : -1;
  if (i < 0) throw new Error('Kategori tidak ditemukan');
  if (list.length === 1) throw new Error('Minimal harus ada satu kategori');
  list.splice(i, 1);
  log(book, 'CAT_DEL', { kind, name });
}

// ---- Pembayaran (piutang) dan akun kustom ----
export const ACCOUNT_SHORT = { 1101: 'Tunai', 1102: 'Bank', 1201: 'Deposit Pulsa', 1202: 'Deposit PPOB', 1203: 'E-Wallet', 1301: 'Piutang' };

function atomic(book, fn) {
  const keep = { n: book.entries.length, a: book.audit.length, seq: book.seq, rev: { ...book.reversedBy } };
  try { return fn(); } catch (e) {
    book.entries.length = keep.n; book.audit.length = keep.a; book.seq = keep.seq; book.reversedBy = keep.rev;
    throw e;
  }
}

// Pembeli belum bayar = penjualan tercatat ke Piutang. Pelunasan memindahkan Piutang ke akun tujuan.
export function settleTransaction(book, id, date) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  if (tx.kind !== 'income' || tx.status !== 'berhasil' || tx.paid !== false) throw new Error('Transaksi ini tidak menunggu pembayaran');
  if (tx.method === '1301') throw new Error('Pilih akun tujuan selain Piutang');
  const e = postEntry(book, { date, ref: `${tx.id}-LUNAS`, memo: `Pelunasan ${tx.product}`,
    lines: [{ account: tx.method, debit: tx.price }, { account: '1301', credit: tx.price }] });
  tx.paid = true; tx.settleId = e.id;
  log(book, 'TX_PAID', { id });
  return tx;
}

export function addAccount(book, name) {
  const n = String(name ?? '').trim().replace(/\s+/g, ' ');
  if (!n) throw new Error('Nama akun wajib diisi');
  if (n.length > 20) throw new Error('Nama akun maksimal 20 huruf');
  const taken = Object.values(book.accounts).filter(a => a.type === 'asset' && !a.archived).map(a => ACCOUNT_SHORT[a.code] ?? a.name);
  if (taken.some(x => x.toLowerCase() === n.toLowerCase())) throw new Error('Nama akun sudah ada');
  let i = 1; while (book.accounts[`14${String(i).padStart(2, '0')}`]) i++;
  const code = `14${String(i).padStart(2, '0')}`;
  book.accounts[code] = { code, name: n, type: 'asset' };
  log(book, 'ACC_ADD', { code, name: n });
  return code;
}

export function removeAccount(book, code) {
  if (!book.accounts[code] || !code.startsWith('14')) throw new Error('Akun bawaan tidak bisa dihapus');
  if (book.entries.some(e => e.lines.some(l => l.account === code))) throw new Error('Akun sudah punya riwayat. Hapus lewat menu Kas (riwayat tetap aman).');
  if (book.transactions.some(t => t.method === code || t.source === code)) throw new Error('Akun dipakai transaksi, tidak bisa dihapus');
  delete book.accounts[code];
  log(book, 'ACC_DEL', { code });
}

// ---- Hapus transaksi, ubah status bayar, hapus akun ----
// Prinsip buku besar tetap: tidak ada jurnal yang dihapus. "Hapus" = jurnal dibalik pada tanggal aslinya
// (laporan jadi seolah transaksi tak pernah ada), transaksi disembunyikan, jejaknya tetap ada di audit.
export const liveTransactions = (book) => book.transactions.filter(t => !t.deleted);
export const PROTECTED_ACCOUNTS = ['1101', '1301'];

// Akun yang benar-benar dipakai jurnal sebuah transaksi berhasil.
function usedAccounts(tx) {
  if (tx.kind === 'expense') return [tx.method];
  if (tx.kind === 'transfer') return [tx.source, tx.method];
  return [tx.paid === false ? '1301' : tx.method, ...(tx.cost > 0 ? [tx.source] : [])];
}

function assertAccountsActive(book, tx) {
  const gone = usedAccounts(tx).map(c => book.accounts[c]).find(a => a?.archived);
  if (gone) throw new Error(`Transaksi ini memakai akun ${ACCOUNT_SHORT[gone.code] ?? gone.name} yang sudah dihapus. Aktifkan lagi akunnya di Kas.`);
}

// Hapus satu atau banyak transaksi sekaligus: semua berhasil atau tidak ada yang berubah (jurnal dibalik, tidak dihapus).
function dropTx(book, txs, many) {
  const assets = Object.values(book.accounts).filter(a => a.type === 'asset');
  const neg0 = new Set(assets.filter(a => balance(book, a.code) < 0).map(a => a.code));
  atomic(book, () => {
    for (const tx of txs) if (tx.status === 'berhasil') {   // status lain sudah dibalik saat statusnya berubah
      assertAccountsActive(book, tx);
      for (const eid of [tx.settleId, tx.entryId].filter(Boolean)) {
        const e = book.entries.find(x => x.id === eid);
        reverseEntry(book, eid, { date: e.date, reason: `Hapus ${tx.id}`, allowNegative: true });
      }
    }
    for (const a of assets) if (balance(book, a.code) < 0 && !neg0.has(a.code)) throw new Error(`Saldo ${a.name} tidak cukup untuk menghapus ${many ? 'transaksi yang dipilih' : 'transaksi ini'}`);
  });
  const at = new Date().toISOString();
  for (const tx of txs) { tx.deleted = true; tx.deletedAt = at; log(book, 'TX_DEL', { id: tx.id }); }
}
export function deleteTransaction(book, id) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  dropTx(book, [tx], false);
  return tx;
}
export function deleteTransactions(book, ids) {
  const uniq = [...new Set(ids)];
  if (!uniq.length) throw new Error('Tidak ada transaksi yang dipilih');
  const txs = uniq.map(id => book.transactions.find(x => x.id === id));
  if (txs.some(t => !t || t.deleted)) throw new Error('Transaksi tidak ditemukan');
  dropTx(book, txs, true);
  return txs;
}

// Sudah bayar <-> belum bayar tanpa membuka form edit.
export function setPaid(book, id, paid, date) {
  const tx = book.transactions.find(x => x.id === id);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  if (tx.kind !== 'income') throw new Error('Hanya pendapatan yang punya status bayar');
  if (!['pending', 'berhasil'].includes(tx.status)) throw new Error('Transaksi ini sudah ditutup');
  if ((tx.paid !== false) === paid) return tx;
  if (paid && tx.status === 'berhasil') return settleTransaction(book, id, date);
  return editTransaction(book, id, { paid });
}

// Hapus akun. Tanpa riwayat -> dihapus sungguhan (akun kustom). Ada riwayat -> diarsipkan: hilang dari daftar
// dan pilihan, riwayat & laporan utuh. Saldo yang tersisa dipindah ke akun tujuan lewat jurnal.
export function deleteAccount(book, code, { moveTo = null, date } = {}) {
  const acc = book.accounts[code];
  if (!acc || acc.type !== 'asset') throw new Error('Akun tidak ditemukan');
  if (acc.archived) throw new Error('Akun sudah dihapus');
  if (code === '1101') throw new Error('Kas Tunai adalah akun utama, tidak bisa dihapus');
  if (code === '1301') throw new Error('Piutang dipakai sistem, tidak bisa dihapus');
  const bal = balance(book, code);
  if (bal < 0) throw new Error('Saldo akun minus, perbaiki dulu sebelum menghapus');
  const mine = (t) => t.method === code || t.source === code;
  const refs = book.transactions.filter(t => !t.deleted && mine(t));
  const open = refs.filter(t => t.status === 'pending' || (t.kind === 'income' && t.status === 'berhasil' && t.paid === false));
  const hasEntries = book.entries.some(e => e.lines.some(l => l.account === code));
  if (!hasEntries && !refs.length && code.startsWith('14')) {
    delete book.accounts[code]; log(book, 'ACC_DEL', { code }); return 'dihapus';
  }
  if (bal > 0 || open.length) {
    const to = book.accounts[moveTo];
    if (!to || to.type !== 'asset' || to.archived || moveTo === code || moveTo === '1301') throw new Error('Pilih akun tujuan untuk memindahkan saldo');
  }
  atomic(book, () => {
    if (bal > 0) postEntry(book, { date: date ?? new Date().toLocaleDateString('sv-SE'), memo: `Saldo ${acc.name} dipindah ke ${book.accounts[moveTo].name} (akun dihapus)`,
      lines: [{ account: moveTo, debit: bal }, { account: code, credit: bal }] });
    for (const t of open) { if (t.method === code) t.method = moveTo; if (t.source === code) t.source = moveTo; }
    acc.archived = true;
  });
  log(book, 'ACC_ARCHIVE', { code, moveTo });
  return 'diarsipkan';
}

export function restoreAccount(book, code) {
  const acc = book.accounts[code];
  if (!acc?.archived) throw new Error('Akun tidak ditemukan');
  const dup = Object.values(book.accounts).find(a => a.type === 'asset' && !a.archived && (ACCOUNT_SHORT[a.code] ?? a.name).toLowerCase() === (ACCOUNT_SHORT[code] ?? acc.name).toLowerCase());
  if (dup) throw new Error('Sudah ada akun aktif dengan nama yang sama');
  delete acc.archived;
  log(book, 'ACC_RESTORE', { code });
}

// ---------- Urutan transaksi dalam satu hari ----------
// Urutan tampil: tanggal terbaru dulu; dalam satu hari, urutan manual (ord, kecil = di atas) bila ada,
// transaksi baru tanpa ord tampil paling atas (jam terbaru dulu). ID dan jurnal tidak pernah berubah.
export const txOrder = (x, y) => {
  const dx = x.date.localeCompare(y.date);
  if (dx) return -dx;
  const hx = x.ord != null, hy = y.ord != null;
  if (hx !== hy) return hx ? 1 : -1;
  if (hx) return x.ord - y.ord;
  return (y.time ?? '').localeCompare(x.time ?? '') || y.id.localeCompare(x.id);
};

// how: 'up' | 'down' | 'top' | 'bottom'. among (opsional): id yang sedang tampil, supaya satu langkah melewati transaksi tersaring.
// Mengembalikan false bila sudah di ujung. Hanya mengubah field ord (metadata tampilan), bukan id, tanggal, atau jurnal.
// Urutan tampil dalam satu hari hasil geser. order = id transaksi (hari yang sama) dalam urutan baru; yang tidak ada di daftar tetap di tempatnya.
export function placeTransaction(book, id, order) {
  const tx = book.transactions.find(t => t.id === id);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  const day = liveTransactions(book).filter(t => t.date === tx.date).sort(txOrder), byId = new Map(day.map(t => [t.id, t]));
  if (!order.includes(id) || new Set(order).size !== order.length || order.some(x => !byId.has(x))) throw new Error('Urutan tidak valid');
  const next = [...day];
  day.map((t, k) => order.includes(t.id) ? k : -1).filter(k => k >= 0).forEach((k, j) => { next[k] = byId.get(order[j]); });
  if (next.every((t, k) => t === day[k])) return false;
  next.forEach((t, k) => { t.ord = k; });
  log(book, 'TX_MOVE', { id, how: 'drag' });
  return true;
}

export function moveTransaction(book, id, how, among = null) {
  const tx = book.transactions.find(t => t.id === id);
  if (!tx || tx.deleted) throw new Error('Transaksi tidak ditemukan');
  if (!['up', 'down', 'top', 'bottom'].includes(how)) throw new Error('Arah tidak dikenal');
  const day = liveTransactions(book).filter(t => t.date === tx.date).sort(txOrder);
  const vis = among ? day.filter(t => t.id === id || among.includes(t.id)) : day, i = vis.findIndex(t => t.id === id);
  const target = how === 'up' ? vis[i - 1] : how === 'down' ? vis[i + 1] : how === 'top' ? vis[0] : vis[vis.length - 1];
  if (!target || target.id === id) return false;
  const rest = day.filter(t => t.id !== id), at = rest.findIndex(t => t.id === target.id);
  rest.splice(how === 'up' || how === 'top' ? at : at + 1, 0, tx);
  rest.forEach((t, k) => { t.ord = k; });
  log(book, 'TX_MOVE', { id, how });
  return true;
}
