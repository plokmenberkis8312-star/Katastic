// Semua nominal = bilangan bulat rupiah. Float ditolak.
export function assertRupiah(n, label = 'nominal') {
  if (!Number.isSafeInteger(n)) throw new Error(`${label} harus bilangan bulat rupiah`);
  return n;
}

export function parseRupiah(input) {
  const s = String(input).trim();
  if (/[.,]\d{1,2}$/.test(s)) throw new Error('Desimal tidak didukung');
  const digits = s.replace(/[^\d-]/g, '');
  if (!/^-?\d+$/.test(digits)) throw new Error('Nominal tidak valid');
  return assertRupiah(Number(digits));
}

export function formatRupiah(n) {
  assertRupiah(n);
  const body = String(Math.abs(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${n < 0 ? '-' : ''}Rp${body}`;
}
