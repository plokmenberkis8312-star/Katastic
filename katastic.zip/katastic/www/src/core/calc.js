// Kalkulator tanpa eval: + - × ÷ dengan prioritas. Pemanggil membulatkan hasil ke rupiah utuh.
export function evalExpr(s) {
  const t = s.match(/\d+|[+\-×÷]/g) ?? [];
  if (/[+\-×÷]/.test(t.at(-1) ?? '0')) t.pop();
  if (!t.length) return 0;
  const out = [Number(t[0])];
  for (let i = 1; i < t.length; i += 2) {
    const op = t[i], n = Number(t[i + 1]);
    if (op === '×') out.push(out.pop() * n);
    else if (op === '÷') { if (n === 0) throw new Error('Tidak bisa dibagi 0'); out.push(out.pop() / n); }
    else out.push(op, n);
  }
  let r = out[0];
  for (let i = 1; i < out.length; i += 2) r = out[i] === '+' ? r + out[i + 1] : r - out[i + 1];
  return r;
}

export const fmtExpr = (s) => s.replace(/\d+/g, n => n.replace(/\B(?=(\d{3})+(?!\d))/g, '.'));

export function pressKey(expr, k) {
  const last = expr.slice(-1), isOp = (c) => c !== '' && '+-×÷'.includes(c);
  const num = expr.match(/\d*$/)[0];
  if (k === '000') return num === '' || num === '0' || num.length > 9 ? expr : expr + k;
  if (/^\d$/.test(k)) return num.length >= 12 ? expr : num === '0' ? expr.slice(0, -1) + k : expr + k;
  if (k === 'back') return expr.slice(0, -1);
  if (k === 'C') return '';
  if (isOp(k)) return expr === '' ? expr : isOp(last) ? expr.slice(0, -1) + k : expr + k;
  return expr;
}
