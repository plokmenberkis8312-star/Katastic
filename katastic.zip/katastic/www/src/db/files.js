// Penyimpanan gambar lampiran. Database TERPISAH dari buku besar (katastic-files), jadi kegagalan di sini
// tidak pernah menyentuh data akuntansi. Gambar disimpan sebagai ArrayBuffer (paling kompatibel).
const FDB = 'katastic-files', FSTORE = 'f';
let fdb = null;
const fOpen = () => fdb ??= new Promise((res, rej) => {
  const r = indexedDB.open(FDB, 1);
  r.onupgradeneeded = () => r.result.createObjectStore(FSTORE);
  r.onsuccess = () => { r.result.onversionchange = () => { r.result.close(); fdb = null; }; res(r.result); };
  r.onerror = () => { fdb = null; rej(r.error); };
  r.onblocked = () => { fdb = null; rej(new Error('Penyimpanan gambar sedang dipakai tab lain')); };
});
const fRun = async (mode, fn) => {
  const db = await fOpen();
  return new Promise((res, rej) => {
    const tx = db.transaction(FSTORE, mode); let out;
    try { out = fn(tx.objectStore(FSTORE)); } catch (e) { rej(e); return; }
    tx.oncomplete = () => res(out?.result ?? out);
    tx.onerror = tx.onabort = () => rej(tx.error ?? new Error('Gagal menyimpan gambar'));
  });
};

// rec = { type, buf: ArrayBuffer, tType, tBuf: ArrayBuffer }
export const putFile = (id, rec) => fRun('readwrite', s => { s.put(rec, id); });
export const getFile = (id) => fRun('readonly', s => s.get(id)).then(r => r ?? null);
export const delFiles = (ids) => ids.length ? fRun('readwrite', s => { for (const id of ids) s.delete(id); }) : Promise.resolve();
export const fileKeys = () => fRun('readonly', s => s.getAllKeys());
